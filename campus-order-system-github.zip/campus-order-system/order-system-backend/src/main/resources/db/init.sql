CREATE DATABASE IF NOT EXISTS order_system DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE order_system;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS message;
DROP TABLE IF EXISTS review_item;
DROP TABLE IF EXISTS review;
DROP TABLE IF EXISTS order_item;
DROP TABLE IF EXISTS order_info;
DROP TABLE IF EXISTS cart;
DROP TABLE IF EXISTS menu;
DROP TABLE IF EXISTS sys_user;
DROP TABLE IF EXISTS canteen_window;
DROP TABLE IF EXISTS canteen;
DROP TABLE IF EXISTS sys_role;

CREATE TABLE `sys_role` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_code` (`role_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `sys_role` VALUES (1,'学生','STUDENT','在校学生，可以在线订餐',TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(2,'食堂管理员','CANTEEN_ADMIN','食堂窗口管理员',TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(3,'系统管理员','SYSTEM_ADMIN','平台系统管理员',TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52'));
CREATE TABLE `canteen` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `canteen` VALUES (1,'第一食堂','校园东区教学楼旁','主营川菜和湘菜，性价比高',1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(2,'第二食堂','校园西区宿舍区','面食小吃应有尽有',1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(3,'第三食堂','校园南区实验楼旁','快餐饮品一站式',1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52'));
CREATE TABLE `canteen_window` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `canteen_id` bigint NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `floor` int DEFAULT '1',
  `pickup_number_prefix` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'A',
  `status` tinyint DEFAULT '1',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_window_canteen` (`canteen_id`),
  CONSTRAINT `fk_window_canteen` FOREIGN KEY (`canteen_id`) REFERENCES `canteen` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `canteen_window` VALUES (1,1,'1号窗口-麻辣烫',1,'A',1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(2,1,'2号窗口-快餐',1,'B',1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(3,1,'3号窗口-煲仔饭',2,'C',1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(4,2,'1号窗口-包子铺',1,'D',1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(5,2,'2号窗口-面食',1,'E',1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(6,2,'3号窗口-小吃炸鸡',1,'F',1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(7,3,'1号窗口-快餐',1,'G',1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(8,3,'2号窗口-饮品甜点',1,'H',1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(9,1,'4号窗口-粥粉面',2,'I',1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(10,2,'4号窗口-铁板烧',2,'J',1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(11,3,'3号窗口-轻食沙拉',2,'K',1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(12,3,'4号窗口-地方风味',2,'L',1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52'));
CREATE TABLE `sys_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `real_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` bigint NOT NULL,
  `canteen_id` bigint DEFAULT NULL,
  `window_id` bigint DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `fk_user_canteen` (`canteen_id`),
  KEY `fk_user_window` (`window_id`),
  KEY `idx_user_role` (`role_id`,`status`),
  CONSTRAINT `fk_user_canteen` FOREIGN KEY (`canteen_id`) REFERENCES `canteen` (`id`),
  CONSTRAINT `fk_user_role` FOREIGN KEY (`role_id`) REFERENCES `sys_role` (`id`),
  CONSTRAINT `fk_user_window` FOREIGN KEY (`window_id`) REFERENCES `canteen_window` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `sys_user` VALUES (1,'20240001','$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi','张三','13800001001',1,NULL,NULL,NULL,1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(2,'20240002','$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi','李四','13800001002',1,NULL,NULL,NULL,1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(3,'20240003','$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi','王五','13800001003',1,NULL,NULL,NULL,1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(4,'admin001','$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi','管理员A','13800002001',2,1,1,NULL,1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(5,'admin002','$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi','管理员B','13800002002',2,2,4,NULL,1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(6,'system001','$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi','系统管理员','13800003001',3,NULL,NULL,NULL,1,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52'));
CREATE TABLE `menu` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `window_id` bigint NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int NOT NULL DEFAULT '0',
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `sale_date` date NOT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_menu_window` (`window_id`,`category`,`status`),
  CONSTRAINT `fk_menu_window` FOREIGN KEY (`window_id`) REFERENCES `canteen_window` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `menu` VALUES (1,1,'经典麻辣烫','主食',18.00,51,'/uploads/menu-images/b31aea49740743f58005553355da87fd.png','自选菜品麻辣烫，辣度可选',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(2,1,'骨汤麻辣烫','主食',22.00,31,'/uploads/menu-images/01e77c31c2e847f79cd90cb9137da0f8.png','浓郁骨汤底，适合不吃辣的同学',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(3,1,'冰镇酸梅汤','饮料',5.00,0,'/uploads/menu-images/e68dbb9e26db4288a158cae880c358ea.png','冰镇解辣必备',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(4,2,'红烧肉套餐','主食',25.00,19,'/uploads/menu-images/f45b19039f344155896797fe8b13f6b3.png','红烧肉+米饭+时蔬+蛋花汤',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(5,2,'宫保鸡丁套餐','主食',22.00,15,'/uploads/menu-images/7d11910dbbaa410d84713de229edf50b.png','宫保鸡丁+米饭+时蔬',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(6,2,'糖醋里脊套餐','主食',24.00,3,'/uploads/menu-images/cf848a38ead941ea92781c6c2581ef62.png','糖醋里脊+米饭+凉拌黄瓜',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(7,3,'腊肠煲仔饭','主食',20.00,25,'/uploads/menu-images/50f8c7d74d7648a3994234cd43245972.png','经典广式腊味煲仔饭',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(8,3,'香菇滑鸡煲仔饭','主食',23.00,18,'/uploads/menu-images/ef6cd2c08baf4fe2827e046293a4ee68.png','嫩滑鸡肉+香菇+秘制酱汁',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(9,4,'鲜肉包子','小吃',3.00,100,'/uploads/menu-images/161d3fb251e64202a2e9e5c1235f61ee.png','现蒸猪肉大葱馅，一笼6个',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(10,4,'三鲜包子','小吃',4.00,80,'/uploads/menu-images/7f1f640781b042b7804ce4a832862d3b.png','虾仁猪肉鸡蛋馅',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(11,4,'豆浆','饮料',2.00,150,'/uploads/menu-images/321fb5f57ee745bd8c772238e58eebcc.png','现磨豆浆，冷热可选',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(12,5,'牛肉拉面','主食',15.00,40,'/uploads/menu-images/826ed5e3afb647ec8e021c6caebccec7.png','兰州风味牛肉拉面',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(13,5,'炸酱面','主食',13.00,35,'/uploads/menu-images/90725cfacdb942f3b44582a5fc4930da.png','老北京炸酱面+黄瓜丝',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(14,5,'酸辣粉','小吃',10.00,5,'/uploads/menu-images/74440cbdd8fd4247b91c2e8be4d3916b.png','重庆风味酸辣粉',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(15,6,'香辣鸡腿堡','主食',16.00,30,'/uploads/menu-images/default-dish.svg','现炸鸡腿+新鲜蔬菜+秘制酱料',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(16,6,'薯条','小吃',8.00,60,'/uploads/menu-images/default-dish.svg','黄金脆薯，配番茄酱',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(17,6,'鸡米花','小吃',10.00,45,'/uploads/menu-images/default-dish.svg','一口一个停不下来',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(18,6,'可乐','饮料',4.00,100,'/uploads/menu-images/4393ade8eff44ad799345a00cf9cc22b.png','冰镇可口可乐',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(19,7,'番茄鸡蛋盖饭','主食',16.00,35,'/uploads/menu-images/203463355e714440adebfdc0aec1a3fd.png','番茄炒蛋+米饭',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(20,7,'鱼香肉丝盖饭','主食',18.00,30,'/uploads/menu-images/4bbdf500b0d74b4792e549b08c8f0fae.png','鱼香肉丝+米饭+小菜',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(21,8,'珍珠奶茶','饮料',10.00,81,'/uploads/menu-images/c04f5e3ee231484e9cc0de51e631238b.png','经典珍珠奶茶，Q弹珍珠',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(22,8,'杨枝甘露','饮料',12.00,50,'/uploads/menu-images/18ae61dc489d4787a2af1c9227344ebe.png','芒果+西柚+椰奶',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(23,8,'提拉米苏','小吃',15.00,0,'/uploads/menu-images/233f697cd25c451caf24cc25758a0eb8.png','意式经典甜点',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(24,8,'抹茶蛋糕','小吃',12.00,13,'/uploads/menu-images/0327fb52aec8479fac42c90a7b01fcd6.png','日式抹茶千层蛋糕',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(25,9,'皮蛋瘦肉粥','主食',8.00,70,'/uploads/menu-images/1b7ab5ade35a4809ba4352e448dca859.png','绵密热粥，早餐夜宵都合适',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(26,9,'肠粉双拼','主食',12.00,45,'/uploads/menu-images/4decb67bc4aa4ce38d8b23a9283dc6e4.png','鸡蛋肠粉+鲜肉肠粉',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(27,9,'云吞面','主食',14.00,38,'/uploads/menu-images/b87dbc1fdeca4606a24b27e28a959ed9.png','鲜虾云吞配细面',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(28,9,'红豆沙','饮料',6.00,50,'/uploads/menu-images/03afb9e57d8d42479c8f3a7caf97ad96.png','温热红豆沙，甜度适中',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(29,10,'黑椒牛柳饭','主食',26.00,30,'/uploads/menu-images/default-dish.svg','铁板黑椒牛柳配米饭',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(30,10,'照烧鸡排饭','主食',22.00,35,'/uploads/menu-images/default-dish.svg','照烧鸡排+煎蛋+蔬菜',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(31,10,'铁板豆腐','小吃',10.00,40,'/uploads/menu-images/default-dish.svg','外焦里嫩，酱香浓郁',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(32,10,'柠檬红茶','饮料',6.00,80,'/uploads/menu-images/679ba361c2fb49ee81f60263d6195e91.jpg','冰爽解腻',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(33,11,'鸡胸肉沙拉','主食',24.00,28,'/uploads/menu-images/c7eacc68fc694a2994816bc41f9a793d.png','低脂鸡胸肉配混合蔬菜',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(34,11,'金枪鱼饭团','主食',12.00,45,'/uploads/menu-images/dbda31e1a0a84a5fab82b0ca36f79d16.png','海苔饭团，方便携带',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(35,11,'水果酸奶杯','小吃',13.00,32,'/uploads/menu-images/f9787ad7f2754defad366ad0292aa954.png','酸奶+当季水果+坚果',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(36,11,'无糖豆乳','饮料',7.00,60,'','植物蛋白饮品',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(37,12,'新疆炒米粉','主食',18.00,36,'/uploads/menu-images/496fb6687a824716b55caee312388971.png','香辣浓郁，米粉筋道',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(38,12,'黄焖鸡米饭','主食',20.00,40,'/uploads/menu-images/56b0a22d21004d87a19d029b8b7fa9ce.png','鸡肉软烂，酱汁下饭',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(39,12,'螺蛳粉','主食',17.00,25,'/uploads/menu-images/d8d21d2c2772426588aa3c5be7d4d779.png','酸辣鲜香，配料丰富',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(40,12,'桂花冰粉','小吃',8.00,44,'/uploads/menu-images/cdc34103c6384bc29666b77d682c055a.png','清凉甜品，桂花香气',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(41,1,'番茄牛腩麻辣烫','主食',24.00,23,'/uploads/menu-images/7bc12292c9d540b8abfdfd8549500772.png','番茄汤底搭配牛腩',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(42,2,'鱼香茄子套餐','主食',19.00,33,'/uploads/menu-images/66d9309b68664576a82ded71df4e40e9.png','鱼香茄子+米饭+例汤',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(43,3,'排骨煲仔饭','主食',25.00,22,'/uploads/menu-images/e1ba7b343c464acfa168c67ba5a84694.png','广式排骨煲仔饭',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(44,4,'烧麦','小吃',5.00,90,'/uploads/menu-images/e1c7de92e3eb4533967c6a815644d482.png','糯米烧麦，一份两个',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(45,5,'鸡丝凉面','主食',12.00,37,'/uploads/menu-images/65460f1ef4614ccca1b4993926d1948f.png','清爽微辣，夏日推荐',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(46,6,'奥尔良鸡翅','小吃',12.00,48,'/uploads/menu-images/fa4018c423294e8bb97dcda6b05f573e.png','现烤鸡翅，香甜微辣',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(47,7,'咖喱鸡盖饭','主食',18.00,34,'/uploads/menu-images/5e133561f2d14c61bc0c6b3a95cf4a30.png','咖喱浓郁，土豆软糯',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39')),(48,8,'芋泥啵啵奶茶','饮料',13.00,42,'/uploads/menu-images/5486464ed2834c23b2ca34e78497c30d.png','芋泥绵密，啵啵Q弹',1,CURDATE(),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '13:02:39'));
CREATE TABLE `cart` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `menu_id` bigint NOT NULL,
  `window_id` bigint NOT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_cart_menu` (`menu_id`),
  KEY `fk_cart_window` (`window_id`),
  KEY `idx_cart_user` (`user_id`),
  CONSTRAINT `fk_cart_menu` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`),
  CONSTRAINT `fk_cart_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`),
  CONSTRAINT `fk_cart_window` FOREIGN KEY (`window_id`) REFERENCES `canteen_window` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `cart` VALUES (8,1,2,1,1,TIMESTAMP(CURDATE(), '14:11:08'),TIMESTAMP(CURDATE(), '14:11:08'));
CREATE TABLE `order_info` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_no` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pickup_number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pickup_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `user_id` bigint NOT NULL,
  `window_id` bigint NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` tinyint NOT NULL DEFAULT '0',
  `pickup_time_slot` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `finish_time` datetime DEFAULT NULL,
  `cancel_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`),
  KEY `idx_order_user` (`user_id`,`status`),
  KEY `idx_order_window` (`window_id`,`status`),
  CONSTRAINT `fk_order_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`),
  CONSTRAINT `fk_order_window` FOREIGN KEY (`window_id`) REFERENCES `canteen_window` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `order_info` VALUES (1,'ORD-DEMO-001','A001','100001',2,1,40.00,5,'11:30-12:00','ALIPAY',NULL,TIMESTAMP(CURDATE(), '00:27:52'),NULL,TIMESTAMP(CURDATE(), '09:29:08'),TIMESTAMP(CURDATE(), '00:27:52')),(2,'ORD-DEMO-002','A002','100002',1,1,18.00,1,'12:00-12:30','WECHAT',TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52'),NULL,NULL,TIMESTAMP(CURDATE(), '00:27:52')),(3,'ORD-DEMO-003','B001','100003',2,2,47.00,2,'12:00-12:30','ALIPAY',TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52'),NULL,NULL,TIMESTAMP(CURDATE(), '00:27:52')),(4,'ORD-DEMO-004','D001','100004',3,4,8.00,3,'11:30-12:00','WECHAT',TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52'),NULL,NULL,TIMESTAMP(CURDATE(), '00:27:52')),(5,'ORD-DEMO-005','E001','100005',1,5,23.00,4,'12:00-12:30','ALIPAY',TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52'),NULL,TIMESTAMP(CURDATE(), '00:27:52')),(6,'ORD-DEMO-006','C001','100006',1,3,20.00,5,'12:00-12:30','ALIPAY',NULL,TIMESTAMP(CURDATE(), '00:27:52'),NULL,TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(7,'ORD-DEMO-007','A003','100007',2,1,41.00,4,'11:30-12:00','ALIPAY',TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52'),NULL,TIMESTAMP(CURDATE(), '00:27:52')),(8,'ORD-DEMO-008','H001','100008',3,8,22.00,5,'12:30-13:00','WECHAT',NULL,TIMESTAMP(CURDATE(), '00:27:52'),NULL,TIMESTAMP(CURDATE(), '09:29:08'),TIMESTAMP(CURDATE(), '00:27:52')),(9,'ORD-DEMO-009','F001','100009',3,6,28.00,4,'12:30-13:00','ALIPAY',TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52'),NULL,TIMESTAMP(CURDATE(), '00:27:52')),(10,'a3938d11a19c42ca','A004','571827',1,1,24.00,4,'11:30-12:00','ALIPAY',TIMESTAMP(CURDATE(), '09:42:05'),TIMESTAMP(CURDATE(), '09:42:00'),TIMESTAMP(CURDATE(), '09:43:24'),NULL,TIMESTAMP(CURDATE(), '09:42:00')),(11,'4dbff08a7f3b48a2','A005','413595',1,1,24.00,4,'11:30-12:00','ALIPAY',TIMESTAMP(CURDATE(), '10:02:14'),TIMESTAMP(CURDATE(), '10:02:12'),TIMESTAMP(CURDATE(), '10:03:01'),NULL,TIMESTAMP(CURDATE(), '10:02:12')),(12,'e67c2a2ba53a4bf6','A006','861607',1,1,24.00,4,'11:30-12:00','WECHAT',TIMESTAMP(CURDATE(), '14:08:54'),TIMESTAMP(CURDATE(), '14:08:31'),TIMESTAMP(CURDATE(), '14:09:50'),NULL,TIMESTAMP(CURDATE(), '14:08:31'));
CREATE TABLE `order_item` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_id` bigint NOT NULL,
  `menu_id` bigint NOT NULL,
  `menu_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_order_item_order` (`order_id`),
  KEY `fk_order_item_menu` (`menu_id`),
  CONSTRAINT `fk_order_item_menu` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`),
  CONSTRAINT `fk_order_item_order` FOREIGN KEY (`order_id`) REFERENCES `order_info` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `order_item` VALUES (35,1,1,'经典麻辣烫',1,18.00,18.00),(36,1,2,'骨汤麻辣烫',1,22.00,22.00),(37,2,1,'经典麻辣烫',1,18.00,18.00),(38,3,4,'红烧肉套餐',1,25.00,25.00),(39,3,5,'宫保鸡丁套餐',1,22.00,22.00),(40,4,9,'鲜肉包子',2,3.00,6.00),(41,4,11,'豆浆',1,2.00,2.00),(42,5,13,'炸酱面',1,13.00,13.00),(43,5,14,'酸辣粉',1,10.00,10.00),(44,6,7,'腊肠煲仔饭',1,20.00,20.00),(45,7,1,'经典麻辣烫',2,18.00,36.00),(46,7,3,'冰镇酸梅汤',1,5.00,5.00),(47,8,21,'珍珠奶茶',1,10.00,10.00),(48,8,24,'抹茶蛋糕',1,12.00,12.00),(49,9,15,'香辣鸡腿堡',1,16.00,16.00),(50,9,16,'薯条',1,8.00,8.00),(51,9,18,'可乐',1,4.00,4.00),(52,10,41,'番茄牛腩麻辣烫',1,24.00,24.00),(53,11,41,'番茄牛腩麻辣烫',1,24.00,24.00),(54,12,41,'番茄牛腩麻辣烫',1,24.00,24.00);
CREATE TABLE `review` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `window_id` bigint NOT NULL,
  `menu_id` bigint DEFAULT NULL,
  `score` tinyint NOT NULL,
  `content` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_content` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_review_order` (`order_id`),
  KEY `fk_review_user` (`user_id`),
  KEY `fk_review_menu` (`menu_id`),
  KEY `idx_review_window` (`window_id`),
  CONSTRAINT `fk_review_menu` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`),
  CONSTRAINT `fk_review_order` FOREIGN KEY (`order_id`) REFERENCES `order_info` (`id`),
  CONSTRAINT `fk_review_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`),
  CONSTRAINT `fk_review_window` FOREIGN KEY (`window_id`) REFERENCES `canteen_window` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `review` VALUES (1,5,1,5,NULL,5,'窗口服务热情，出餐很快','感谢好评，欢迎下次光临！',TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(2,7,2,1,NULL,4,'窗口整体还可以，稍微有点慢','我们会优化出餐速度，谢谢建议',TIMESTAMP(CURDATE(), '00:27:52'),TIMESTAMP(CURDATE(), '00:27:52')),(3,9,3,6,NULL,2,'等待时间偏长，希望改进',NULL,NULL,TIMESTAMP(CURDATE(), '00:27:52')),(4,10,1,1,NULL,5,'难吃，又不便宜','好的，回滚',TIMESTAMP(CURDATE(), '09:51:04'),TIMESTAMP(CURDATE(), '09:50:20')),(5,11,1,1,NULL,5,'好吃,爱吃','+99999',TIMESTAMP(CURDATE(), '10:03:38'),TIMESTAMP(CURDATE(), '10:03:23')),(6,12,1,1,NULL,5,'好吃n+99999','99999',TIMESTAMP(CURDATE(), '14:10:37'),TIMESTAMP(CURDATE(), '14:10:22'));
CREATE TABLE `review_item` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `review_id` bigint NOT NULL,
  `order_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `window_id` bigint NOT NULL,
  `menu_id` bigint NOT NULL,
  `score` tinyint NOT NULL,
  `content` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_review_item_order` (`order_id`),
  KEY `fk_review_item_user` (`user_id`),
  KEY `fk_review_item_window` (`window_id`),
  KEY `idx_review_item_review` (`review_id`),
  KEY `idx_review_item_menu` (`menu_id`),
  CONSTRAINT `fk_review_item_menu` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`),
  CONSTRAINT `fk_review_item_order` FOREIGN KEY (`order_id`) REFERENCES `order_info` (`id`),
  CONSTRAINT `fk_review_item_review` FOREIGN KEY (`review_id`) REFERENCES `review` (`id`),
  CONSTRAINT `fk_review_item_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`),
  CONSTRAINT `fk_review_item_window` FOREIGN KEY (`window_id`) REFERENCES `canteen_window` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `review_item` VALUES (15,1,5,1,5,13,5,'炸酱面太好吃了，分量足味道正宗',TIMESTAMP(CURDATE(), '00:27:52')),(16,1,5,1,5,14,4,'酸辣粉味道不错',TIMESTAMP(CURDATE(), '00:27:52')),(17,2,7,2,1,1,4,'麻辣烫还可以，稍微有点辣',TIMESTAMP(CURDATE(), '00:27:52')),(18,2,7,2,1,3,4,'酸梅汤解辣',TIMESTAMP(CURDATE(), '00:27:52')),(19,3,9,3,6,15,2,'鸡腿堡鸡肉有点干',TIMESTAMP(CURDATE(), '00:27:52')),(20,3,9,3,6,16,2,'薯条软了',TIMESTAMP(CURDATE(), '00:27:52')),(21,3,9,3,6,18,3,'可乐正常',TIMESTAMP(CURDATE(), '00:27:52')),(22,4,10,1,1,41,5,'',TIMESTAMP(CURDATE(), '09:50:20')),(23,5,11,1,1,41,5,'',TIMESTAMP(CURDATE(), '10:03:23')),(24,6,12,1,1,41,5,'',TIMESTAMP(CURDATE(), '14:10:22'));
CREATE TABLE `message` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` tinyint NOT NULL,
  `is_read` tinyint DEFAULT '0',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_message_user` (`user_id`,`is_read`),
  CONSTRAINT `fk_message_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `message` VALUES (16,1,'支付成功','订单 ORD-DEMO-002 已支付，等待窗口制作。请留意订单状态变化。',1,0,TIMESTAMP(CURDATE(), '00:27:52')),(17,1,'订单已完成','您的订单 ORD-DEMO-004 已制作完成，请前往窗口取餐。取餐号：D001，取餐码：100004。',2,0,TIMESTAMP(CURDATE(), '00:27:52')),(18,1,'订单已取消','您的订单 ORD-DEMO-006 因超时未支付已自动取消，已释放占用库存。',3,1,TIMESTAMP(CURDATE(), '00:27:52')),(19,1,'系统通知','欢迎使用校园食堂在线订餐平台！',3,1,TIMESTAMP(CURDATE(), '00:27:52')),(20,2,'支付成功','订单 ORD-DEMO-007 已支付，等待窗口制作。请留意订单状态变化。',1,0,TIMESTAMP(CURDATE(), '00:27:52')),(21,3,'订单已完成','您的订单 ORD-DEMO-009 已制作完成，请前往窗口取餐。取餐号：F001，取餐码：100009。',2,1,TIMESTAMP(CURDATE(), '00:27:52')),(22,2,'订单已取消','您的订单（取餐号：A001）因超时未支付已自动取消。',3,0,TIMESTAMP(CURDATE(), '09:29:07')),(23,3,'订单已取消','您的订单（取餐号：H001）因超时未支付已自动取消。',3,0,TIMESTAMP(CURDATE(), '09:29:07')),(24,1,'支付成功','订单已支付，等待窗口制作',1,0,TIMESTAMP(CURDATE(), '09:42:04')),(25,1,'订单已完成','您的订单已制作完成，请前往窗口取餐。取餐号：A004，取餐码：571827。',2,0,TIMESTAMP(CURDATE(), '09:42:29')),(26,1,'支付成功','订单已支付，等待窗口制作',1,0,TIMESTAMP(CURDATE(), '10:02:14')),(27,1,'订单已完成','您的订单已制作完成，请前往窗口取餐。取餐号：A005，取餐码：413595。',2,0,TIMESTAMP(CURDATE(), '10:02:28')),(28,1,'评价回复通知','您提交的评价已收到管理员回复：+99999',3,1,TIMESTAMP(CURDATE(), '10:03:38')),(29,1,'支付成功','订单已支付，等待窗口制作',1,0,TIMESTAMP(CURDATE(), '14:08:54')),(30,1,'订单已完成','您的订单已制作完成，请前往窗口取餐。取餐号：A006，取餐码：861607。',2,0,TIMESTAMP(CURDATE(), '14:09:07')),(31,1,'评价回复通知','您提交的评价已收到管理员回复：99999',3,0,TIMESTAMP(CURDATE(), '14:10:36'));

SET FOREIGN_KEY_CHECKS = 1;
