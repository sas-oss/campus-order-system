package com.ordersystem.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ordersystem.common.BusinessException;
import com.ordersystem.common.ErrorCode;
import com.ordersystem.dto.*;
import com.ordersystem.entity.Canteen;
import com.ordersystem.entity.OrderInfo;
import com.ordersystem.entity.Window;
import com.ordersystem.mapper.CanteenMapper;
import com.ordersystem.mapper.OrderInfoMapper;
import com.ordersystem.mapper.WindowMapper;
import com.ordersystem.service.CanteenService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 食堂服务实现
 */
@Service
@RequiredArgsConstructor
public class CanteenServiceImpl implements CanteenService {

    private final CanteenMapper canteenMapper;
    private final WindowMapper windowMapper;
    private final OrderInfoMapper orderInfoMapper;

    @Override
    public List<CanteenVO> listAll() {
        LambdaQueryWrapper<Canteen> wrapper = new LambdaQueryWrapper<>();
        wrapper.orderByDesc(Canteen::getId);
        List<Canteen> canteens = canteenMapper.selectList(wrapper);

        return canteens.stream().map(canteen -> {
            CanteenVO vo = new CanteenVO();
            vo.setId(canteen.getId());
            vo.setName(canteen.getName());
            vo.setAddress(canteen.getAddress());
            vo.setDescription(canteen.getDescription());
            vo.setStatus(canteen.getStatus());
            vo.setCreateTime(canteen.getCreateTime());

            // 关联查询窗口列表
            LambdaQueryWrapper<Window> winWrapper = new LambdaQueryWrapper<>();
            winWrapper.eq(Window::getCanteenId, canteen.getId());
            winWrapper.eq(Window::getStatus, 1);
            winWrapper.orderByAsc(Window::getFloor, Window::getId);
            List<Window> windows = windowMapper.selectList(winWrapper);

            List<CanteenVO.WindowSimpleVO> windowVOs = windows.stream().map(w -> {
                CanteenVO.WindowSimpleVO wvo = new CanteenVO.WindowSimpleVO();
                wvo.setId(w.getId());
                wvo.setName(w.getName());
                wvo.setFloor(w.getFloor());
                wvo.setPickupNumberPrefix(w.getPickupNumberPrefix());
                wvo.setStatus(w.getStatus());
                return wvo;
            }).collect(Collectors.toList());
            vo.setWindows(windowVOs);
            vo.setOrderCount(countOrders(windows));
            vo.setTotalOrders(vo.getOrderCount());

            return vo;
        }).collect(Collectors.toList());
    }

    @Override
    public CanteenVO getById(Long id) {
        Canteen canteen = canteenMapper.selectById(id);
        if (canteen == null) {
            throw new BusinessException(ErrorCode.CANTEEN_NOT_FOUND);
        }

        CanteenVO vo = new CanteenVO();
        vo.setId(canteen.getId());
        vo.setName(canteen.getName());
        vo.setAddress(canteen.getAddress());
        vo.setDescription(canteen.getDescription());
        vo.setStatus(canteen.getStatus());
        vo.setCreateTime(canteen.getCreateTime());

        LambdaQueryWrapper<Window> winWrapper = new LambdaQueryWrapper<>();
        winWrapper.eq(Window::getCanteenId, canteen.getId());
        winWrapper.eq(Window::getStatus, 1);
        winWrapper.orderByAsc(Window::getFloor, Window::getId);
        List<Window> windows = windowMapper.selectList(winWrapper);

        List<CanteenVO.WindowSimpleVO> windowVOs = windows.stream().map(w -> {
            CanteenVO.WindowSimpleVO wvo = new CanteenVO.WindowSimpleVO();
            wvo.setId(w.getId());
            wvo.setName(w.getName());
            wvo.setFloor(w.getFloor());
            wvo.setPickupNumberPrefix(w.getPickupNumberPrefix());
            wvo.setStatus(w.getStatus());
            return wvo;
        }).collect(Collectors.toList());
        vo.setWindows(windowVOs);
        vo.setOrderCount(countOrders(windows));
        vo.setTotalOrders(vo.getOrderCount());

        return vo;
    }

    @Override
    public void create(CanteenRequest request, Long operatorId) {
        Canteen canteen = new Canteen();
        canteen.setName(request.getName());
        canteen.setAddress(request.getAddress());
        canteen.setDescription(request.getDescription());
        canteen.setStatus(1);
        canteenMapper.insert(canteen);
    }

    @Override
    public void update(Long id, CanteenRequest request, Long operatorId) {
        Canteen canteen = canteenMapper.selectById(id);
        if (canteen == null) {
            throw new BusinessException(ErrorCode.CANTEEN_NOT_FOUND);
        }
        canteen.setName(request.getName());
        canteen.setAddress(request.getAddress());
        canteen.setDescription(request.getDescription());
        canteenMapper.updateById(canteen);
    }

    @Override
    public void delete(Long id, Long operatorId) {
        Canteen canteen = canteenMapper.selectById(id);
        if (canteen == null) {
            throw new BusinessException(ErrorCode.CANTEEN_NOT_FOUND);
        }
        canteenMapper.deleteById(id);
    }

    private Long countOrders(List<Window> windows) {
        if (windows.isEmpty()) {
            return 0L;
        }
        return orderInfoMapper.selectCount(new LambdaQueryWrapper<OrderInfo>()
                .in(OrderInfo::getWindowId, windows.stream().map(Window::getId).toList()));
    }
}
