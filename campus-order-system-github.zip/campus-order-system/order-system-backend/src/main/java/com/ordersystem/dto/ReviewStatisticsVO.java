package com.ordersystem.dto;

import lombok.Data;

@Data
public class ReviewStatisticsVO {
    private Long windowId;
    private String windowName;
    private Long canteenId;
    private String canteenName;
    private Double averageScore;
    private Long totalReviews;
    private Long negativeReviews;
}
