package com.ordersystem.dto;

import lombok.Data;

import java.math.BigDecimal;

/**
 * AI 推荐菜品视图，比 MenuVO 多推荐理由字段
 */
@Data
public class AiRecommendationVO {

    private Long id;
    private Long windowId;
    private String windowName;
    private Long canteenId;
    private String canteenName;
    private String name;
    private String category;
    private BigDecimal price;
    private Integer stock;

    /** 是否售罄（库存 <= 0） */
    private Boolean soldOut;

    private String imageUrl;
    private String description;

    /** AI 推荐理由，失败时用本地兜底文案 */
    private String reason;
}
