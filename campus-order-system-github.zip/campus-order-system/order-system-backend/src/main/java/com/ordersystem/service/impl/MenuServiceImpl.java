package com.ordersystem.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ordersystem.common.BusinessException;
import com.ordersystem.common.ErrorCode;
import com.ordersystem.common.PageResult;
import com.ordersystem.dto.MenuQueryDTO;
import com.ordersystem.dto.MenuRequest;
import com.ordersystem.dto.MenuVO;
import com.ordersystem.entity.Canteen;
import com.ordersystem.entity.Menu;
import com.ordersystem.entity.SysUser;
import com.ordersystem.entity.Window;
import com.ordersystem.mapper.CanteenMapper;
import com.ordersystem.mapper.MenuMapper;
import com.ordersystem.mapper.SysUserMapper;
import com.ordersystem.mapper.WindowMapper;
import com.ordersystem.service.MenuService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MenuServiceImpl implements MenuService {

    private final MenuMapper menuMapper;
    private final WindowMapper windowMapper;
    private final CanteenMapper canteenMapper;
    private final SysUserMapper sysUserMapper;

    @Override
    public PageResult<MenuVO> listMenus(MenuQueryDTO query, int page, int size) {
        Page<Menu> requestPage = new Page<>(Math.max(page, 1), Math.max(size, 10));
        List<Long> canteenWindowIds = resolveWindowIds(query.getCanteenId());
        if (query.getCanteenId() != null && canteenWindowIds.isEmpty()) {
            return new PageResult<>(Collections.emptyList(), 0, requestPage.getCurrent(), requestPage.getSize());
        }

        Page<Menu> result;
        if (query.getAllDates() == null || !query.getAllDates()) {
            LocalDate targetDate = query.getSaleDate() == null ? LocalDate.now() : query.getSaleDate();
            result = menuMapper.selectPage(requestPage, buildMenuWrapper(query, canteenWindowIds, targetDate));
            if (query.getSaleDate() == null && result.getRecords().isEmpty()) {
                LocalDate fallbackDate = findLatestSaleDate(query, canteenWindowIds);
                if (fallbackDate != null && !fallbackDate.equals(targetDate)) {
                    result = menuMapper.selectPage(requestPage, buildMenuWrapper(query, canteenWindowIds, fallbackDate));
                }
            }
        } else {
            result = menuMapper.selectPage(requestPage, buildMenuWrapper(query, canteenWindowIds, query.getSaleDate()));
        }

        return new PageResult<>(assembleMenuVOs(result.getRecords()), result.getTotal(), result.getCurrent(), result.getSize());
    }

    @Override
    public MenuVO getMenuById(Long id) {
        Menu menu = menuMapper.selectById(id);
        if (menu == null) {
            throw new BusinessException(ErrorCode.MENU_NOT_FOUND);
        }
        return assembleMenuVOs(List.of(menu)).get(0);
    }

    @Override
    public void createMenu(MenuRequest request, Long adminId) {
        validateWindowAccess(adminId, request.getWindowId());
        Menu menu = new Menu();
        fillMenu(menu, request);
        menu.setStatus(1);
        menu.setSaleDate(request.getSaleDate() == null ? LocalDate.now() : request.getSaleDate());
        menuMapper.insert(menu);
    }

    @Override
    public void updateMenu(Long id, MenuRequest request, Long adminId) {
        Menu menu = menuMapper.selectById(id);
        if (menu == null) {
            throw new BusinessException(ErrorCode.MENU_NOT_FOUND);
        }
        validateWindowAccess(adminId, menu.getWindowId());
        validateWindowAccess(adminId, request.getWindowId());
        fillMenu(menu, request);
        if (request.getSaleDate() == null) {
            menu.setSaleDate(menu.getSaleDate() == null ? LocalDate.now() : menu.getSaleDate());
        }
        menuMapper.updateById(menu);
    }

    @Override
    public void deleteMenu(Long id, Long adminId) {
        Menu menu = menuMapper.selectById(id);
        if (menu == null) {
            throw new BusinessException(ErrorCode.MENU_NOT_FOUND);
        }
        validateWindowAccess(adminId, menu.getWindowId());
        menuMapper.deleteById(id);
    }

    @Override
    public void updateStock(Long id, Integer stock) {
        Menu menu = menuMapper.selectById(id);
        if (menu == null) {
            throw new BusinessException(ErrorCode.MENU_NOT_FOUND);
        }
        menu.setStock(stock);
        menuMapper.updateById(menu);
    }

    @Override
    public List<MenuVO> getTodayMenusByWindow(Long windowId) {
        List<Menu> todayMenus = menuMapper.selectList(new LambdaQueryWrapper<Menu>()
                .eq(Menu::getWindowId, windowId)
                .eq(Menu::getStatus, 1)
                .eq(Menu::getSaleDate, LocalDate.now())
                .orderByDesc(Menu::getId));
        if (!todayMenus.isEmpty()) {
            return assembleMenuVOs(todayMenus);
        }

        List<Menu> fallbackMenus = menuMapper.selectList(new LambdaQueryWrapper<Menu>()
                .eq(Menu::getWindowId, windowId)
                .eq(Menu::getStatus, 1)
                .orderByDesc(Menu::getSaleDate)
                .orderByDesc(Menu::getId)
                .last("LIMIT 1"));
        if (fallbackMenus.isEmpty() || fallbackMenus.get(0).getSaleDate() == null) {
            return Collections.emptyList();
        }
        LocalDate fallbackDate = fallbackMenus.get(0).getSaleDate();

        return assembleMenuVOs(menuMapper.selectList(new LambdaQueryWrapper<Menu>()
                .eq(Menu::getWindowId, windowId)
                .eq(Menu::getStatus, 1)
                .eq(Menu::getSaleDate, fallbackDate)
                .orderByDesc(Menu::getId)));
    }

    private void validateWindowAccess(Long adminId, Long windowId) {
        SysUser user = sysUserMapper.selectById(adminId);
        if (user == null) {
            throw new BusinessException(ErrorCode.USER_NOT_FOUND);
        }
    }

    private void fillMenu(Menu menu, MenuRequest request) {
        menu.setWindowId(request.getWindowId());
        menu.setName(request.getName());
        menu.setCategory(request.getCategory());
        menu.setPrice(request.getPrice());
        menu.setStock(request.getStock());
        String imageUrl = request.getImageUrl();
        if (imageUrl != null) {
            menu.setImageUrl(imageUrl.isBlank() ? "" : imageUrl);
        }
        menu.setDescription(request.getDescription());
        if (request.getSaleDate() != null) {
            menu.setSaleDate(request.getSaleDate());
        }
    }

    private List<Long> resolveWindowIds(Long canteenId) {
        if (canteenId == null) {
            return Collections.emptyList();
        }
        return windowMapper.selectList(new LambdaQueryWrapper<Window>().eq(Window::getCanteenId, canteenId))
                .stream()
                .map(Window::getId)
                .toList();
    }

    private LambdaQueryWrapper<Menu> buildMenuWrapper(MenuQueryDTO query, List<Long> canteenWindowIds, LocalDate saleDate) {
        LambdaQueryWrapper<Menu> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Menu::getStatus, 1);
        if (saleDate != null) {
            wrapper.eq(Menu::getSaleDate, saleDate);
        }
        if (query.getWindowId() != null) {
            wrapper.eq(Menu::getWindowId, query.getWindowId());
        } else if (query.getCanteenId() != null && !canteenWindowIds.isEmpty()) {
            wrapper.in(Menu::getWindowId, canteenWindowIds);
        }
        if (query.getCategory() != null && !query.getCategory().isBlank()) {
            wrapper.eq(Menu::getCategory, query.getCategory());
        }
        if (query.getKeyword() != null && !query.getKeyword().isBlank()) {
            wrapper.like(Menu::getName, query.getKeyword());
        }
        wrapper.orderByAsc(Menu::getWindowId).orderByDesc(Menu::getId);
        return wrapper;
    }

    private LocalDate findLatestSaleDate(MenuQueryDTO query, List<Long> canteenWindowIds) {
        List<Menu> fallbackMenus = menuMapper.selectList(buildMenuWrapper(query, canteenWindowIds, null)
                .orderByDesc(Menu::getSaleDate)
                .orderByDesc(Menu::getId)
                .last("LIMIT 1"));
        if (fallbackMenus.isEmpty()) {
            return null;
        }
        return fallbackMenus.get(0).getSaleDate();
    }

    private List<MenuVO> assembleMenuVOs(List<Menu> menus) {
        Map<Long, Window> windowMap = windowMapper.selectList(new LambdaQueryWrapper<>()).stream()
                .collect(Collectors.toMap(Window::getId, Function.identity(), (left, right) -> left));
        Map<Long, Canteen> canteenMap = canteenMapper.selectList(new LambdaQueryWrapper<>()).stream()
                .collect(Collectors.toMap(Canteen::getId, Function.identity(), (left, right) -> left));

        return menus.stream().map(menu -> {
            MenuVO menuVO = new MenuVO();
            menuVO.setId(menu.getId());
            menuVO.setWindowId(menu.getWindowId());
            menuVO.setName(menu.getName());
            menuVO.setCategory(menu.getCategory());
            menuVO.setPrice(menu.getPrice());
            menuVO.setStock(menu.getStock());
            menuVO.setSoldOut(menu.getStock() == null || menu.getStock() <= 0);
            menuVO.setImageUrl(menu.getImageUrl());
            menuVO.setDescription(menu.getDescription());
            menuVO.setStatus(menu.getStatus());
            menuVO.setSaleDate(menu.getSaleDate());
            menuVO.setCreateTime(menu.getCreateTime());

            Window window = windowMap.get(menu.getWindowId());
            if (window != null) {
                menuVO.setWindowName(window.getName());
                menuVO.setCanteenId(window.getCanteenId());
                Canteen canteen = canteenMap.get(window.getCanteenId());
                if (canteen != null) {
                    menuVO.setCanteenName(canteen.getName());
                }
            }
            return menuVO;
        }).toList();
    }
}
