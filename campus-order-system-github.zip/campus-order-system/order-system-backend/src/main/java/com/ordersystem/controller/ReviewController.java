package com.ordersystem.controller;

import com.ordersystem.common.Result;
import com.ordersystem.dto.ReviewReplyRequest;
import com.ordersystem.dto.ReviewRequest;
import com.ordersystem.service.ReviewService;
import com.ordersystem.service.SysUserService;
import com.ordersystem.utils.AuthUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@Tag(name = "评价管理")
@RestController
@RequestMapping("/api/reviews")
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;
    private final SysUserService sysUserService;

    @PostMapping
    @Operation(summary = "提交评价")
    public Result<?> create(@RequestAttribute("userId") Long userId,
                            @RequestAttribute("role") String role,
                            @Valid @RequestBody ReviewRequest request) {
        AuthUtil.requireRole(role, "STUDENT");
        reviewService.submitReview(userId, request);
        return Result.success();
    }

    @GetMapping("/my")
    @Operation(summary = "我的评价")
    public Result<?> my(@RequestAttribute("userId") Long userId,
                        @RequestAttribute("role") String role,
                        @RequestParam(defaultValue = "1") int page,
                        @RequestParam(defaultValue = "10") int size) {
        AuthUtil.requireRole(role, "STUDENT");
        return Result.success(reviewService.listMyReviews(userId, page, size));
    }

    @GetMapping("/window/{windowId}")
    @Operation(summary = "窗口评价列表")
    public Result<?> windowReviews(@PathVariable Long windowId,
                                   @RequestAttribute("role") String role,
                                   @RequestParam(defaultValue = "1") int page,
                                   @RequestParam(defaultValue = "10") int size) {
        AuthUtil.requireAnyRole(role, "CANTEEN_ADMIN", "SYSTEM_ADMIN");
        return Result.success(reviewService.listWindowReviews(windowId, page, size));
    }

    @PutMapping("/{id}/reply")
    @Operation(summary = "回复评价")
    public Result<?> reply(@PathVariable Long id,
                           @RequestAttribute("userId") Long userId,
                           @RequestAttribute("role") String role,
                           @Valid @RequestBody ReviewReplyRequest request) {
        AuthUtil.requireAnyRole(role, "CANTEEN_ADMIN", "SYSTEM_ADMIN");
        reviewService.replyReview(id, request.getContent(), userId);
        return Result.success();
    }

    @GetMapping("/statistics")
    @Operation(summary = "全部评价统计")
    public Result<?> allStatistics(@RequestAttribute("role") String role) {
        AuthUtil.requireRole(role, "SYSTEM_ADMIN");
        return Result.success(reviewService.getAllStatistics());
    }

    @GetMapping("/statistics/window/{windowId}")
    @Operation(summary = "窗口评价统计")
    public Result<?> windowStatistics(@PathVariable Long windowId,
                                      @RequestAttribute("role") String role) {
        AuthUtil.requireAnyRole(role, "CANTEEN_ADMIN", "SYSTEM_ADMIN");
        return Result.success(reviewService.getWindowStatistics(windowId));
    }
}
