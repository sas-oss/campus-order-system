package com.ordersystem.service;

import com.ordersystem.common.PageResult;
import com.ordersystem.dto.MessageVO;

public interface MessageService {
    void createMessage(Long userId, String title, String content, Integer type);
    PageResult<MessageVO> listByUser(Long userId, int page, int size);
    Integer getUnreadCount(Long userId);
    void markAsRead(Long id, Long userId);
    void markAllAsRead(Long userId);
}
