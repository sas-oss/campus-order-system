package com.ordersystem.controller;

import com.ordersystem.common.Result;
import com.ordersystem.dto.CartItemRequest;
import com.ordersystem.service.CartService;
import com.ordersystem.utils.AuthUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@Tag(name = "购物车", description = "学生购物车操作")
@RestController
@RequestMapping("/api/cart")
@RequiredArgsConstructor
public class CartController {

    private final CartService cartService;

    @GetMapping
    @Operation(summary = "获取购物车")
    public Result<?> getCart(@RequestAttribute("userId") Long userId,
                             @RequestAttribute("role") String role) {
        AuthUtil.requireRole(role, "STUDENT");
        return Result.success(cartService.getCart(userId));
    }

    @PostMapping("/items")
    @Operation(summary = "添加购物车")
    public Result<?> addToCart(@RequestAttribute("userId") Long userId,
                               @RequestAttribute("role") String role,
                               @Valid @RequestBody CartItemRequest request) {
        AuthUtil.requireRole(role, "STUDENT");
        cartService.addToCart(userId, request);
        return Result.success();
    }

    @PutMapping("/items/{id}")
    @Operation(summary = "更新购物车数量")
    public Result<?> updateQuantity(@RequestAttribute("userId") Long userId,
                                    @RequestAttribute("role") String role,
                                    @PathVariable Long id,
                                    @RequestBody Map<String, Integer> body) {
        AuthUtil.requireRole(role, "STUDENT");
        cartService.updateQuantity(userId, id, body.getOrDefault("quantity", 1));
        return Result.success();
    }

    @DeleteMapping("/items/{id}")
    @Operation(summary = "删除购物车项")
    public Result<?> remove(@RequestAttribute("userId") Long userId,
                            @RequestAttribute("role") String role,
                            @PathVariable Long id) {
        AuthUtil.requireRole(role, "STUDENT");
        cartService.removeItem(userId, id);
        return Result.success();
    }

    @DeleteMapping("/clear")
    @Operation(summary = "清空购物车")
    public Result<?> clear(@RequestAttribute("userId") Long userId,
                           @RequestAttribute("role") String role) {
        AuthUtil.requireRole(role, "STUDENT");
        cartService.clearCart(userId);
        return Result.success();
    }
}
