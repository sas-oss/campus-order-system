package com.ordersystem.service;

import com.ordersystem.dto.*;
import java.util.List;

/**
 * 食堂服务接口
 */
public interface CanteenService {
    List<CanteenVO> listAll();
    CanteenVO getById(Long id);
    void create(CanteenRequest request, Long operatorId);
    void update(Long id, CanteenRequest request, Long operatorId);
    void delete(Long id, Long operatorId);
}
