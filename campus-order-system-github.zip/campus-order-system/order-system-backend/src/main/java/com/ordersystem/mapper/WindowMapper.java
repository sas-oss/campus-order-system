package com.ordersystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ordersystem.entity.Window;
import org.apache.ibatis.annotations.Mapper;

/**
 * 窗口 Mapper
 */
@Mapper
public interface WindowMapper extends BaseMapper<Window> {
}
