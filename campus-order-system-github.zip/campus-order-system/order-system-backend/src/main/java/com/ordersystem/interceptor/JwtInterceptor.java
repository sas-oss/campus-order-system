package com.ordersystem.interceptor;

import com.ordersystem.common.BusinessException;
import com.ordersystem.common.ErrorCode;
import com.ordersystem.config.JwtUtils;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * JWT 拦截器：校验 /api/** 请求的 Bearer Token，将 userId/username/role 注入 request。
 * 放行：OPTIONS、login、register、食堂/菜单 GET 查询、swagger 文档。
 */
@Component
@RequiredArgsConstructor
public class JwtInterceptor implements HandlerInterceptor {

    private final JwtUtils jwtUtils;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) return true;
        if (isPublicReadRequest(request)) return true;

        String token = request.getHeader("Authorization");
        if (token == null || !token.startsWith("Bearer ")) {
            throw new BusinessException(ErrorCode.UNAUTHORIZED);
        }

        token = token.substring(7);
        if (!jwtUtils.validateToken(token)) {
            throw new BusinessException(ErrorCode.UNAUTHORIZED);
        }

        // 将用户信息写入 request attribute，后续 Controller 通过 @RequestAttribute 获取
        request.setAttribute("userId", jwtUtils.getUserIdFromToken(token));
        request.setAttribute("username", jwtUtils.getUsernameFromToken(token));
        request.setAttribute("role", jwtUtils.getRoleFromToken(token));
        return true;
    }

    /** 公开只读接口：食堂和菜单的 GET 请求无需登录 */
    private boolean isPublicReadRequest(HttpServletRequest request) {
        if (!"GET".equalsIgnoreCase(request.getMethod())) return false;
        String path = request.getRequestURI();
        return path.equals("/api/canteens")
                || path.startsWith("/api/canteens/")
                || path.equals("/api/menus")
                || path.startsWith("/api/menus/");
    }
}
