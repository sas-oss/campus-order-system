package com.ordersystem.controller;

import com.ordersystem.common.Result;
import com.ordersystem.dto.LoginRequest;
import com.ordersystem.dto.PasswordChangeRequest;
import com.ordersystem.dto.ProfileUpdateRequest;
import com.ordersystem.dto.RegisterRequest;
import com.ordersystem.service.SysUserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@Tag(name = "认证模块", description = "用户注册、登录、个人信息管理")
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final SysUserService sysUserService;

    @Operation(summary = "用户登录")
    @PostMapping("/login")
    public Result<?> login(@Valid @RequestBody LoginRequest request) {
        SysUserService.LoginResponse response = sysUserService.login(request);
        return Result.success(Map.of(
                "token", response.getToken(),
                "role", response.getRole(),
                "userInfo", response.getUserInfo()
        ));
    }

    @Operation(summary = "用户注册")
    @PostMapping("/register")
    public Result<?> register(@Valid @RequestBody RegisterRequest request) {
        sysUserService.register(request);
        return Result.success("注册成功");
    }

    @Operation(summary = "获取当前用户信息")
    @GetMapping("/profile")
    public Result<?> getProfile(@RequestAttribute("userId") Long userId) {
        return Result.success(sysUserService.getProfile(userId));
    }

    @Operation(summary = "更新个人信息")
    @PutMapping("/profile")
    public Result<?> updateProfile(@RequestAttribute("userId") Long userId,
                                   @RequestBody ProfileUpdateRequest request) {
        sysUserService.updateProfile(userId, request);
        return Result.success("更新成功");
    }

    @Operation(summary = "修改密码")
    @PutMapping("/password")
    public Result<?> changePassword(@RequestAttribute("userId") Long userId,
                                    @Valid @RequestBody PasswordChangeRequest request) {
        sysUserService.changePassword(userId, request);
        return Result.success("密码修改成功");
    }
}
