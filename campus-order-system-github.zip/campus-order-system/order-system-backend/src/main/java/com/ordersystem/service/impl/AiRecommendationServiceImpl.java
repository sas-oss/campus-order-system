package com.ordersystem.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ordersystem.dto.AiMealAssistantRequest;
import com.ordersystem.dto.AiMealAssistantResponse;
import com.ordersystem.dto.AiMenuCandidate;
import com.ordersystem.dto.AiRecommendationVO;
import com.ordersystem.entity.Canteen;
import com.ordersystem.entity.Menu;
import com.ordersystem.entity.Window;
import com.ordersystem.mapper.CanteenMapper;
import com.ordersystem.mapper.MenuMapper;
import com.ordersystem.mapper.WindowMapper;
import com.ordersystem.service.AiClient;
import com.ordersystem.service.AiRecommendationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * AI 推荐服务实现。
 *
 * 核心设计："本地规则做主菜，AI 做调料"——菜品筛选、打分、组合由本地算法完成，
 * AI 只负责生成推荐理由和自然语言回复。AI 不可用时系统功能完全不受影响。
 *
 * 推荐算法流水线（5 步）：
 * 1. 候选筛选：查询在售有库存菜品，优先当天上架
 * 2. 预算过滤：剔除超出预算的菜品
 * 3. 同窗口贪心选取：按窗口分组，每组选取得分最高的 1-2 个菜品
 * 4. 窗口间竞争：选得分总和最高且总价最低的窗口组合
 * 5. AI 润色：调用 AI 生成推荐理由/回复，失败则本地兜底
 *
 * 打分规则（执行顺序无关，各维度独立累加）：
 *   辣味匹配 +8    清淡偏好 +5    管饱/午餐 +5
 *   赶时间   +3    饮料需求 +4    低价需求  +4    库存充足 +1
 */
@Service
@RequiredArgsConstructor
public class AiRecommendationServiceImpl implements AiRecommendationService {

    private final MenuMapper menuMapper;
    private final WindowMapper windowMapper;
    private final CanteenMapper canteenMapper;
    private final AiClient aiClient;

    /**
     * 获取今日推荐菜品。
     * 两级降级查询：当天上架 → 全部在售 → 空列表。
     * AI 推荐理由优先，不可用时每个菜品单独给本地兜底理由。
     */
    @Override
    public List<AiRecommendationVO> getTodayRecommendations(int limit) {
        // 限制推荐数量 1-6，前端默认传 6，AI 推荐接口默认传 3
        int useLimit = Math.min(Math.max(limit, 1), 6);

        // 两级降级：当天菜品 → 全部在售
        List<Menu> menus = selectTodayMenus(useLimit);
        if (menus.isEmpty()) {
            menus = selectAvailableMenus(useLimit);
        }
        if (menus.isEmpty()) {
            return List.of();
        }

        // 批量加载窗口和食堂，构建 ID→实体 映射
        Map<Long, Window> windowMap = windowMapper.selectList(new LambdaQueryWrapper<Window>()).stream()
                .collect(Collectors.toMap(Window::getId, Function.identity(), (left, right) -> left));
        Map<Long, Canteen> canteenMap = canteenMapper.selectList(new LambdaQueryWrapper<Canteen>()).stream()
                .collect(Collectors.toMap(Canteen::getId, Function.identity(), (left, right) -> left));

        // Menu → AiRecommendationVO，同时填充窗口和食堂名称
        List<AiRecommendationVO> recommendations = menus.stream()
                .map(menu -> toRecommendation(menu, windowMap, canteenMap))
                .toList();

        // 调用 AI 生成推荐理由，RuntimeException 或网络异常均静默降级
        Map<Long, String> generatedReasons;
        try {
            generatedReasons = aiClient.generateRecommendationReasons(toCandidates(recommendations));
        } catch (RuntimeException ex) {
            generatedReasons = Map.of();
        }
        Map<Long, String> aiReasons = generatedReasons;

        // 逐菜品设置理由：AI 优先，本地兜底
        recommendations.forEach(item -> item.setReason(aiReasons.getOrDefault(item.getId(), fallbackReason(item))));
        return recommendations;
    }

    /**
     * AI 点餐助手：从自然语言需求到推荐搭配的完整流程。
     *
     * 降级链路（3 层）：
     * 1. 无在售菜品 → 返回空推荐提示
     * 2. 预算内无菜品 → 降级为取最便宜的 1 个
     * 3. AI 回复失败 → 本地模版拼接
     */
    @Override
    public AiMealAssistantResponse createMealPlan(AiMealAssistantRequest request) {
        AiMealAssistantRequest useRequest = request == null ? new AiMealAssistantRequest() : request;
        BigDecimal budget = effectiveBudget(useRequest);  // 三级预算解析

        // 查询在售菜品，取 24 个保证覆盖面
        List<Menu> menus = selectAvailableMenus(24);
        if (menus.isEmpty()) {
            AiMealAssistantResponse empty = new AiMealAssistantResponse();
            empty.setReply("AI 暂时没有找到可推荐的在售菜品，可以稍后再试。");
            empty.setTotalAmount(BigDecimal.ZERO);
            empty.setMatchedTags(matchedTags(useRequest));
            empty.setMenus(List.of());
            return empty;
        }

        // 批量加载窗口和食堂
        Map<Long, Window> windowMap = windowMapper.selectList(new LambdaQueryWrapper<Window>()).stream()
                .collect(Collectors.toMap(Window::getId, Function.identity(), (left, right) -> left));
        Map<Long, Canteen> canteenMap = canteenMapper.selectList(new LambdaQueryWrapper<Canteen>()).stream()
                .collect(Collectors.toMap(Canteen::getId, Function.identity(), (left, right) -> left));

        // Step 1-2：转换 VO + 预算过滤，无结果时降级取最便宜的 1 个
        List<AiRecommendationVO> candidates = menus.stream()
                .map(menu -> toRecommendation(menu, windowMap, canteenMap))
                .filter(menu -> menu.getPrice() != null && menu.getPrice().compareTo(budget) <= 0)
                .toList();
        if (candidates.isEmpty()) {
            candidates = menus.stream()
                    .map(menu -> toRecommendation(menu, windowMap, canteenMap))
                    .sorted(Comparator.comparing(AiRecommendationVO::getPrice))
                    .limit(1)
                    .toList();
        }

        // Step 3-4：同窗口贪心选取最佳搭配
        List<AiRecommendationVO> selectedMenus = selectBestSameWindowMeal(candidates, useRequest, budget);

        // Step 5：AI 生成推荐回复，失败用本地模版
        String reply;
        try {
            reply = aiClient.generateMealAssistantReply(useRequest, toCandidates(candidates), toCandidates(selectedMenus));
        } catch (RuntimeException ex) {
            reply = "";
        }
        if (reply == null || reply.isBlank()) {
            reply = fallbackMealReply(useRequest, selectedMenus);
        }

        // 组装响应：所有推荐菜品同属一个窗口，前端可直接展示
        AiMealAssistantResponse response = new AiMealAssistantResponse();
        response.setReply(reply);
        response.setTotalAmount(totalAmount(selectedMenus));
        response.setMatchedTags(matchedTags(useRequest));
        response.setMenus(selectedMenus);
        if (!selectedMenus.isEmpty()) {
            AiRecommendationVO first = selectedMenus.get(0);
            response.setWindowId(first.getWindowId());
            response.setWindowName(first.getWindowName());
            response.setCanteenId(first.getCanteenId());
            response.setCanteenName(first.getCanteenName());
        }
        return response;
    }

    /** 查询当天上架、状态正常、库存大于 0 的菜品 */
    private List<Menu> selectTodayMenus(int limit) {
        return menuMapper.selectList(new LambdaQueryWrapper<Menu>()
                .eq(Menu::getStatus, 1)
                .eq(Menu::getSaleDate, LocalDate.now())
                .gt(Menu::getStock, 0)
                .orderByDesc(Menu::getStock)
                .orderByDesc(Menu::getId)
                .last("LIMIT " + limit));
    }

    /** 查询所有在售有库存的菜品，不限当天 */
    private List<Menu> selectAvailableMenus(int limit) {
        return menuMapper.selectList(new LambdaQueryWrapper<Menu>()
                .eq(Menu::getStatus, 1)
                .gt(Menu::getStock, 0)
                .orderByDesc(Menu::getSaleDate)
                .orderByDesc(Menu::getStock)
                .orderByDesc(Menu::getId)
                .last("LIMIT " + limit));
    }

    /**
     * 在所有候选菜品中选择最佳同窗口搭配。
     * 优先同窗口的原因：学生只需跑一个窗口取餐，不用跨窗口奔波。
     * 选择策略：各窗口组独立贪心选取 → 得分总和最高且总价最低的胜出。
     */
    private static List<AiRecommendationVO> selectBestSameWindowMeal(List<AiRecommendationVO> candidates,
                                                                     AiMealAssistantRequest request,
                                                                     BigDecimal budget) {
        return candidates.stream()
                .collect(Collectors.groupingBy(AiRecommendationVO::getWindowId))  // 按窗口分组
                .values().stream()
                .map(group -> selectWithinBudget(group, request, budget))          // 各组内贪心选取
                .filter(group -> !group.isEmpty())
                .max(Comparator
                        .comparingInt((List<AiRecommendationVO> group) ->
                                group.stream().mapToInt(item -> score(item, request)).sum())  // 优先比分总和
                        .thenComparing(group -> totalAmount(group)))                          // 得分相同比总价
                .orElse(List.of());
    }

    /**
     * 单窗口内贪心选取算法：
     * 1. 按得分降序 + 价格升序排序（得分相同时优先便宜的）
     * 2. 依次尝试加入购物篮，预算不够则跳过
     * 3. 最多选 2 个菜品（一餐合理搭配上限）
     * 4. 最终按分类优先级（主食 → 小吃 → 饮料）排序输出
     */
    private static List<AiRecommendationVO> selectWithinBudget(List<AiRecommendationVO> group,
                                                               AiMealAssistantRequest request,
                                                               BigDecimal budget) {
        BigDecimal remaining = budget;
        // 按得分降序、价格升序排列
        List<AiRecommendationVO> sorted = group.stream()
                .sorted(Comparator
                        .comparingInt((AiRecommendationVO item) -> score(item, request)).reversed()
                        .thenComparing(AiRecommendationVO::getPrice))
                .toList();
        // 贪心选取：够预算就加入，最多 2 个
        java.util.ArrayList<AiRecommendationVO> selected = new java.util.ArrayList<>();
        for (AiRecommendationVO item : sorted) {
            if (selected.size() >= 2) break;
            if (item.getPrice() != null && item.getPrice().compareTo(remaining) <= 0) {
                selected.add(item);
                remaining = remaining.subtract(item.getPrice());
            }
        }
        // 按主食 > 小吃 > 饮料排序
        selected.sort(Comparator
                .comparingInt(AiRecommendationServiceImpl::categoryPriority)
                .thenComparing(AiRecommendationVO::getId));
        return selected;
    }

    /** 分类优先级：主食(0) > 小吃(1) > 饮料(2) > 其他(3) */
    private static int categoryPriority(AiRecommendationVO item) {
        if ("主食".equals(item.getCategory())) return 0;
        if ("小吃".equals(item.getCategory())) return 1;
        if ("饮料".equals(item.getCategory())) return 2;
        return 3;
    }

    /**
     * 菜品与用户需求匹配度打分。
     * 将用户偏好/口味/场景与菜品名称/分类/描述做关键词匹配，各维度独立累加。
     */
    private static int score(AiRecommendationVO item, AiMealAssistantRequest request) {
        // 拼接用户输入文本
        String text = ((request.getPreference() == null ? "" : request.getPreference()) + " "
                + (request.getFlavor() == null ? "" : request.getFlavor()) + " "
                + (request.getScene() == null ? "" : request.getScene())).toLowerCase();
        // 拼接菜品搜索文本
        String menuText = ((item.getName() == null ? "" : item.getName()) + " "
                + (item.getCategory() == null ? "" : item.getCategory()) + " "
                + (item.getDescription() == null ? "" : item.getDescription())).toLowerCase();

        int score = 0;
        // 辣味匹配：用户提"辣"且菜品含辣 +8
        if (containsAny(text, "辣", "麻辣", "香辣") && containsAny(menuText, "辣", "麻辣", "香锅", "香辣")) score += 8;
        // 清淡偏好：用户要"清淡/不辣"且菜品不含辣 +5
        if (containsAny(text, "清淡", "不辣") && !containsAny(menuText, "辣", "麻辣")) score += 5;
        // 管饱需求：用户要"管饱/午餐"且菜品是主食或饭面 +5
        if (containsAny(text, "管饱", "饱", "午餐") && containsAny(menuText, "主食", "饭", "面")) score += 5;
        // 赶时间：库存 >= 20 意味着不用排队等备货 +3
        if (containsAny(text, "赶时间", "快") && item.getStock() != null && item.getStock() >= 20) score += 3;
        // 饮料需求：匹配茶/豆浆/奶茶等饮料 +4
        if (containsAny(text, "饮料", "解辣") && containsAny(menuText, "饮料", "茶", "豆浆", "奶")) score += 4;
        // 低价偏好：用户提"便宜/实惠"且菜品 <= 15 元 +4
        if (containsAny(text, "便宜", "低价", "实惠") && item.getPrice() != null && item.getPrice().compareTo(new BigDecimal("15")) <= 0) score += 4;
        // 库存充足基础分 +1
        if (item.getStock() != null && item.getStock() >= 20) score += 1;
        return score;
    }

    /** 检查文本中是否包含任意一个关键词 */
    private static boolean containsAny(String text, String... keywords) {
        for (String keyword : keywords) {
            if (text.contains(keyword)) return true;
        }
        return false;
    }

    /** Menu 实体 → AiRecommendationVO，同时穿透窗口和食堂信息 */
    private static AiRecommendationVO toRecommendation(Menu menu, Map<Long, Window> windowMap, Map<Long, Canteen> canteenMap) {
        AiRecommendationVO vo = new AiRecommendationVO();
        vo.setId(menu.getId());
        vo.setWindowId(menu.getWindowId());
        vo.setName(menu.getName());
        vo.setCategory(menu.getCategory());
        vo.setPrice(menu.getPrice());
        vo.setStock(menu.getStock());
        vo.setSoldOut(menu.getStock() == null || menu.getStock() <= 0);
        vo.setImageUrl(menu.getImageUrl());
        vo.setDescription(menu.getDescription());
        Window window = windowMap.get(menu.getWindowId());
        if (window != null) {
            vo.setWindowName(window.getName());
            vo.setCanteenId(window.getCanteenId());
            Canteen canteen = canteenMap.get(window.getCanteenId());
            if (canteen != null) {
                vo.setCanteenName(canteen.getName());
            }
        }
        return vo;
    }

    /** VO 列表 → AiMenuCandidate 列表，扁平化后传给 AI 拼 Prompt */
    private static List<AiMenuCandidate> toCandidates(List<AiRecommendationVO> recommendations) {
        return recommendations.stream()
                .map(item -> new AiMenuCandidate(
                        item.getId(), item.getName(), item.getCategory(),
                        item.getPrice(), item.getStock(),
                        item.getWindowName(), item.getCanteenName()))
                .toList();
    }

    /** 计算选中菜品总价 */
    private static BigDecimal totalAmount(List<AiRecommendationVO> selectedMenus) {
        return selectedMenus.stream()
                .map(AiRecommendationVO::getPrice)
                .filter(price -> price != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * 三级预算解析，按优先级：
     * 1. request.budget 显式传入 > 0 → 直接使用
     * 2. preference 中正则匹配「数字 + 元」→ 提取
     * 3. 都未指定 → 默认 25 元
     */
    private static BigDecimal effectiveBudget(AiMealAssistantRequest request) {
        if (request.getBudget() != null && request.getBudget().compareTo(BigDecimal.ZERO) > 0) {
            return request.getBudget();
        }
        String preference = request.getPreference();
        if (preference != null) {
            Matcher matcher = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*元").matcher(preference);
            if (matcher.find()) {
                return new BigDecimal(matcher.group(1));
            }
        }
        return new BigDecimal("25.00");
    }

    /** 组装匹配标签，用于前端展示"已识别需求" */
    private static List<String> matchedTags(AiMealAssistantRequest request) {
        java.util.ArrayList<String> tags = new java.util.ArrayList<>();
        addIfPresent(tags, request.getFlavor());
        addIfPresent(tags, request.getScene());
        if (request.getBudget() != null && request.getBudget().compareTo(BigDecimal.ZERO) > 0) {
            tags.add("预算" + request.getBudget().stripTrailingZeros().toPlainString() + "元");
        }
        // 有偏好但没有标签时，给一个通用标签
        if (tags.isEmpty() && request.getPreference() != null && !request.getPreference().isBlank()) {
            tags.add("已理解需求");
        }
        return tags;
    }

    private static void addIfPresent(List<String> tags, String value) {
        if (value != null && !value.isBlank()) tags.add(value);
    }

    /** 本地兜底推荐理由：库存充足的优先推荐，其余统一用"今日上架" */
    private static String fallbackReason(AiRecommendationVO item) {
        if (item.getStock() != null && item.getStock() >= 20) {
            return "库存充足，适合现在下单。";
        }
        return "今日上架，适合顺手尝尝。";
    }

    /**
     * 本地兜底点餐回复——模版拼接。
     * 保证 AI 不可用时用户仍然能看到完整的推荐结果，不会出现空白。
     */
    private static String fallbackMealReply(AiMealAssistantRequest request, List<AiRecommendationVO> selectedMenus) {
        if (selectedMenus.isEmpty()) {
            return "AI 暂时没找到符合预算的搭配，可以放宽预算或换个口味试试。";
        }
        String names = selectedMenus.stream().map(AiRecommendationVO::getName).collect(Collectors.joining(" + "));
        String preference = request.getPreference() == null || request.getPreference().isBlank()
                ? "你的点餐需求"
                : "「" + request.getPreference() + "」";
        return "AI 已根据" + preference + "推荐：" + names + "，同一窗口可点，当前库存可用。";
    }
}
