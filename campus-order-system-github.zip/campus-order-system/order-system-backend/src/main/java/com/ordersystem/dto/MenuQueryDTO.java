package com.ordersystem.dto;

import lombok.Data;
import java.time.LocalDate;

/**
 * 菜品查询DTO
 */
@Data
public class MenuQueryDTO {
    private Long canteenId;
    private Long windowId;
    private String category;
    private String keyword;
    private LocalDate saleDate;
    /**
     * When true, skip the saleDate filter (show menus from all dates).
     * Used by admin management pages. Student-facing pages should leave this false/null.
     */
    private Boolean allDates;
}
