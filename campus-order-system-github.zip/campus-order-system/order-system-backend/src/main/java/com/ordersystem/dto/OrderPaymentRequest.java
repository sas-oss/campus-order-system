package com.ordersystem.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class OrderPaymentRequest {
    @NotBlank(message = "支付方式不能为空")
    private String paymentMethod;
}
