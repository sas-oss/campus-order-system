package com.ordersystem.utils;

/**
 * 订单状态工具：status → 中文文本。
 * 0-待支付 1-已支付待制作 2-制作中 3-制作完成待取餐 4-已取餐 5-已取消
 */
public final class OrderStatusUtil {

    private OrderStatusUtil() {}

    public static String text(Integer status) {
        if (status == null) return "未知";
        return switch (status) {
            case 0 -> "待支付";
            case 1 -> "已支付待制作";
            case 2 -> "制作中";
            case 3 -> "制作完成待取餐";
            case 4 -> "已取餐";
            case 5 -> "已取消";
            default -> "未知";
        };
    }
}
