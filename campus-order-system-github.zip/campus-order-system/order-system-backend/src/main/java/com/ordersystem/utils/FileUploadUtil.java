package com.ordersystem.utils;

import com.ordersystem.common.BusinessException;
import com.ordersystem.common.ErrorCode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

@Component
public class FileUploadUtil {

    @Value("${upload.path}")
    private String uploadPath;
    private static final Set<String> ALLOWED_IMAGE_EXTENSIONS = Set.of(".jpg", ".jpeg", ".png", ".gif", ".webp");

    public String upload(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            return null;
        }
        try {
            validateImage(file);
            File directory = new File(uploadPath).getAbsoluteFile();
            if (!directory.exists() && !directory.mkdirs()) {
                throw new BusinessException(ErrorCode.FILE_UPLOAD_FAILED);
            }
            String originalFilename = file.getOriginalFilename() == null ? "image.jpg" : file.getOriginalFilename();
            String extension = originalFilename.contains(".") ? originalFilename.substring(originalFilename.lastIndexOf('.')).toLowerCase(Locale.ROOT) : ".jpg";
            String filename = UUID.randomUUID().toString().replace("-", "") + extension;
            File target = new File(directory, filename).getAbsoluteFile();
            file.transferTo(target);
            return "/uploads/menu-images/" + filename;
        } catch (IOException exception) {
            throw new BusinessException(ErrorCode.FILE_UPLOAD_FAILED);
        }
    }

    private void validateImage(MultipartFile file) {
        String originalFilename = file.getOriginalFilename() == null ? "" : file.getOriginalFilename().toLowerCase(Locale.ROOT);
        String extension = originalFilename.contains(".") ? originalFilename.substring(originalFilename.lastIndexOf('.')) : "";
        String contentType = file.getContentType() == null ? "" : file.getContentType().toLowerCase(Locale.ROOT);
        boolean contentTypeOk = contentType.startsWith("image/");
        boolean extensionOk = ALLOWED_IMAGE_EXTENSIONS.contains(extension);
        // Accept if EITHER content type or extension indicates a valid image
        // (some clients send "application/octet-stream" for images)
        if (!contentTypeOk && !extensionOk) {
            throw new BusinessException(ErrorCode.FILE_UPLOAD_FAILED);
        }
    }
}
