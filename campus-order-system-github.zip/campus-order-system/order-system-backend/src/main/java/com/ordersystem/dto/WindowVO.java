package com.ordersystem.dto;

import lombok.Data;
import java.time.LocalDateTime;

/**
 * 窗口视图DTO
 */
@Data
public class WindowVO {
    private Long id;
    private Long canteenId;
    private String canteenName;
    private String name;
    private Integer floor;
    private String pickupNumberPrefix;
    private Integer status;
    private LocalDateTime createTime;
}
