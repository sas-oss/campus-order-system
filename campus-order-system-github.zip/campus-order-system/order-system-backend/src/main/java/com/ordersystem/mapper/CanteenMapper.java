package com.ordersystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ordersystem.entity.Canteen;
import org.apache.ibatis.annotations.Mapper;

/**
 * 食堂 Mapper
 */
@Mapper
public interface CanteenMapper extends BaseMapper<Canteen> {
}
