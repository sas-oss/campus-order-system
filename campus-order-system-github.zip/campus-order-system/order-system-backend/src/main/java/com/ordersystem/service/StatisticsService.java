package com.ordersystem.service;

import com.ordersystem.dto.DailyStatsVO;
import com.ordersystem.dto.HotDishVO;
import com.ordersystem.dto.OverviewStatsVO;
import com.ordersystem.dto.OrderTrendVO;
import com.ordersystem.dto.RankingVO;
import com.ordersystem.dto.TimeSlotStatsVO;

import java.time.LocalDate;
import java.util.List;

public interface StatisticsService {
    DailyStatsVO getDailyStats(Long windowId, LocalDate date);
    List<HotDishVO> getHotDishes(Long windowId, int days);
    List<TimeSlotStatsVO> getTimeSlotStats(Long windowId, LocalDate date);
    OverviewStatsVO getOverview();
    List<RankingVO> getRankings();
    List<OrderTrendVO> getOrderTrend(LocalDate startDate, LocalDate endDate);
}
