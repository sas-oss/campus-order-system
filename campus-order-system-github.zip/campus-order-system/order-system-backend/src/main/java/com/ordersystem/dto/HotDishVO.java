package com.ordersystem.dto;

import lombok.Data;

@Data
public class HotDishVO {
    private Long menuId;
    private String menuName;
    private Integer totalQuantity;
    private Double totalRevenue;
}
