package com.ordersystem.controller;

import com.ordersystem.common.Result;
import com.ordersystem.service.MessageService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@Tag(name = "消息管理")
@RestController
@RequestMapping("/api/messages")
@RequiredArgsConstructor
public class MessageController {

    private final MessageService messageService;

    @GetMapping
    @Operation(summary = "获取消息列表")
    public Result<?> list(@RequestAttribute("userId") Long userId,
                          @RequestParam(defaultValue = "1") int page,
                          @RequestParam(defaultValue = "10") int size) {
        return Result.success(messageService.listByUser(userId, page, size));
    }

    @GetMapping("/unread-count")
    @Operation(summary = "获取未读消息数")
    public Result<?> unreadCount(@RequestAttribute("userId") Long userId) {
        return Result.success(messageService.getUnreadCount(userId));
    }

    @PutMapping("/{id}/read")
    @Operation(summary = "标记已读")
    public Result<?> markRead(@PathVariable Long id, @RequestAttribute("userId") Long userId) {
        messageService.markAsRead(id, userId);
        return Result.success();
    }

    @PutMapping("/read-all")
    @Operation(summary = "全部标记已读")
    public Result<?> markAllRead(@RequestAttribute("userId") Long userId) {
        messageService.markAllAsRead(userId);
        return Result.success();
    }
}
