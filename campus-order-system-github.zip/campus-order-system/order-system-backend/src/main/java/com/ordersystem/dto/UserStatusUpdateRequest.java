package com.ordersystem.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class UserStatusUpdateRequest {
    @NotNull(message = "用户状态不能为空")
    private Integer status;
}
