package com.ordersystem.service;

import com.ordersystem.dto.*;
import com.ordersystem.common.PageResult;
import java.util.List;

/**
 * 菜品服务接口
 */
public interface MenuService {
    PageResult<MenuVO> listMenus(MenuQueryDTO query, int page, int size);
    MenuVO getMenuById(Long id);
    void createMenu(MenuRequest request, Long adminId);
    void updateMenu(Long id, MenuRequest request, Long adminId);
    void deleteMenu(Long id, Long adminId);
    void updateStock(Long id, Integer stock);
    List<MenuVO> getTodayMenusByWindow(Long windowId);
}
