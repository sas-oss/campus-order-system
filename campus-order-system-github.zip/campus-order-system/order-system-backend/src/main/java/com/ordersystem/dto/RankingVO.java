package com.ordersystem.dto;

import lombok.Data;

@Data
public class RankingVO {
    private Long windowId;
    private String windowName;
    private String canteenName;
    private Double averageScore;
    private Long totalReviews;
    private Integer rank;
}
