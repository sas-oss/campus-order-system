package com.ordersystem.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ordersystem.dto.AiMealAssistantRequest;
import com.ordersystem.dto.AiMenuCandidate;
import com.ordersystem.service.AiClient;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * OpenAI 兼容客户端，默认对接 DeepSeek。
 * 核心安全策略：api-key 为空或网络异常时静默返回空结果，不抛异常，由上层降级到本地兜底。
 * 连接超时 3s、读取超时 5s，避免 AI 服务不可用时阻塞整个请求链路。
 */
@Service
@RequiredArgsConstructor
public class OpenAiCompatibleClient implements AiClient {

    private final ObjectMapper objectMapper;

    /** 静态创建，启动时即初始化，避免每次请求都 new */
    private final RestTemplate restTemplate = createRestTemplate();

    /** 为空时所有 AI 调用静默跳过，返回空结果 */
    @Value("${ai.api-key:}")
    private String apiKey;

    @Value("${ai.base-url:https://api.deepseek.com}")
    private String baseUrl;

    @Value("${ai.model:deepseek-chat}")
    private String model;

    /** 为每个菜品生成推荐理由，temperature=0.6 保证 JSON 格式输出稳定 */
    @Override
    public Map<Long, String> generateRecommendationReasons(List<AiMenuCandidate> candidates) {
        if (apiKey == null || apiKey.isBlank() || candidates.isEmpty()) {
            return Map.of();
        }
        String content = chat("你是校园食堂点餐助手，只输出 JSON。", buildRecommendationPrompt(candidates), 0.6);
        return parseReasons(content);
    }

    /** 生成点餐助手回复，temperature=0.7 保留自然表达 */
    @Override
    public String generateMealAssistantReply(AiMealAssistantRequest request,
                                             List<AiMenuCandidate> candidates,
                                             List<AiMenuCandidate> selectedMenus) {
        if (apiKey == null || apiKey.isBlank() || selectedMenus.isEmpty()) {
            return "";
        }
        return chat("你是校园食堂 AI 点餐助手，回答要自然、具体、简短。", buildMealAssistantPrompt(request, candidates, selectedMenus), 0.7);
    }

    /**
     * 发送 Chat Completions 请求。
     * 使用 JSONPath /choices/0/message/content 提取回复文本，
     * 响应为 null 或解析失败均返回空字符串。
     */
    private String chat(String systemPrompt, String userPrompt, double temperature) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(apiKey);

        // 组装标准 Chat Completions 请求体
        Map<String, Object> request = Map.of(
                "model", model,
                "temperature", temperature,
                "messages", List.of(
                        Map.of("role", "system", "content", systemPrompt),
                        Map.of("role", "user", "content", userPrompt)
                )
        );
        JsonNode response = restTemplate.postForObject(chatCompletionsUrl(), new HttpEntity<>(request, headers), JsonNode.class);
        return response == null ? "" : response.at("/choices/0/message/content").asText("");
    }

    /**
     * 构建推荐理由 Prompt。
     * 关键约束：要求 AI 只输出 JSON 数组，方便代码解析；指定格式示例减少 AI 自由发挥。
     */
    private String buildRecommendationPrompt(List<AiMenuCandidate> candidates) {
        // 将菜品列表序列化为结构化的纯文本行
        String menuText = candidates.stream()
                .map(item -> String.format(
                        "menuId=%d, name=%s, category=%s, price=%s, stock=%s, window=%s, canteen=%s",
                        item.getMenuId(),
                        item.getName(),
                        item.getCategory(),
                        item.getPrice(),
                        item.getStock(),
                        item.getWindowName(),
                        item.getCanteenName()))
                .collect(Collectors.joining("\n"));
        return """
                请为下面每个菜品生成一句中文推荐理由。
                要求：自然、有食堂点餐场景，不超过 20 个汉字，不夸大疗效。
                只返回 JSON 数组，格式：
                [{"menuId":1,"reason":"近期人气高，午餐很合适。"}]

                菜品：
                """ + menuText;
    }

    /**
     * 构建点餐助手 Prompt。
     * 核心约束：系统已通过本地算法选好菜品，AI 只负责润色回复，不能推荐未选中菜品。
     * 要求两句式输出——第一句推荐、第二句解释，且必须提及预算或库存（增强可信度）。
     */
    private String buildMealAssistantPrompt(AiMealAssistantRequest request,
                                            List<AiMenuCandidate> candidates,
                                            List<AiMenuCandidate> selectedMenus) {
        String candidateText = formatCandidates(candidates);
        String selectedText = formatCandidates(selectedMenus);
        return String.format("""
                用户需求：%s
                口味标签：%s
                场景标签：%s
                预算：%s 元

                系统已根据真实菜单、库存、预算和同窗口限制选出：
                %s

                可选菜单上下文：
                %s

                请用中文回复 2 句：
                第一句直接说"为你推荐：菜品A + 菜品B"。
                第二句解释为什么符合用户需求，必须提到预算或库存之一。
                不要推荐未选中的菜，不要输出 Markdown。
                """,
                blankToDefault(request.getPreference(), "想让 AI 帮我搭配一餐"),
                blankToDefault(request.getFlavor(), "未指定"),
                blankToDefault(request.getScene(), "未指定"),
                request.getBudget() == null ? "未指定" : request.getBudget().stripTrailingZeros().toPlainString(),
                selectedText,
                candidateText);
    }

    /** 将候选菜品格式化为 Prompt 可用的文本行 */
    private String formatCandidates(List<AiMenuCandidate> candidates) {
        return candidates.stream()
                .map(item -> String.format(
                        "menuId=%d, name=%s, category=%s, price=%s, stock=%s, window=%s, canteen=%s",
                        item.getMenuId(),
                        item.getName(),
                        item.getCategory(),
                        item.getPrice(),
                        item.getStock(),
                        item.getWindowName(),
                        item.getCanteenName()))
                .collect(Collectors.joining("\n"));
    }

    /** 空值或空白字符串替换为默认值，用于 Prompt 中的空白字段占位 */
    private static String blankToDefault(String value, String defaultValue) {
        return value == null || value.isBlank() ? defaultValue : value;
    }

    /**
     * 解析 AI 返回的 JSON 推荐理由。
     * 容错：自动去除 Markdown 代码块包裹 → Jackson 解析 → 过滤无效条目。
     * 任何步骤失败均返回空 Map，不抛异常。
     */
    private Map<Long, String> parseReasons(String content) {
        String json = stripCodeFence(content);
        try {
            List<ReasonItem> items = objectMapper.readValue(json, new TypeReference<List<ReasonItem>>() {});
            return items.stream()
                    .filter(item -> item.getMenuId() != null && item.getReason() != null && !item.getReason().isBlank())
                    .collect(Collectors.toMap(ReasonItem::getMenuId, ReasonItem::getReason, (left, right) -> left));
        } catch (Exception ex) {
            // AI 返回格式异常时静默降级，上层使用本地兜底理由
            return Map.of();
        }
    }

    /**
     * 去除 AI 返回中可能包裹的 Markdown 代码块（```json ... ```）。
     * 部分模型即使 Prompt 要求只返回 JSON，仍会自动加代码块包裹，这里做防御性处理。
     */
    private static String stripCodeFence(String content) {
        String trimmed = content == null ? "" : content.trim();
        if (!trimmed.startsWith("```")) {
            return trimmed;
        }
        List<String> lines = new ArrayList<>(List.of(trimmed.split("\\R")));
        // 去掉首行 ```json 或 ```
        if (!lines.isEmpty()) {
            lines.remove(0);
        }
        // 去掉末行 ```
        if (!lines.isEmpty() && lines.get(lines.size() - 1).startsWith("```")) {
            lines.remove(lines.size() - 1);
        }
        return String.join("\n", lines).trim();
    }

    /** 拼接 API 地址：去除 baseUrl 尾部斜杠后接 /chat/completions */
    private String chatCompletionsUrl() {
        return baseUrl.replaceAll("/+$", "") + "/chat/completions";
    }

    /** 创建 RestTemplate，连接超时 3s、读取超时 5s，避免 AI 不可用时长时间阻塞 */
    private static RestTemplate createRestTemplate() {
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        requestFactory.setConnectTimeout(3000);
        requestFactory.setReadTimeout(5000);
        return new RestTemplate(requestFactory);
    }

    /** 对应 AI 返回的 {"menuId": 1, "reason": "..."} 格式 */
    @Data
    private static class ReasonItem {
        private Long menuId;
        private String reason;
    }
}
