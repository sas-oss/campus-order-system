package com.ordersystem.controller;

import com.ordersystem.common.Result;
import com.ordersystem.dto.CanteenRequest;
import com.ordersystem.service.CanteenService;
import com.ordersystem.utils.AuthUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "食堂管理", description = "系统管理员维护食堂信息")
@RestController
@RequestMapping("/api/canteens")
@RequiredArgsConstructor
public class CanteenController {

    private final CanteenService canteenService;

    @GetMapping
    @Operation(summary = "获取食堂列表")
    public Result<?> list() {
        return Result.success(canteenService.listAll());
    }

    @GetMapping("/{id}")
    @Operation(summary = "获取食堂详情")
    public Result<?> detail(@PathVariable Long id) {
        return Result.success(canteenService.getById(id));
    }

    @PostMapping
    @Operation(summary = "新增食堂")
    public Result<?> create(@Valid @RequestBody CanteenRequest request,
                            @RequestAttribute("role") String role,
                            @RequestAttribute("userId") Long userId) {
        AuthUtil.requireRole(role, "SYSTEM_ADMIN");
        canteenService.create(request, userId);
        return Result.success();
    }

    @PutMapping("/{id}")
    @Operation(summary = "编辑食堂")
    public Result<?> update(@PathVariable Long id,
                            @Valid @RequestBody CanteenRequest request,
                            @RequestAttribute("role") String role,
                            @RequestAttribute("userId") Long userId) {
        AuthUtil.requireRole(role, "SYSTEM_ADMIN");
        canteenService.update(id, request, userId);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "删除食堂")
    public Result<?> delete(@PathVariable Long id,
                            @RequestAttribute("role") String role,
                            @RequestAttribute("userId") Long userId) {
        AuthUtil.requireRole(role, "SYSTEM_ADMIN");
        canteenService.delete(id, userId);
        return Result.success();
    }
}
