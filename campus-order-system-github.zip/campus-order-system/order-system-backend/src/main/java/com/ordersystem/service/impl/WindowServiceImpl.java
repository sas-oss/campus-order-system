package com.ordersystem.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ordersystem.common.BusinessException;
import com.ordersystem.common.ErrorCode;
import com.ordersystem.dto.*;
import com.ordersystem.entity.Canteen;
import com.ordersystem.entity.Window;
import com.ordersystem.entity.SysUser;
import com.ordersystem.mapper.CanteenMapper;
import com.ordersystem.mapper.WindowMapper;
import com.ordersystem.mapper.SysUserMapper;
import com.ordersystem.service.WindowService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 窗口服务实现
 */
@Service
@RequiredArgsConstructor
public class WindowServiceImpl implements WindowService {

    private final WindowMapper windowMapper;
    private final CanteenMapper canteenMapper;
    private final SysUserMapper sysUserMapper;

    @Override
    public List<WindowVO> listByCanteenId(Long canteenId) {
        LambdaQueryWrapper<Window> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Window::getCanteenId, canteenId);
        wrapper.eq(Window::getStatus, 1);
        wrapper.orderByAsc(Window::getFloor, Window::getId);
        List<Window> windows = windowMapper.selectList(wrapper);

        return windows.stream().map(this::toVO).collect(Collectors.toList());
    }

    @Override
    public WindowVO getById(Long id) {
        Window window = windowMapper.selectById(id);
        if (window == null) {
            throw new BusinessException(ErrorCode.WINDOW_NOT_FOUND);
        }
        return toVO(window);
    }

    @Override
    public List<WindowVO> listByAdmin(Long adminWindowId) {
        if (adminWindowId == null) {
            // 无绑定窗口，返回全部窗口
            LambdaQueryWrapper<Window> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Window::getStatus, 1);
            wrapper.orderByAsc(Window::getCanteenId, Window::getFloor, Window::getId);
            return windowMapper.selectList(wrapper).stream().map(this::toVO).collect(Collectors.toList());
        }
        LambdaQueryWrapper<Window> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Window::getId, adminWindowId);
        wrapper.eq(Window::getStatus, 1);
        return windowMapper.selectList(wrapper).stream().map(this::toVO).collect(Collectors.toList());
    }

    @Override
    public List<WindowVO> listForCurrentUser(Long canteenId, Long adminWindowId, String role, Long userId) {
        if (canteenId != null) {
            return listByCanteenId(canteenId);
        }
        return listByAdmin(adminWindowId);
    }

    @Override
    public void create(WindowRequest request, Long operatorId) {
        // 验证食堂是否存在
        Canteen canteen = canteenMapper.selectById(request.getCanteenId());
        if (canteen == null) {
            throw new BusinessException(ErrorCode.CANTEEN_NOT_FOUND);
        }

        Window window = new Window();
        window.setCanteenId(request.getCanteenId());
        window.setName(request.getName());
        window.setFloor(request.getFloor());
        window.setPickupNumberPrefix(request.getPickupNumberPrefix());
        window.setStatus(1);
        windowMapper.insert(window);
    }

    @Override
    public void update(Long id, WindowRequest request, Long operatorId) {
        Window window = windowMapper.selectById(id);
        if (window == null) {
            throw new BusinessException(ErrorCode.WINDOW_NOT_FOUND);
        }
        // 验证食堂是否存在
        Canteen canteen = canteenMapper.selectById(request.getCanteenId());
        if (canteen == null) {
            throw new BusinessException(ErrorCode.CANTEEN_NOT_FOUND);
        }

        window.setCanteenId(request.getCanteenId());
        window.setName(request.getName());
        window.setFloor(request.getFloor());
        window.setPickupNumberPrefix(request.getPickupNumberPrefix());
        windowMapper.updateById(window);
    }

    @Override
    public void delete(Long id, Long operatorId) {
        Window window = windowMapper.selectById(id);
        if (window == null) {
            throw new BusinessException(ErrorCode.WINDOW_NOT_FOUND);
        }
        windowMapper.deleteById(id);
    }

    /**
     * 将 Window 实体转为 VO，关联食堂名称
     */
    private WindowVO toVO(Window window) {
        WindowVO vo = new WindowVO();
        vo.setId(window.getId());
        vo.setCanteenId(window.getCanteenId());
        vo.setName(window.getName());
        vo.setFloor(window.getFloor());
        vo.setPickupNumberPrefix(window.getPickupNumberPrefix());
        vo.setStatus(window.getStatus());
        vo.setCreateTime(window.getCreateTime());

        // 关联查询食堂名称
        if (window.getCanteenId() != null) {
            Canteen canteen = canteenMapper.selectById(window.getCanteenId());
            if (canteen != null) {
                vo.setCanteenName(canteen.getName());
            }
        }
        return vo;
    }
}
