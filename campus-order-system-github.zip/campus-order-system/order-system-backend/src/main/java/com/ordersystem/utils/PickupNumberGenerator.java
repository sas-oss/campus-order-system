package com.ordersystem.utils;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ordersystem.entity.OrderInfo;
import com.ordersystem.entity.Window;
import com.ordersystem.mapper.OrderInfoMapper;
import com.ordersystem.mapper.WindowMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;

/**
 * 取餐号生成器：窗口前缀 + 当天自增序号，每天从 001 开始。
 * 例如 A001、A002、B001。
 */
@Component
@RequiredArgsConstructor
public class PickupNumberGenerator {

    private final OrderInfoMapper orderInfoMapper;
    private final WindowMapper windowMapper;

    /** 根据窗口前缀生成当天自增收餐号，如 A001 */
    public String generate(Long windowId) {
        // 获取窗口前缀，默认 A
        Window window = windowMapper.selectById(windowId);
        String prefix = window == null || window.getPickupNumberPrefix() == null || window.getPickupNumberPrefix().isBlank()
                ? "A"
                : window.getPickupNumberPrefix();

        // 查询当天该窗口的最大序号
        LocalDateTime start = LocalDate.now().atStartOfDay();
        LocalDateTime end = start.plusDays(1);
        List<OrderInfo> todayOrders = orderInfoMapper.selectList(new LambdaQueryWrapper<OrderInfo>()
                .eq(OrderInfo::getWindowId, windowId)
                .ge(OrderInfo::getCreateTime, start)
                .lt(OrderInfo::getCreateTime, end));

        // 取最大序号 +1，格式化为 3 位
        int next = todayOrders.stream()
                .map(OrderInfo::getPickupNumber)
                .filter(number -> number != null && number.startsWith(prefix))
                .map(number -> number.substring(prefix.length()))
                .filter(number -> number.matches("\\d+"))
                .map(Integer::parseInt)
                .max(Comparator.naturalOrder())
                .orElse(0) + 1;

        return prefix + String.format("%03d", next);
    }
}
