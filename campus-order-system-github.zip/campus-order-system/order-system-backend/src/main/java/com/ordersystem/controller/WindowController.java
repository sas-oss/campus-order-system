package com.ordersystem.controller;

import com.ordersystem.common.Result;
import com.ordersystem.dto.WindowRequest;
import com.ordersystem.service.WindowService;
import com.ordersystem.utils.AuthUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@Tag(name = "窗口管理")
@RestController
@RequestMapping("/api/windows")
@RequiredArgsConstructor
public class WindowController {

    private final WindowService windowService;

    @GetMapping
    @Operation(summary = "获取窗口列表")
    public Result<?> list(@RequestParam(required = false) Long canteenId,
                          @RequestParam(required = false) Long adminWindowId,
                          @RequestAttribute(value = "role", required = false) String role,
                          @RequestAttribute(value = "userId", required = false) Long userId) {
        return Result.success(windowService.listForCurrentUser(canteenId, adminWindowId, role, userId));
    }

    @GetMapping("/{id}")
    @Operation(summary = "获取窗口详情")
    public Result<?> detail(@PathVariable Long id) {
        return Result.success(windowService.getById(id));
    }

    @PostMapping
    @Operation(summary = "新增窗口")
    public Result<?> create(@Valid @RequestBody WindowRequest request,
                            @RequestAttribute("role") String role,
                            @RequestAttribute("userId") Long userId) {
        AuthUtil.requireRole(role, "SYSTEM_ADMIN");
        windowService.create(request, userId);
        return Result.success();
    }

    @PutMapping("/{id}")
    @Operation(summary = "编辑窗口")
    public Result<?> update(@PathVariable Long id,
                            @Valid @RequestBody WindowRequest request,
                            @RequestAttribute("role") String role,
                            @RequestAttribute("userId") Long userId) {
        AuthUtil.requireRole(role, "SYSTEM_ADMIN");
        windowService.update(id, request, userId);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "删除窗口")
    public Result<?> delete(@PathVariable Long id,
                            @RequestAttribute("role") String role,
                            @RequestAttribute("userId") Long userId) {
        AuthUtil.requireRole(role, "SYSTEM_ADMIN");
        windowService.delete(id, userId);
        return Result.success();
    }
}
