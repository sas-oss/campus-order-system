package com.ordersystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("review_item")
public class ReviewItem {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long reviewId;
    private Long orderId;
    private Long userId;
    private Long windowId;
    private Long menuId;
    private Integer score;
    private String content;
    private LocalDateTime createTime;
}
