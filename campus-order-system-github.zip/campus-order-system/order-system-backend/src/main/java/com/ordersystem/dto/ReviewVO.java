package com.ordersystem.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class ReviewVO {
    private Long id;
    private Long orderId;
    private Long userId;
    private String username;
    private String realName;
    private Long windowId;
    private String windowName;
    private Long menuId;
    private String menuName;
    private Integer score;
    private String content;
    private String replyContent;
    private LocalDateTime replyTime;
    private LocalDateTime createTime;
    private List<ReviewItemVO> items;
}
