package com.ordersystem.service;

import com.ordersystem.common.PageResult;
import com.ordersystem.dto.ReviewRequest;
import com.ordersystem.dto.ReviewStatisticsVO;
import com.ordersystem.dto.ReviewVO;

import java.util.List;

/**
 * 评价服务接口。
 * review 表存窗口评价，review_item 表存每个菜品的独立评分。
 * 学生只能对已取餐订单评价且每个订单只能评价一次。
 */
public interface ReviewService {

    /** 提交评价（窗口评分 + 菜品评分明细），存入 review + review_item */
    void submitReview(Long userId, ReviewRequest request);

    /** 分页查询我的评价 */
    PageResult<ReviewVO> listMyReviews(Long userId, int page, int size);

    /** 分页查询某窗口的评价列表 */
    PageResult<ReviewVO> listWindowReviews(Long windowId, int page, int size);

    /** 管理员回复评价，回复后发送站内信通知 */
    void replyReview(Long reviewId, String content, Long adminId);

    /** 单窗口评价统计（总数/均分/差评数） */
    ReviewStatisticsVO getWindowStatistics(Long windowId);

    /** 全平台各窗口评价统计 */
    List<ReviewStatisticsVO> getAllStatistics();
}
