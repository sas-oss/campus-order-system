package com.ordersystem.controller;

import com.ordersystem.common.Result;
import com.ordersystem.dto.OrderCreateRequest;
import com.ordersystem.dto.OrderPaymentRequest;
import com.ordersystem.dto.OrderStatusUpdateRequest;
import com.ordersystem.service.OrderService;
import com.ordersystem.service.SysUserService;
import com.ordersystem.utils.AuthUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@Tag(name = "订单管理")
@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;
    private final SysUserService sysUserService;

    @PostMapping
    @Operation(summary = "创建订单")
    public Result<?> create(@RequestAttribute("userId") Long userId,
                            @RequestAttribute("role") String role,
                            @Valid @RequestBody OrderCreateRequest request) {
        AuthUtil.requireRole(role, "STUDENT");
        return Result.success(orderService.createOrder(userId, request));
    }

    @GetMapping
    @Operation(summary = "获取订单列表")
    public Result<?> list(@RequestAttribute("userId") Long userId,
                          @RequestAttribute("role") String role,
                          @RequestParam(required = false) Integer status,
                          @RequestParam(defaultValue = "1") int page,
                          @RequestParam(defaultValue = "10") int size) {
        if ("STUDENT".equals(role)) {
            return Result.success(orderService.getUserOrders(userId, status, page, size));
        }
        Long windowId = sysUserService.getProfile(userId).getWindowId();
        return Result.success(orderService.getWindowOrders(windowId, status, page, size));
    }

    @GetMapping("/{id}")
    @Operation(summary = "获取订单详情")
    public Result<?> detail(@PathVariable Long id,
                            @RequestAttribute("userId") Long userId,
                            @RequestAttribute("role") String role) {
        return Result.success(orderService.getDetail(id, userId, role));
    }

    @PostMapping("/{id}/pay")
    @Operation(summary = "模拟支付")
    public Result<?> pay(@PathVariable Long id,
                         @RequestAttribute("userId") Long userId,
                         @RequestAttribute("role") String role,
                         @Valid @RequestBody OrderPaymentRequest request) {
        AuthUtil.requireRole(role, "STUDENT");
        return Result.success(orderService.payOrder(id, userId, request.getPaymentMethod()));
    }

    @PostMapping("/{id}/cancel")
    @Operation(summary = "取消订单")
    public Result<?> cancel(@PathVariable Long id,
                            @RequestAttribute("userId") Long userId,
                            @RequestAttribute("role") String role) {
        AuthUtil.requireRole(role, "STUDENT");
        return Result.success(orderService.cancelOrder(id, userId));
    }

    @PutMapping("/{id}/status")
    @Operation(summary = "更新订单状态")
    public Result<?> updateStatus(@PathVariable Long id,
                                  @RequestAttribute("userId") Long userId,
                                  @RequestAttribute("role") String role,
                                  @Valid @RequestBody OrderStatusUpdateRequest request) {
        AuthUtil.requireAnyRole(role, "CANTEEN_ADMIN", "SYSTEM_ADMIN");
        return Result.success(orderService.updateStatus(id, request.getStatus(), userId, request.getPickupCode()));
    }
}
