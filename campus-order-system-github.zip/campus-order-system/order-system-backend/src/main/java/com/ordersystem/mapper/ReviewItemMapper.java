package com.ordersystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ordersystem.entity.ReviewItem;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ReviewItemMapper extends BaseMapper<ReviewItem> {
}
