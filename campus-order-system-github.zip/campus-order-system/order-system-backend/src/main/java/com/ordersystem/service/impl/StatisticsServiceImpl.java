package com.ordersystem.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ordersystem.dto.DailyStatsVO;
import com.ordersystem.dto.HotDishVO;
import com.ordersystem.dto.OverviewStatsVO;
import com.ordersystem.dto.OrderTrendVO;
import com.ordersystem.dto.RankingVO;
import com.ordersystem.dto.ReviewStatisticsVO;
import com.ordersystem.dto.TimeSlotStatsVO;
import com.ordersystem.entity.Canteen;
import com.ordersystem.entity.OrderInfo;
import com.ordersystem.entity.OrderItem;
import com.ordersystem.entity.Review;
import com.ordersystem.entity.SysUser;
import com.ordersystem.entity.Window;
import com.ordersystem.mapper.CanteenMapper;
import com.ordersystem.mapper.OrderInfoMapper;
import com.ordersystem.mapper.OrderItemMapper;
import com.ordersystem.mapper.ReviewMapper;
import com.ordersystem.mapper.SysUserMapper;
import com.ordersystem.mapper.WindowMapper;
import com.ordersystem.service.StatisticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StatisticsServiceImpl implements StatisticsService {

    private final OrderInfoMapper orderInfoMapper;
    private final OrderItemMapper orderItemMapper;
    private final ReviewMapper reviewMapper;
    private final SysUserMapper sysUserMapper;
    private final CanteenMapper canteenMapper;
    private final WindowMapper windowMapper;

    @Override
    public DailyStatsVO getDailyStats(Long windowId, LocalDate date) {
        LocalDate useDate = date == null ? LocalDate.now() : date;
        List<OrderInfo> orders = ordersByWindowAndDate(windowId, useDate);
        DailyStatsVO vo = new DailyStatsVO();
        vo.setTotalOrders(orders.size());
        vo.setCompletedOrders((int) orders.stream().filter(order -> order.getStatus() == 4).count());
        vo.setTotalRevenue(orders.stream().filter(order -> order.getStatus() != 5).map(OrderInfo::getTotalAmount).mapToDouble(amount -> amount == null ? 0D : amount.doubleValue()).sum());
        vo.setUniqueCustomers((int) orders.stream().map(OrderInfo::getUserId).distinct().count());
        return vo;
    }

    @Override
    public List<HotDishVO> getHotDishes(Long windowId, int days) {
        LocalDateTime start = LocalDate.now().minusDays(Math.max(days, 1) - 1).atStartOfDay();
        List<OrderInfo> orders = orderInfoMapper.selectList(new LambdaQueryWrapper<OrderInfo>()
                .eq(OrderInfo::getWindowId, windowId)
                .ge(OrderInfo::getCreateTime, start)
                .in(OrderInfo::getStatus, List.of(1, 2, 3, 4)));
        if (orders.isEmpty()) {
            return List.of();
        }
        List<OrderItem> items = orderItemMapper.selectList(new LambdaQueryWrapper<OrderItem>()
                .in(OrderItem::getOrderId, orders.stream().map(OrderInfo::getId).toList()));
        return items.stream()
                .collect(Collectors.groupingBy(OrderItem::getMenuId))
                .values().stream()
                .map(group -> {
                    OrderItem first = group.get(0);
                    HotDishVO vo = new HotDishVO();
                    vo.setMenuId(first.getMenuId());
                    vo.setMenuName(first.getMenuName());
                    vo.setTotalQuantity(group.stream().mapToInt(OrderItem::getQuantity).sum());
                    vo.setTotalRevenue(group.stream().mapToDouble(item -> item.getSubtotal().doubleValue()).sum());
                    return vo;
                })
                .sorted(Comparator.comparing(HotDishVO::getTotalQuantity).reversed())
                .toList();
    }

    @Override
    public List<TimeSlotStatsVO> getTimeSlotStats(Long windowId, LocalDate date) {
        return ordersByWindowAndDate(windowId, date == null ? LocalDate.now() : date).stream()
                .collect(Collectors.groupingBy(OrderInfo::getPickupTimeSlot, Collectors.counting()))
                .entrySet().stream()
                .map(entry -> {
                    TimeSlotStatsVO vo = new TimeSlotStatsVO();
                    vo.setTimeSlot(entry.getKey());
                    vo.setOrderCount(entry.getValue().intValue());
                    return vo;
                })
                .sorted(Comparator.comparing(TimeSlotStatsVO::getTimeSlot))
                .toList();
    }

    @Override
    public OverviewStatsVO getOverview() {
        OverviewStatsVO vo = new OverviewStatsVO();
        vo.setTotalUsers(sysUserMapper.selectCount(new LambdaQueryWrapper<SysUser>()));
        vo.setTotalCanteens(canteenMapper.selectCount(new LambdaQueryWrapper<Canteen>()));
        vo.setTotalWindows(windowMapper.selectCount(new LambdaQueryWrapper<Window>()));

        // 使用 COUNT 查询代替全表加载
        LocalDateTime todayStart = LocalDate.now().atStartOfDay();
        LocalDateTime todayEnd = todayStart.plusDays(1);

        vo.setTotalOrders(orderInfoMapper.selectCount(new LambdaQueryWrapper<OrderInfo>()));
        vo.setTodayOrders(orderInfoMapper.selectCount(new LambdaQueryWrapper<OrderInfo>()
                .ge(OrderInfo::getCreateTime, todayStart)
                .lt(OrderInfo::getCreateTime, todayEnd)));

        // 营收统计：仅查询已支付/制作中/待取餐/已取餐的订单金额
        List<OrderInfo> revenueOrders = orderInfoMapper.selectList(new LambdaQueryWrapper<OrderInfo>()
                .select(OrderInfo::getTotalAmount, OrderInfo::getCreateTime, OrderInfo::getStatus)
                .in(OrderInfo::getStatus, List.of(1, 2, 3, 4)));
        vo.setTotalRevenue(revenueOrders.stream()
                .mapToDouble(o -> o.getTotalAmount() == null ? 0D : o.getTotalAmount().doubleValue()).sum());
        vo.setTodayRevenue(revenueOrders.stream()
                .filter(o -> o.getCreateTime() != null && !o.getCreateTime().isBefore(todayStart) && o.getCreateTime().isBefore(todayEnd))
                .mapToDouble(o -> o.getTotalAmount() == null ? 0D : o.getTotalAmount().doubleValue()).sum());
        return vo;
    }

    @Override
    public List<RankingVO> getRankings() {
        Map<Long, List<Review>> reviewsByWindow = reviewMapper.selectList(new LambdaQueryWrapper<Review>()).stream()
                .collect(Collectors.groupingBy(Review::getWindowId));
        Map<Long, Window> windowMap = windowMapper.selectList(new LambdaQueryWrapper<>()).stream()
                .collect(Collectors.toMap(Window::getId, window -> window));
        Map<Long, Canteen> canteenMap = canteenMapper.selectList(new LambdaQueryWrapper<>()).stream()
                .collect(Collectors.toMap(Canteen::getId, canteen -> canteen));
        List<RankingVO> rankings = reviewsByWindow.entrySet().stream().map(entry -> {
            RankingVO vo = new RankingVO();
            Window window = windowMap.get(entry.getKey());
            vo.setWindowId(entry.getKey());
            vo.setWindowName(window == null ? "" : window.getName());
            if (window != null) {
                Canteen canteen = canteenMap.get(window.getCanteenId());
                vo.setCanteenName(canteen == null ? "" : canteen.getName());
            }
            vo.setAverageScore(entry.getValue().stream().mapToInt(Review::getScore).average().orElse(0D));
            vo.setTotalReviews((long) entry.getValue().size());
            return vo;
        }).sorted(Comparator.comparing(RankingVO::getAverageScore).reversed()).toList();
        for (int index = 0; index < rankings.size(); index++) {
            rankings.get(index).setRank(index + 1);
        }
        return rankings;
    }

    @Override
    public List<OrderTrendVO> getOrderTrend(LocalDate startDate, LocalDate endDate) {
        LocalDate end = endDate == null ? LocalDate.now() : endDate;
        LocalDate start = startDate == null ? end.minusDays(6) : startDate;
        if (start.isAfter(end)) {
            LocalDate temp = start;
            start = end;
            end = temp;
        }
        LocalDateTime startTime = start.atStartOfDay();
        LocalDateTime endTime = end.plusDays(1).atStartOfDay();
        List<OrderInfo> orders = orderInfoMapper.selectList(new LambdaQueryWrapper<OrderInfo>()
                .ge(OrderInfo::getCreateTime, startTime)
                .lt(OrderInfo::getCreateTime, endTime));
        Map<LocalDate, List<OrderInfo>> ordersByDate = orders.stream()
                .filter(order -> order.getCreateTime() != null)
                .collect(Collectors.groupingBy(order -> order.getCreateTime().toLocalDate()));

        return start.datesUntil(end.plusDays(1)).map(date -> {
            List<OrderInfo> dayOrders = ordersByDate.getOrDefault(date, List.of());
            OrderTrendVO vo = new OrderTrendVO();
            vo.setDate(date);
            vo.setOrderCount(dayOrders.size());
            vo.setRevenue(dayOrders.stream()
                    .filter(order -> order.getStatus() == null || order.getStatus() != 5)
                    .mapToDouble(order -> order.getTotalAmount() == null ? 0D : order.getTotalAmount().doubleValue())
                    .sum());
            return vo;
        }).toList();
    }

    private List<OrderInfo> ordersByWindowAndDate(Long windowId, LocalDate date) {
        LocalDateTime start = date.atStartOfDay();
        LocalDateTime end = start.plusDays(1);
        return orderInfoMapper.selectList(new LambdaQueryWrapper<OrderInfo>()
                .eq(OrderInfo::getWindowId, windowId)
                .ge(OrderInfo::getCreateTime, start)
                .lt(OrderInfo::getCreateTime, end));
    }
}
