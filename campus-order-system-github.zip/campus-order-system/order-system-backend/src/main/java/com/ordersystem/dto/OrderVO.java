package com.ordersystem.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class OrderVO {
    private Long id;
    private String orderNo;
    private String pickupNumber;
    private String pickupCode;
    private Long userId;
    private Long windowId;
    private String windowName;
    private String canteenName;
    private BigDecimal totalAmount;
    private Integer status;
    private String statusText;
    private String pickupTimeSlot;
    private String paymentMethod;
    private LocalDateTime createTime;
    private LocalDateTime paymentTime;
    private LocalDateTime finishTime;
    private List<OrderItemVO> items;
}
