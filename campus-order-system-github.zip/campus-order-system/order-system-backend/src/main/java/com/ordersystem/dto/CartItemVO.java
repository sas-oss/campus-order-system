package com.ordersystem.dto;

import lombok.Data;
import java.math.BigDecimal;

/**
 * 购物车项VO
 */
@Data
public class CartItemVO {
    private Long id;
    private Long menuId;
    private String menuName;
    private String categoryName;
    private BigDecimal price;
    private String imageUrl;
    private Integer quantity;
    private BigDecimal subtotal;
    private Integer stock;
    private Boolean soldOut;
    private Long canteenId;
    private String canteenName;
    private Long windowId;
    private String windowName;
}
