package com.ordersystem.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ordersystem.common.BusinessException;
import com.ordersystem.common.PageResult;
import com.ordersystem.common.ErrorCode;
import com.ordersystem.config.JwtUtils;
import com.ordersystem.dto.LoginRequest;
import com.ordersystem.dto.PasswordChangeRequest;
import com.ordersystem.dto.ProfileUpdateRequest;
import com.ordersystem.dto.RegisterRequest;
import com.ordersystem.dto.UserSaveRequest;
import com.ordersystem.dto.UserVO;
import com.ordersystem.entity.SysUser;
import com.ordersystem.entity.Window;
import com.ordersystem.mapper.SysUserMapper;
import com.ordersystem.mapper.WindowMapper;
import com.ordersystem.service.SysUserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SysUserServiceImpl implements SysUserService {

    private final SysUserMapper sysUserMapper;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtils jwtUtils;
    private final WindowMapper windowMapper;

    @Override
    public void register(RegisterRequest request) {
        if (!"STUDENT".equals(request.getRole())) {
            throw new BusinessException(ErrorCode.FORBIDDEN);
        }
        // 学生账号必须为纯数字学号（6-12位）
        if ("STUDENT".equals(request.getRole()) && !request.getUsername().matches("^[0-9]{6,12}$")) {
            throw new BusinessException(ErrorCode.INVALID_STUDENT_NUMBER);
        }
        LambdaQueryWrapper<SysUser> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(SysUser::getUsername, request.getUsername());
        if (sysUserMapper.selectCount(wrapper) > 0) {
            throw new BusinessException(ErrorCode.REGISTER_FAILED);
        }

        SysUser user = new SysUser();
        user.setUsername(request.getUsername());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRealName(request.getRealName());
        user.setPhone(request.getPhone());
        user.setStatus(1);
        user.setRoleId(roleIdFromCode(request.getRole()));
        sysUserMapper.insert(user);
    }

    @Override
    public LoginResponse login(LoginRequest request) {
        SysUser user = sysUserMapper.selectWithRoleByUsername(request.getUsername());
        if (user == null) {
            throw new BusinessException(ErrorCode.USER_NOT_FOUND);
        }
        if (user.getStatus() == null || user.getStatus() != 1) {
            throw new BusinessException(ErrorCode.USER_DISABLED);
        }
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new BusinessException(ErrorCode.INVALID_CREDENTIALS);
        }
        String roleCode = roleCodeFromId(user.getRoleId());
        if (!roleCode.equals(request.getRole())) {
            throw new BusinessException(ErrorCode.INVALID_CREDENTIALS);
        }
        String token = jwtUtils.generateToken(user.getId(), user.getUsername(), roleCode);
        return new LoginResponse(token, roleCode, toUserVO(user));
    }

    @Override
    public UserVO getProfile(Long userId) {
        SysUser user = sysUserMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException(ErrorCode.USER_NOT_FOUND);
        }
        return toUserVO(user);
    }

    @Override
    public void updateProfile(Long userId, ProfileUpdateRequest request) {
        SysUser existing = sysUserMapper.selectById(userId);
        if (existing == null) {
            throw new BusinessException(ErrorCode.USER_NOT_FOUND);
        }
        existing.setRealName(request.getRealName());
        existing.setPhone(request.getPhone());
        existing.setAvatar(request.getAvatar());
        sysUserMapper.updateById(existing);
    }

    @Override
    public void changePassword(Long userId, PasswordChangeRequest request) {
        SysUser user = sysUserMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException(ErrorCode.USER_NOT_FOUND);
        }
        if (!passwordEncoder.matches(request.getOldPassword(), user.getPassword())) {
            throw new BusinessException(ErrorCode.INVALID_CREDENTIALS);
        }
        if (request.getOldPassword().equals(request.getNewPassword())) {
            throw new BusinessException(ErrorCode.INVALID_PASSWORD_FORMAT);
        }
        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        sysUserMapper.updateById(user);
    }

    @Override
    public PageResult<UserVO> listUsers(String role, Integer status, int page, int size) {
        LambdaQueryWrapper<SysUser> wrapper = new LambdaQueryWrapper<>();
        if (role != null && !role.isBlank()) {
            wrapper.eq(SysUser::getRoleId, roleIdFromCode(role));
        }
        if (status != null) {
            wrapper.eq(SysUser::getStatus, status);
        }
        wrapper.orderByDesc(SysUser::getId);
        Page<SysUser> pageResult = sysUserMapper.selectPage(new Page<>(page, size), wrapper);
        List<UserVO> records = pageResult.getRecords().stream()
                .map(this::toUserVO)
                .collect(Collectors.toList());
        return new PageResult<>(records, pageResult.getTotal(), page, size);
    }

    @Override
    public void createUser(UserSaveRequest request) {
        validateManagedPassword(request.getPassword(), true);
        ensureUsernameAvailable(request.getUsername(), null);

        SysUser user = new SysUser();
        user.setUsername(request.getUsername());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRealName(request.getRealName());
        user.setPhone(request.getPhone());
        user.setStatus(request.getStatus() == null ? 1 : request.getStatus());
        applyRoleAndBinding(user, request);
        sysUserMapper.insert(user);
    }

    @Override
    public void updateUser(Long userId, UserSaveRequest request) {
        SysUser user = sysUserMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException(ErrorCode.USER_NOT_FOUND);
        }

        ensureUsernameAvailable(request.getUsername(), userId);

        user.setUsername(request.getUsername());
        user.setRealName(request.getRealName());
        user.setPhone(request.getPhone());
        user.setStatus(request.getStatus() == null ? user.getStatus() : request.getStatus());
        if (request.getPassword() != null && !request.getPassword().isBlank()) {
            validateManagedPassword(request.getPassword(), false);
            user.setPassword(passwordEncoder.encode(request.getPassword()));
        }
        applyRoleAndBinding(user, request);
        sysUserMapper.updateById(user);
    }

    @Override
    public void updateUserStatus(Long userId, Integer status) {
        SysUser user = sysUserMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException(ErrorCode.USER_NOT_FOUND);
        }
        user.setStatus(status);
        sysUserMapper.updateById(user);
    }

    private UserVO toUserVO(SysUser user) {
        UserVO userVO = new UserVO();
        userVO.setId(user.getId());
        userVO.setUsername(user.getUsername());
        userVO.setRealName(user.getRealName());
        userVO.setPhone(user.getPhone());
        userVO.setAvatar(user.getAvatar());
        userVO.setCanteenId(user.getCanteenId());
        userVO.setWindowId(user.getWindowId());
        userVO.setStatus(user.getStatus());
        userVO.setRole(roleCodeFromId(user.getRoleId()));
        userVO.setRoleName(roleNameFromId(user.getRoleId()));
        return userVO;
    }

    private void ensureUsernameAvailable(String username, Long currentUserId) {
        LambdaQueryWrapper<SysUser> wrapper = new LambdaQueryWrapper<SysUser>()
                .eq(SysUser::getUsername, username);
        if (currentUserId != null) {
            wrapper.ne(SysUser::getId, currentUserId);
        }
        if (sysUserMapper.selectCount(wrapper) > 0) {
            throw new BusinessException(ErrorCode.REGISTER_FAILED);
        }
    }

    private void applyRoleAndBinding(SysUser user, UserSaveRequest request) {
        user.setRoleId(roleIdFromCode(request.getRole()));
        if ("CANTEEN_ADMIN".equals(request.getRole())) {
            if (request.getWindowId() == null) {
                throw new BusinessException(ErrorCode.WINDOW_NOT_FOUND);
            }
            Window window = windowMapper.selectById(request.getWindowId());
            if (window == null) {
                throw new BusinessException(ErrorCode.WINDOW_NOT_FOUND);
            }
            user.setWindowId(window.getId());
            user.setCanteenId(window.getCanteenId());
            return;
        }
        user.setWindowId(null);
        user.setCanteenId(null);
    }

    private void validateManagedPassword(String password, boolean required) {
        if (password == null || password.isBlank()) {
            if (required) {
                throw new BusinessException(ErrorCode.INVALID_PASSWORD_FORMAT);
            }
            return;
        }
        if (password.length() < 6 || password.length() > 30) {
            throw new BusinessException(ErrorCode.INVALID_PASSWORD_FORMAT);
        }
    }

    private Long roleIdFromCode(String roleCode) {
        return switch (roleCode) {
            case "STUDENT" -> 1L;
            case "CANTEEN_ADMIN" -> 2L;
            case "SYSTEM_ADMIN" -> 3L;
            default -> throw new BusinessException("不支持的角色类型");
        };
    }

    private String roleCodeFromId(Long roleId) {
        if (roleId == null) {
            return "UNKNOWN";
        }
        return switch (roleId.intValue()) {
            case 1 -> "STUDENT";
            case 2 -> "CANTEEN_ADMIN";
            case 3 -> "SYSTEM_ADMIN";
            default -> "UNKNOWN";
        };
    }

    private String roleNameFromId(Long roleId) {
        if (roleId == null) {
            return "未知";
        }
        return switch (roleId.intValue()) {
            case 1 -> "学生";
            case 2 -> "食堂管理员";
            case 3 -> "系统管理员";
            default -> "未知";
        };
    }
}
