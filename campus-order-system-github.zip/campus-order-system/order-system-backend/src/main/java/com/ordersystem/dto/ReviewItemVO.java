package com.ordersystem.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ReviewItemVO {
    private Long id;
    private Long reviewId;
    private Long orderId;
    private Long menuId;
    private String menuName;
    private Integer score;
    private String content;
    private LocalDateTime createTime;
}
