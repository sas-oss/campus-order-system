package com.ordersystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 订单主表实体。
 * 状态：0-待支付 1-已支付待制作 2-制作中 3-制作完成待取餐 4-已取餐 5-已取消
 */
@Data
@TableName("order_info")
public class OrderInfo {
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 订单号（UUID 前 16 位） */
    private String orderNo;

    /** 取餐号（窗口前缀 + 自增序号，如 A001） */
    private String pickupNumber;

    /** 6 位取餐码，取餐时校验 */
    private String pickupCode;

    private Long userId;
    private Long windowId;
    private BigDecimal totalAmount;

    /** 0-5 */
    private Integer status;

    /** 取餐时段：11:30-12:00 / 12:00-12:30 / 12:30-13:00 */
    private String pickupTimeSlot;

    /** 支付方式：ALIPAY / WECHAT */
    private String paymentMethod;

    private LocalDateTime paymentTime;
    private LocalDateTime createTime;
    private LocalDateTime finishTime;
    private LocalDateTime cancelTime;
    private LocalDateTime updateTime;
}
