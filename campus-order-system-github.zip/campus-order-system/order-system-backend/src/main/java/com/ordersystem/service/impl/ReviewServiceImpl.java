package com.ordersystem.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ordersystem.common.BusinessException;
import com.ordersystem.common.ErrorCode;
import com.ordersystem.common.PageResult;
import com.ordersystem.dto.ReviewRequest;
import com.ordersystem.dto.ReviewItemVO;
import com.ordersystem.dto.ReviewStatisticsVO;
import com.ordersystem.dto.ReviewVO;
import com.ordersystem.entity.Canteen;
import com.ordersystem.entity.Menu;
import com.ordersystem.entity.OrderInfo;
import com.ordersystem.entity.OrderItem;
import com.ordersystem.entity.Review;
import com.ordersystem.entity.ReviewItem;
import com.ordersystem.entity.SysUser;
import com.ordersystem.entity.Window;
import com.ordersystem.mapper.CanteenMapper;
import com.ordersystem.mapper.MenuMapper;
import com.ordersystem.mapper.OrderInfoMapper;
import com.ordersystem.mapper.OrderItemMapper;
import com.ordersystem.mapper.ReviewItemMapper;
import com.ordersystem.mapper.ReviewMapper;
import com.ordersystem.mapper.SysUserMapper;
import com.ordersystem.mapper.WindowMapper;
import com.ordersystem.service.MessageService;
import com.ordersystem.service.ReviewService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 评价服务实现。
 * 评价结构：review（窗口整体评分+回复）+ review_item（每个菜品的独立评分）。
 * 业务规则：仅已取餐订单可评价、每个订单只能评价一次、菜品评分项必须属于本订单。
 */
@Service
@RequiredArgsConstructor
public class ReviewServiceImpl implements ReviewService {

    private final ReviewMapper reviewMapper;
    private final OrderInfoMapper orderInfoMapper;
    private final OrderItemMapper orderItemMapper;
    private final ReviewItemMapper reviewItemMapper;
    private final WindowMapper windowMapper;
    private final MenuMapper menuMapper;
    private final SysUserMapper sysUserMapper;
    private final CanteenMapper canteenMapper;
    private final MessageService messageService;

    /**
     * 提交评价。
     * 前置校验：订单归属 + 状态=4（已取餐）+ 未重复评价。
     * 写入 review（窗口评分）+ review_item（每个菜品评分），菜品必须属于本订单。
     */
    @Override
    @Transactional
    public void submitReview(Long userId, ReviewRequest request) {
        // 校验订单归属
        OrderInfo order = orderInfoMapper.selectById(request.getOrderId());
        if (order == null || !order.getUserId().equals(userId)) {
            throw new BusinessException(ErrorCode.ORDER_NOT_FOUND);
        }
        // 只有已取餐（状态=4）才能评价
        if (order.getStatus() != 4) {
            throw new BusinessException(ErrorCode.REVIEW_ORDER_NOT_COMPLETED);
        }
        // 一个订单只能评价一次
        long existing = reviewMapper.selectCount(new LambdaQueryWrapper<Review>()
                .eq(Review::getOrderId, request.getOrderId())
                .eq(Review::getUserId, userId));
        if (existing > 0) {
            throw new BusinessException(ErrorCode.REVIEW_ALREADY_SUBMITTED);
        }

        Integer windowScore = request.effectiveWindowScore();
        if (windowScore == null) {
            throw new BusinessException(ErrorCode.SYSTEM_ERROR.getCode(), "窗口评分不能为空");
        }

        // 获取订单中的菜品 ID 列表，用于校验菜品归属
        List<OrderItem> orderItems = orderItemMapper.selectList(new LambdaQueryWrapper<OrderItem>().eq(OrderItem::getOrderId, order.getId()));
        List<Long> orderMenuIds = orderItems.stream().map(OrderItem::getMenuId).toList();

        // 写入窗口评价
        Review review = new Review();
        review.setOrderId(order.getId());
        review.setUserId(userId);
        review.setWindowId(order.getWindowId());
        review.setMenuId(null);
        review.setScore(windowScore);
        review.setContent(request.getContent());
        reviewMapper.insert(review);

        // 写入每个菜品的独立评分，校验菜品属于本订单
        List<ReviewRequest.DishReviewItem> items = request.getItems() == null ? List.of() : request.getItems();
        for (ReviewRequest.DishReviewItem item : items) {
            if (!orderMenuIds.contains(item.getMenuId())) {
                throw new BusinessException(ErrorCode.MENU_NOT_FOUND);  // 防止评价非本订单菜品
            }
            ReviewItem reviewItem = new ReviewItem();
            reviewItem.setReviewId(review.getId());
            reviewItem.setOrderId(order.getId());
            reviewItem.setUserId(userId);
            reviewItem.setWindowId(order.getWindowId());
            reviewItem.setMenuId(item.getMenuId());
            reviewItem.setScore(item.getScore());
            reviewItem.setContent(item.getContent());
            reviewItemMapper.insert(reviewItem);
        }
    }

    @Override
    public PageResult<ReviewVO> listMyReviews(Long userId, int page, int size) {
        Page<Review> pageResult = reviewMapper.selectPage(new Page<>(page, size),
                new LambdaQueryWrapper<Review>().eq(Review::getUserId, userId).orderByDesc(Review::getId));
        return new PageResult<>(toVOs(pageResult.getRecords()), pageResult.getTotal(), page, size);
    }

    @Override
    public PageResult<ReviewVO> listWindowReviews(Long windowId, int page, int size) {
        Page<Review> pageResult = reviewMapper.selectPage(new Page<>(page, size),
                new LambdaQueryWrapper<Review>().eq(Review::getWindowId, windowId).orderByDesc(Review::getId));
        return new PageResult<>(toVOs(pageResult.getRecords()), pageResult.getTotal(), page, size);
    }

    /** 查询某窗口全部评价（不分页），用于统计 */
    private List<ReviewVO> listWindowReviewsAll(Long windowId) {
        return toVOs(reviewMapper.selectList(new LambdaQueryWrapper<Review>()
                .eq(Review::getWindowId, windowId)
                .orderByDesc(Review::getId)));
    }

    /**
     * 管理员回复评价。
     * 校验管理员绑定窗口与评价所属窗口一致，回复后发送站内信通知学生。
     */
    @Override
    public void replyReview(Long reviewId, String content, Long adminId) {
        Review review = reviewMapper.selectById(reviewId);
        if (review == null) throw new BusinessException(ErrorCode.SYSTEM_ERROR);

        // 校验管理员窗口归属
        SysUser admin = sysUserMapper.selectById(adminId);
        if (admin == null || (admin.getWindowId() != null && !admin.getWindowId().equals(review.getWindowId()))) {
            throw new BusinessException(ErrorCode.FORBIDDEN);
        }

        review.setReplyContent(content);
        review.setReplyTime(LocalDateTime.now());
        reviewMapper.updateById(review);

        // 回复后通知学生
        messageService.createMessage(review.getUserId(), "评价回复通知",
                "您提交的评价已收到管理员回复：" + content, 3);
    }

    @Override
    public ReviewStatisticsVO getWindowStatistics(Long windowId) {
        return buildStatistics(windowId, listWindowReviewsAll(windowId));
    }

    /** 全平台各窗口评价统计，通过 groupBy windowId 实现 */
    @Override
    public List<ReviewStatisticsVO> getAllStatistics() {
        return reviewMapper.selectList(new LambdaQueryWrapper<Review>()).stream()
                .collect(Collectors.groupingBy(Review::getWindowId))
                .entrySet()
                .stream()
                .map(entry -> buildStatistics(entry.getKey(), toVOs(entry.getValue())))
                .toList();
    }

    /** 构建评价统计：总数、均分、差评数（<=2 分），填充窗口/食堂名称 */
    private ReviewStatisticsVO buildStatistics(Long windowId, List<ReviewVO> reviews) {
        ReviewStatisticsVO statisticsVO = new ReviewStatisticsVO();
        statisticsVO.setWindowId(windowId);
        Window window = windowMapper.selectById(windowId);
        if (window != null) {
            statisticsVO.setWindowName(window.getName());
            statisticsVO.setCanteenId(window.getCanteenId());
            Canteen canteen = canteenMapper.selectById(window.getCanteenId());
            if (canteen != null) {
                statisticsVO.setCanteenName(canteen.getName());
            }
        } else {
            statisticsVO.setWindowName("");
        }
        statisticsVO.setTotalReviews((long) reviews.size());
        statisticsVO.setAverageScore(reviews.isEmpty() ? 0D : reviews.stream().mapToInt(ReviewVO::getScore).average().orElse(0D));
        statisticsVO.setNegativeReviews(reviews.stream().filter(review -> review.getScore() <= 2).count());  // <=2 分视为差评
        return statisticsVO;
    }

    /**
     * Entity → VO 批量转换。
     * 批量加载用户/窗口/菜品/review_item，拼接完整评价信息。
     */
    private List<ReviewVO> toVOs(List<Review> reviews) {
        if (reviews.isEmpty()) return List.of();

        // 批量加载关联数据
        Map<Long, SysUser> userMap = sysUserMapper.selectBatchIds(reviews.stream().map(Review::getUserId).distinct().toList())
                .stream().collect(Collectors.toMap(SysUser::getId, Function.identity()));
        Map<Long, Window> windowMap = windowMapper.selectBatchIds(reviews.stream().map(Review::getWindowId).distinct().toList())
                .stream().collect(Collectors.toMap(Window::getId, Function.identity()));

        // review 表上的 menuId（可能为空）
        List<Long> reviewMenuIds = reviews.stream().map(Review::getMenuId).filter(id -> id != null).distinct().toList();
        Map<Long, Menu> menuMap = reviewMenuIds.isEmpty()
                ? Map.of()
                : menuMapper.selectBatchIds(reviewMenuIds).stream().collect(Collectors.toMap(Menu::getId, Function.identity()));

        // 加载每个 review 下的 review_item（菜品评分明细）
        Map<Long, List<ReviewItem>> reviewItemsMap = reviewItemMapper.selectList(new LambdaQueryWrapper<ReviewItem>()
                        .in(ReviewItem::getReviewId, reviews.stream().map(Review::getId).toList()))
                .stream().collect(Collectors.groupingBy(ReviewItem::getReviewId));

        // 加载 review_item 中引用的菜品名称
        List<Long> itemMenuIds = reviewItemsMap.values().stream()
                .flatMap(List::stream).map(ReviewItem::getMenuId)
                .filter(id -> id != null).distinct().toList();
        Map<Long, Menu> itemMenuMap = itemMenuIds.isEmpty()
                ? Map.of()
                : menuMapper.selectBatchIds(itemMenuIds).stream().collect(Collectors.toMap(Menu::getId, Function.identity()));

        return reviews.stream().map(review -> {
            ReviewVO vo = new ReviewVO();
            vo.setId(review.getId());
            vo.setOrderId(review.getOrderId());
            vo.setUserId(review.getUserId());
            vo.setWindowId(review.getWindowId());
            vo.setMenuId(review.getMenuId());
            vo.setScore(review.getScore());
            vo.setContent(review.getContent());
            vo.setReplyContent(review.getReplyContent());
            vo.setReplyTime(review.getReplyTime());
            vo.setCreateTime(review.getCreateTime());

            // 填充评价人信息
            SysUser user = userMap.get(review.getUserId());
            if (user != null) {
                vo.setUsername(user.getUsername());
                vo.setRealName(user.getRealName());
            }
            // 填充窗口名称
            Window window = windowMap.get(review.getWindowId());
            if (window != null) vo.setWindowName(window.getName());
            // 填充菜品名称
            Menu menu = review.getMenuId() == null ? null : menuMap.get(review.getMenuId());
            if (menu != null) vo.setMenuName(menu.getName());

            // 填充菜品评分明细
            vo.setItems(reviewItemsMap.getOrDefault(review.getId(), List.of()).stream().map(item -> {
                ReviewItemVO itemVO = new ReviewItemVO();
                itemVO.setId(item.getId());
                itemVO.setReviewId(item.getReviewId());
                itemVO.setOrderId(item.getOrderId());
                itemVO.setMenuId(item.getMenuId());
                itemVO.setScore(item.getScore());
                itemVO.setContent(item.getContent());
                itemVO.setCreateTime(item.getCreateTime());
                Menu itemMenu = item.getMenuId() == null ? null : itemMenuMap.get(item.getMenuId());
                if (itemMenu != null) itemVO.setMenuName(itemMenu.getName());
                return itemVO;
            }).toList());
            return vo;
        }).toList();
    }
}
