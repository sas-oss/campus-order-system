package com.ordersystem.task;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ordersystem.entity.OrderInfo;
import com.ordersystem.mapper.OrderInfoMapper;
import com.ordersystem.service.MessageService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class PickupRemindTask {

    private final OrderInfoMapper orderInfoMapper;
    private final MessageService messageService;

    /**
     * 每60秒扫描一次。
     * 首次提醒：制作完成后 30~31 分钟窗口内发送一次"超时提醒"。
     * 二次提醒：制作完成后 60~61 分钟窗口内发送一次"二次提醒"。
     * 时间窗口设计确保每条订单在每个阶段只被提醒一次。
     */
    @Scheduled(fixedDelay = 60000)
    public void remindTimeoutPickup() {
        LocalDateTime now = LocalDateTime.now();
        // 首次提醒：30~31 分钟前完成
        LocalDateTime firstWindowStart = now.minusMinutes(31);
        LocalDateTime firstWindowEnd = now.minusMinutes(30);
        List<OrderInfo> firstRemindOrders = orderInfoMapper.selectList(new LambdaQueryWrapper<OrderInfo>()
                .eq(OrderInfo::getStatus, 3)
                .ge(OrderInfo::getUpdateTime, firstWindowStart)
                .le(OrderInfo::getUpdateTime, firstWindowEnd));
        for (OrderInfo order : firstRemindOrders) {
            messageService.createMessage(order.getUserId(), "请尽快取餐",
                    "您的订单（取餐号：" + order.getPickupNumber() + "）已完成超过30分钟，请尽快前往窗口领取。", 2);
            log.info("首次取餐提醒已发送: orderId={}, pickupNumber={}", order.getId(), order.getPickupNumber());
        }

        // 二次提醒：60~61 分钟前完成
        LocalDateTime secondWindowStart = now.minusMinutes(61);
        LocalDateTime secondWindowEnd = now.minusMinutes(60);
        List<OrderInfo> secondRemindOrders = orderInfoMapper.selectList(new LambdaQueryWrapper<OrderInfo>()
                .eq(OrderInfo::getStatus, 3)
                .ge(OrderInfo::getUpdateTime, secondWindowStart)
                .le(OrderInfo::getUpdateTime, secondWindowEnd));
        for (OrderInfo order : secondRemindOrders) {
            messageService.createMessage(order.getUserId(), "二次提醒：请尽快取餐",
                    "您的订单（取餐号：" + order.getPickupNumber() + "）已完成超过60分钟仍未取餐，请立即前往窗口领取！", 2);
            log.info("二次取餐提醒已发送: orderId={}, pickupNumber={}", order.getId(), order.getPickupNumber());
        }
    }
}
