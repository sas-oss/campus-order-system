package com.ordersystem.db;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.io.FileNotFoundException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Component
public class DemoDataInitializer implements ApplicationRunner {

    private final JdbcTemplate jdbcTemplate;
    private final ResourceLoader resourceLoader;
    @Value("${demo-data.enabled:true}")
    private boolean enabled;

    public DemoDataInitializer(JdbcTemplate jdbcTemplate, ResourceLoader resourceLoader) {
        this.jdbcTemplate = jdbcTemplate;
        this.resourceLoader = resourceLoader;
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        run();
    }

    void run() throws Exception {
        if (!enabled) {
            return;
        }
        if (!hasSchema()) {
            runScript("classpath:db/init.sql");
            log.info("Database schema initialized from db/init.sql");
        }
        if (hasDemoData()) {
            return;
        }
        String seedLocation = resolveDemoDataLocation();
        if (seedLocation == null) {
            log.warn("No demo data script found, skipping demo data initialization");
            return;
        }
        runScript(seedLocation);
        log.info("Demo data initialized from {}", seedLocation);
    }

    private void runScript(String location) throws Exception {
        boolean h2Database = isH2Database();
        Resource resource = resourceLoader.getResource(location);
        String script = new String(resource.getInputStream().readAllBytes(), StandardCharsets.UTF_8)
                .replace("\uFEFF", "")
                .lines()
                .map(String::trim)
                .filter(line -> !line.startsWith("--") && !line.startsWith("/*!"))
                .reduce("", (left, right) -> left + System.lineSeparator() + right);
        for (String sql : Arrays.stream(script.split(";")).map(String::trim).filter(item -> !item.isBlank()).toList()) {
            if (isScriptControlStatement(sql)) {
                continue;
            }
            String executableSql = h2Database ? adaptSqlForH2(sql) : sql;
            if (executableSql.isBlank()) {
                continue;
            }
            jdbcTemplate.execute(executableSql);
        }
    }

    private boolean hasSchema() {
        try {
            jdbcTemplate.queryForObject("SELECT COUNT(*) FROM sys_role", Integer.class);
            jdbcTemplate.queryForObject("SELECT COUNT(*) FROM order_info", Integer.class);
            jdbcTemplate.queryForObject("SELECT COUNT(*) FROM review", Integer.class);
            return true;
        } catch (Exception exception) {
            return false;
        }
    }

    private boolean hasDemoData() {
        try {
            Integer userCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM sys_user", Integer.class);
            Integer windowCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM canteen_window", Integer.class);
            Integer menuCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM menu", Integer.class);
            Integer orderCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM order_info", Integer.class);
            Integer reviewCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM review", Integer.class);
            Integer messageCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM message", Integer.class);
            return safeCount(userCount) >= 6
                    && safeCount(windowCount) >= 12
                    && safeCount(menuCount) >= 48
                    && safeCount(orderCount) >= 9
                    && safeCount(reviewCount) >= 3
                    && safeCount(messageCount) >= 6;
        } catch (Exception exception) {
            return false;
        }
    }

    private boolean resourceExists(String location) {
        Resource resource = resourceLoader.getResource(location);
        try {
            if (resource.exists()) {
                return true;
            }
            if (resourceLoader instanceof ResourcePatternResolver resolver) {
                return resolver.getResources(location).length > 0;
            }
            resource.getInputStream().close();
            return true;
        } catch (FileNotFoundException exception) {
            return false;
        } catch (Exception exception) {
            log.warn("Unable to verify resource {}, treating it as unavailable", location, exception);
            return false;
        }
    }

    private int safeCount(Integer count) {
        return count == null ? 0 : count;
    }

    private String resolveDemoDataLocation() {
        if (resourceExists("classpath:db/test-data.sql")) {
            return "classpath:db/test-data.sql";
        }
        if (resourceExists("classpath:db/init.sql")) {
            return "classpath:db/init.sql";
        }
        return null;
    }

    static boolean isScriptControlStatement(String sql) {
        return sql.startsWith("CREATE DATABASE")
                || sql.startsWith("USE ")
                || sql.startsWith("SOURCE ")
                || sql.startsWith("SET FOREIGN_KEY_CHECKS");
    }

    static String adaptSqlForH2(String sql) {
        String adapted = sql
                .replace("CURDATE()", "CURRENT_DATE")
                .replaceAll("(?i)\\s+COLLATE\\s+utf8mb4_unicode_ci", "")
                .replaceAll("(?i)\\s+ON UPDATE CURRENT_TIMESTAMP", "")
                .replaceAll("(?i)\\s+ENGINE=InnoDB", "")
                .replaceAll("(?i)\\s+AUTO_INCREMENT=\\d+", "")
                .replaceAll("(?i)\\s+DEFAULT CHARSET=utf8mb4", "")
                .replaceAll("(?m)^\\s*KEY\\s+`[^`]+`\\s*\\([^\\n]+\\),?\\s*$", "")
                .replaceAll("UNIQUE KEY `[^`]+` \\(([^)]+)\\)", "UNIQUE ($1)")
                .replaceAll(",\\s*\\)", System.lineSeparator() + ")")
                .replaceAll(System.lineSeparator() + "{2,}", System.lineSeparator());

        Pattern timestampPattern = Pattern.compile("TIMESTAMP\\(CURRENT_DATE, '([0-9]{2}):([0-9]{2}):([0-9]{2})'\\)");
        Matcher matcher = timestampPattern.matcher(adapted);
        StringBuffer buffer = new StringBuffer();
        while (matcher.find()) {
            int totalSeconds = Integer.parseInt(matcher.group(1)) * 3600
                    + Integer.parseInt(matcher.group(2)) * 60
                    + Integer.parseInt(matcher.group(3));
            matcher.appendReplacement(buffer, "DATEADD('SECOND', " + totalSeconds + ", CURRENT_DATE)");
        }
        matcher.appendTail(buffer);
        return buffer.toString().trim();
    }

    private boolean isH2Database() {
        try (Connection connection = jdbcTemplate.getDataSource().getConnection()) {
            return connection.getMetaData().getURL().startsWith("jdbc:h2:");
        } catch (Exception exception) {
            return false;
        }
    }
}
