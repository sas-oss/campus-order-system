package com.ordersystem.service;

import com.ordersystem.common.PageResult;
import com.ordersystem.dto.LoginRequest;
import com.ordersystem.dto.PasswordChangeRequest;
import com.ordersystem.dto.ProfileUpdateRequest;
import com.ordersystem.dto.RegisterRequest;
import com.ordersystem.dto.UserSaveRequest;
import com.ordersystem.dto.UserVO;

public interface SysUserService {
    void register(RegisterRequest request);

    LoginResponse login(LoginRequest request);

    UserVO getProfile(Long userId);

    void updateProfile(Long userId, ProfileUpdateRequest request);

    void changePassword(Long userId, PasswordChangeRequest request);

    PageResult<UserVO> listUsers(String role, Integer status, int page, int size);

    void createUser(UserSaveRequest request);

    void updateUser(Long userId, UserSaveRequest request);

    void updateUserStatus(Long userId, Integer status);

    class LoginResponse {
        private final String token;
        private final String role;
        private final UserVO userInfo;

        public LoginResponse(String token, String role, UserVO userInfo) {
            this.token = token;
            this.role = role;
            this.userInfo = userInfo;
        }

        public String getToken() {
            return token;
        }

        public String getRole() {
            return role;
        }

        public UserVO getUserInfo() {
            return userInfo;
        }
    }
}
