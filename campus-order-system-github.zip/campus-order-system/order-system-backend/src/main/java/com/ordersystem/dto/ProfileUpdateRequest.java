package com.ordersystem.dto;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * 更新个人信息请求 DTO
 */
@Data
public class ProfileUpdateRequest {
    @Size(min = 1, max = 20, message = "姓名长度为1-20个字符")
    private String realName;

    @Pattern(regexp = "^(1[3-9]\\d{9})?$", message = "手机号格式不正确")
    private String phone;

    private String avatar;
}
