package com.ordersystem.controller;

import com.ordersystem.common.Result;
import com.ordersystem.dto.MenuQueryDTO;
import com.ordersystem.dto.MenuRequest;
import com.ordersystem.dto.StockUpdateRequest;
import com.ordersystem.service.MenuService;
import com.ordersystem.utils.AuthUtil;
import com.ordersystem.utils.FileUploadUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.time.LocalDate;

@Tag(name = "菜单管理")
@RestController
@RequestMapping("/api/menus")
@RequiredArgsConstructor
public class MenuController {

    private final MenuService menuService;
    private final FileUploadUtil fileUploadUtil;

    @GetMapping
    @Operation(summary = "获取菜单列表")
    public Result<?> list(MenuQueryDTO query,
                          @RequestParam(defaultValue = "1") int page,
                          @RequestParam(defaultValue = "10") int size) {
        return Result.success(menuService.listMenus(query, page, size));
    }

    @GetMapping("/{id}")
    @Operation(summary = "获取菜品详情")
    public Result<?> detail(@PathVariable Long id) {
        return Result.success(menuService.getMenuById(id));
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "新增菜品")
    public Result<?> create(@Valid @RequestBody MenuRequest request,
                            @RequestAttribute("role") String role,
                            @RequestAttribute("userId") Long userId) {
        AuthUtil.requireAnyRole(role, "CANTEEN_ADMIN", "SYSTEM_ADMIN");
        menuService.createMenu(request, userId);
        return Result.success();
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "鏂板鑿滃搧")
    public Result<?> createMultipart(@RequestParam Long windowId,
                                     @RequestParam String name,
                                     @RequestParam String category,
                                     @RequestParam BigDecimal price,
                                     @RequestParam Integer stock,
                                     @RequestParam(required = false) String description,
                                     @RequestParam(required = false) String imageUrl,
                                     @RequestParam(required = false) LocalDate saleDate,
                                     @RequestPart(value = "imageFile", required = false) MultipartFile imageFile,
                                     @RequestAttribute("role") String role,
                                     @RequestAttribute("userId") Long userId) {
        AuthUtil.requireAnyRole(role, "CANTEEN_ADMIN", "SYSTEM_ADMIN");
        menuService.createMenu(buildMultipartRequest(windowId, name, category, price, stock, description, imageUrl, saleDate, imageFile), userId);
        return Result.success();
    }

    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "编辑菜品")
    public Result<?> update(@PathVariable Long id,
                            @Valid @RequestBody MenuRequest request,
                            @RequestAttribute("role") String role,
                            @RequestAttribute("userId") Long userId) {
        AuthUtil.requireAnyRole(role, "CANTEEN_ADMIN", "SYSTEM_ADMIN");
        menuService.updateMenu(id, request, userId);
        return Result.success();
    }

    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "缂栬緫鑿滃搧")
    public Result<?> updateMultipart(@PathVariable Long id,
                                     @RequestParam Long windowId,
                                     @RequestParam String name,
                                     @RequestParam String category,
                                     @RequestParam BigDecimal price,
                                     @RequestParam Integer stock,
                                     @RequestParam(required = false) String description,
                                     @RequestParam(required = false) String imageUrl,
                                     @RequestParam(required = false) LocalDate saleDate,
                                     @RequestPart(value = "imageFile", required = false) MultipartFile imageFile,
                                     @RequestAttribute("role") String role,
                                     @RequestAttribute("userId") Long userId) {
        AuthUtil.requireAnyRole(role, "CANTEEN_ADMIN", "SYSTEM_ADMIN");
        menuService.updateMenu(id, buildMultipartRequest(windowId, name, category, price, stock, description, imageUrl, saleDate, imageFile), userId);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "删除菜品")
    public Result<?> delete(@PathVariable Long id,
                            @RequestAttribute("role") String role,
                            @RequestAttribute("userId") Long userId) {
        AuthUtil.requireAnyRole(role, "CANTEEN_ADMIN", "SYSTEM_ADMIN");
        menuService.deleteMenu(id, userId);
        return Result.success();
    }

    @PutMapping("/{id}/stock")
    @Operation(summary = "更新库存")
    public Result<?> updateStock(@PathVariable Long id,
                                 @Valid @RequestBody StockUpdateRequest request,
                                 @RequestAttribute("role") String role) {
        AuthUtil.requireAnyRole(role, "CANTEEN_ADMIN", "SYSTEM_ADMIN");
        menuService.updateStock(id, request.getStock());
        return Result.success();
    }

    private MenuRequest buildMultipartRequest(Long windowId,
                                              String name,
                                              String category,
                                              BigDecimal price,
                                              Integer stock,
                                              String description,
                                              String imageUrl,
                                              LocalDate saleDate,
                                              MultipartFile imageFile) {
        MenuRequest request = new MenuRequest();
        request.setWindowId(windowId);
        request.setName(name);
        request.setCategory(category);
        request.setPrice(price);
        request.setStock(stock);
        request.setDescription(description);
        request.setImageUrl(resolveImageUrl(imageUrl, imageFile));
        request.setSaleDate(saleDate);
        return request;
    }

    private String resolveImageUrl(String imageUrl, MultipartFile imageFile) {
        if (imageFile != null && !imageFile.isEmpty()) {
            return fileUploadUtil.upload(imageFile);
        }
        return imageUrl;
    }
}
