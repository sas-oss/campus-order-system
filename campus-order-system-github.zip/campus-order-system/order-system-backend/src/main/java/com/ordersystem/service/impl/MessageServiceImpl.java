package com.ordersystem.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ordersystem.common.PageResult;
import com.ordersystem.dto.MessageVO;
import com.ordersystem.entity.Message;
import com.ordersystem.mapper.MessageMapper;
import com.ordersystem.service.MessageService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 站内信服务实现。
 * 消息类型：1-订单提醒 2-取餐提醒 3-系统通知。
 */
@Service
@RequiredArgsConstructor
public class MessageServiceImpl implements MessageService {

    private final MessageMapper messageMapper;

    /** 创建消息，isRead 默认为 0（未读） */
    @Override
    public void createMessage(Long userId, String title, String content, Integer type) {
        Message message = new Message();
        message.setUserId(userId);
        message.setTitle(title);
        message.setContent(content);
        message.setType(type);
        message.setIsRead(0);
        messageMapper.insert(message);
    }

    /** 分页查询用户消息，按时间倒序 */
    @Override
    public PageResult<MessageVO> listByUser(Long userId, int page, int size) {
        Page<Message> pageResult = messageMapper.selectPage(new Page<>(page, size),
                new LambdaQueryWrapper<Message>()
                        .eq(Message::getUserId, userId)
                        .orderByDesc(Message::getId));
        List<MessageVO> records = pageResult.getRecords().stream()
                .map(this::toVO)
                .toList();
        return new PageResult<>(records, pageResult.getTotal(), page, size);
    }

    /** 获取未读消息数量 */
    @Override
    public Integer getUnreadCount(Long userId) {
        return Math.toIntExact(messageMapper.selectCount(new LambdaQueryWrapper<Message>()
                .eq(Message::getUserId, userId)
                .eq(Message::getIsRead, 0)));
    }

    /** 标记单条已读，校验消息归属该用户 */
    @Override
    public void markAsRead(Long id, Long userId) {
        Message message = messageMapper.selectById(id);
        if (message != null && message.getUserId().equals(userId)) {
            message.setIsRead(1);
            messageMapper.updateById(message);
        }
    }

    /** 一键全部标记已读 */
    @Override
    public void markAllAsRead(Long userId) {
        List<Message> unreadMessages = messageMapper.selectList(new LambdaQueryWrapper<Message>()
                .eq(Message::getUserId, userId)
                .eq(Message::getIsRead, 0));
        for (Message message : unreadMessages) {
            message.setIsRead(1);
            messageMapper.updateById(message);
        }
    }

    /** Entity → VO，type 数字转中文 */
    private MessageVO toVO(Message message) {
        MessageVO vo = new MessageVO();
        vo.setId(message.getId());
        vo.setTitle(message.getTitle());
        vo.setContent(message.getContent());
        vo.setType(message.getType());
        vo.setTypeText(switch (message.getType()) {
            case 1 -> "订单提醒";
            case 2 -> "取餐提醒";
            case 3 -> "系统通知";
            default -> "通知";
        });
        vo.setRead(message.getIsRead() != null && message.getIsRead() == 1);
        vo.setCreateTime(message.getCreateTime());
        return vo;
    }
}
