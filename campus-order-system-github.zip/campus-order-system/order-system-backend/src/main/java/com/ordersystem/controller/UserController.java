package com.ordersystem.controller;

import com.ordersystem.common.Result;
import com.ordersystem.dto.UserSaveRequest;
import com.ordersystem.dto.UserStatusUpdateRequest;
import com.ordersystem.service.SysUserService;
import com.ordersystem.utils.AuthUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@Tag(name = "用户管理")
@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final SysUserService sysUserService;

    @GetMapping
    @Operation(summary = "用户列表")
    public Result<?> list(@RequestParam(required = false) String role,
                          @RequestParam(required = false) Integer status,
                          @RequestParam(defaultValue = "1") int page,
                          @RequestParam(defaultValue = "10") int size,
                          @RequestAttribute("role") String currentRole) {
        AuthUtil.requireRole(currentRole, "SYSTEM_ADMIN");
        return Result.success(sysUserService.listUsers(role, status, page, size));
    }

    @PostMapping
    @Operation(summary = "新增用户")
    public Result<?> create(@Valid @RequestBody UserSaveRequest request,
                            @RequestAttribute("role") String currentRole) {
        AuthUtil.requireRole(currentRole, "SYSTEM_ADMIN");
        sysUserService.createUser(request);
        return Result.success();
    }

    @PutMapping("/{id}")
    @Operation(summary = "编辑用户")
    public Result<?> update(@PathVariable Long id,
                            @Valid @RequestBody UserSaveRequest request,
                            @RequestAttribute("role") String currentRole) {
        AuthUtil.requireRole(currentRole, "SYSTEM_ADMIN");
        sysUserService.updateUser(id, request);
        return Result.success();
    }

    @PutMapping("/{id}/status")
    @Operation(summary = "更新用户状态")
    public Result<?> updateStatus(@PathVariable Long id,
                                  @Valid @RequestBody UserStatusUpdateRequest request,
                                  @RequestAttribute("role") String currentRole) {
        AuthUtil.requireRole(currentRole, "SYSTEM_ADMIN");
        sysUserService.updateUserStatus(id, request.getStatus());
        return Result.success();
    }
}
