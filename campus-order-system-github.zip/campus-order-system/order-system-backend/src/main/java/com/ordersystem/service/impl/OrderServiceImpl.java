package com.ordersystem.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ordersystem.common.BusinessException;
import com.ordersystem.common.ErrorCode;
import com.ordersystem.common.PageResult;
import com.ordersystem.dto.OrderCreateRequest;
import com.ordersystem.dto.OrderItemVO;
import com.ordersystem.dto.OrderVO;
import com.ordersystem.entity.Canteen;
import com.ordersystem.entity.Cart;
import com.ordersystem.entity.Menu;
import com.ordersystem.entity.OrderInfo;
import com.ordersystem.entity.OrderItem;
import com.ordersystem.entity.SysUser;
import com.ordersystem.entity.Window;
import com.ordersystem.mapper.CanteenMapper;
import com.ordersystem.mapper.CartMapper;
import com.ordersystem.mapper.MenuMapper;
import com.ordersystem.mapper.OrderInfoMapper;
import com.ordersystem.mapper.OrderItemMapper;
import com.ordersystem.mapper.SysUserMapper;
import com.ordersystem.mapper.WindowMapper;
import com.ordersystem.service.MessageService;
import com.ordersystem.service.OrderService;
import com.ordersystem.utils.OrderStatusUtil;
import com.ordersystem.utils.PickupNumberGenerator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 订单服务实现，核心业务：下单、支付、取消、状态流转。
 */
@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final OrderInfoMapper orderInfoMapper;
    private final OrderItemMapper orderItemMapper;
    private final CartMapper cartMapper;
    private final MenuMapper menuMapper;
    private final WindowMapper windowMapper;
    private final CanteenMapper canteenMapper;
    private final SysUserMapper sysUserMapper;
    private final PickupNumberGenerator pickupNumberGenerator;
    private final MessageService messageService;

    /**
     * 下单：按窗口拆分购物车为多笔订单，校验库存并扣减，限制未完成订单不超过 3 个。
     */
    @Override
    @Transactional
    public List<OrderVO> createOrder(Long userId, OrderCreateRequest request) {
        // 获取购物车
        List<Cart> carts = cartMapper.selectList(new LambdaQueryWrapper<Cart>().eq(Cart::getUserId, userId));
        if (carts.isEmpty()) {
            throw new BusinessException(ErrorCode.CART_EMPTY);
        }

        // 按窗口分组
        Map<Long, List<Cart>> cartsByWindow = carts.stream()
                .collect(Collectors.groupingBy(Cart::getWindowId, LinkedHashMap::new, Collectors.toList()));

        // 未完成订单（状态 0/1/2/3）+ 本次新订单数不能超过 3
        long unfinishedCount = orderInfoMapper.selectCount(new LambdaQueryWrapper<OrderInfo>()
                .eq(OrderInfo::getUserId, userId)
                .in(OrderInfo::getStatus, List.of(0, 1, 2, 3)));
        if (unfinishedCount + cartsByWindow.size() > 3) {
            throw new BusinessException(ErrorCode.ORDER_LIMIT_EXCEEDED);
        }

        // 批量查询菜品，校验库存和窗口一致性
        Map<Long, Menu> menuMap = menuMapper.selectBatchIds(carts.stream().map(Cart::getMenuId).toList()).stream()
                .collect(Collectors.toMap(Menu::getId, Function.identity()));
        for (Cart cart : carts) {
            Menu menu = menuMap.get(cart.getMenuId());
            if (menu == null) throw new BusinessException(ErrorCode.MENU_NOT_FOUND);
            if (!cart.getWindowId().equals(menu.getWindowId())) throw new BusinessException(ErrorCode.CART_CROSS_WINDOW);
            if (menu.getStock() == null || menu.getStock() < cart.getQuantity()) throw new BusinessException(ErrorCode.INSUFFICIENT_STOCK);
        }

        // 扣减库存（用 SQL 行锁防超卖）
        for (Cart cart : carts) {
            deductStock(cart.getMenuId(), cart.getQuantity());
        }

        // 按窗口生成订单
        List<Long> orderIds = cartsByWindow.entrySet().stream().map(entry -> {
            Long windowId = entry.getKey();
            List<Cart> windowCarts = entry.getValue();

            // 计算窗口订单总金额
            BigDecimal totalAmount = windowCarts.stream()
                    .map(cart -> {
                        Menu menu = menuMap.get(cart.getMenuId());
                        return menu.getPrice().multiply(BigDecimal.valueOf(cart.getQuantity()));
                    })
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            // 创建订单主记录
            OrderInfo orderInfo = new OrderInfo();
            orderInfo.setOrderNo(UUID.randomUUID().toString().replace("-", "").substring(0, 16));
            orderInfo.setPickupNumber(pickupNumberGenerator.generate(windowId));
            orderInfo.setPickupCode(generatePickupCode());
            orderInfo.setUserId(userId);
            orderInfo.setWindowId(windowId);
            orderInfo.setTotalAmount(totalAmount);
            orderInfo.setStatus(0); // 待支付
            orderInfo.setPickupTimeSlot(request.getPickupTimeSlot());
            orderInfo.setPaymentMethod(request.getPaymentMethod());
            orderInfoMapper.insert(orderInfo);

            // 创建订单明细
            for (Cart cart : windowCarts) {
                Menu menu = menuMap.get(cart.getMenuId());
                OrderItem item = new OrderItem();
                item.setOrderId(orderInfo.getId());
                item.setMenuId(menu.getId());
                item.setMenuName(menu.getName());
                item.setQuantity(cart.getQuantity());
                item.setUnitPrice(menu.getPrice());
                item.setSubtotal(menu.getPrice().multiply(BigDecimal.valueOf(cart.getQuantity())));
                orderItemMapper.insert(item);
            }
            return orderInfo.getId();
        }).toList();

        // 清空购物车
        cartMapper.delete(new LambdaQueryWrapper<Cart>().eq(Cart::getUserId, userId));
        return orderIds.stream().map(orderId -> getDetail(orderId, userId, "STUDENT")).toList();
    }

    /** SQL 行锁扣减库存：stock = stock - quantity WHERE stock >= quantity */
    private void deductStock(Long menuId, Integer quantity) {
        if (quantity == null || quantity <= 0) return;
        LambdaUpdateWrapper<Menu> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.setSql("stock = stock - " + quantity)
                .eq(Menu::getId, menuId)
                .ge(Menu::getStock, quantity);
        int updated = menuMapper.update(null, updateWrapper);
        if (updated == 0) throw new BusinessException(ErrorCode.INSUFFICIENT_STOCK);
    }

    /** 支付：校验状态为待支付、未超时 30 分钟，支付后发站内信 */
    @Override
    @Transactional
    public OrderVO payOrder(Long orderId, Long userId, String paymentMethod) {
        OrderInfo order = ownedOrder(orderId, userId);
        if (order.getStatus() != 0) throw new BusinessException(ErrorCode.ORDER_STATUS_INVALID);
        if (order.getCreateTime() != null && order.getCreateTime().plusMinutes(30).isBefore(LocalDateTime.now())) {
            throw new BusinessException(ErrorCode.ORDER_EXPIRED);
        }
        order.setStatus(1);
        order.setPaymentMethod(paymentMethod);
        order.setPaymentTime(LocalDateTime.now());
        orderInfoMapper.updateById(order);
        messageService.createMessage(userId, "支付成功", "订单已支付，等待窗口制作", 1);
        return getDetail(orderId, userId, "STUDENT");
    }

    /** 取消订单：仅待支付/已支付待制作可取消，取消后恢复库存 */
    @Override
    @Transactional
    public OrderVO cancelOrder(Long orderId, Long userId) {
        OrderInfo order = ownedOrder(orderId, userId);
        if (order.getStatus() != 0 && order.getStatus() != 1) {
            throw new BusinessException(ErrorCode.ORDER_STATUS_INVALID);
        }
        // 恢复库存
        List<OrderItem> items = orderItemMapper.selectList(new LambdaQueryWrapper<OrderItem>().eq(OrderItem::getOrderId, orderId));
        for (OrderItem item : items) {
            Menu menu = menuMapper.selectById(item.getMenuId());
            if (menu != null) {
                menu.setStock(menu.getStock() + item.getQuantity());
                menuMapper.updateById(menu);
            }
        }
        order.setStatus(5);
        order.setCancelTime(LocalDateTime.now());
        orderInfoMapper.updateById(order);
        return getDetail(orderId, userId, "STUDENT");
    }

    /**
     * 管理员更新订单状态。
     * 合法流转：待制作(1)→制作中(2)→待取餐(3)→已取餐(4)。
     * 确认取餐(3→4)必须校验取餐码。
     */
    @Override
    @Transactional
    public OrderVO updateStatus(Long orderId, Integer status, Long adminId) {
        return updateStatus(orderId, status, adminId, null);
    }

    @Override
    @Transactional
    public OrderVO updateStatus(Long orderId, Integer status, Long adminId, String pickupCode) {
        OrderInfo order = orderInfoMapper.selectById(orderId);
        if (order == null) throw new BusinessException(ErrorCode.ORDER_NOT_FOUND);

        // 校验管理员归属窗口
        SysUser admin = sysUserMapper.selectById(adminId);
        if (admin == null) throw new BusinessException(ErrorCode.USER_NOT_FOUND);
        if (admin.getWindowId() != null && !admin.getWindowId().equals(order.getWindowId())) {
            throw new BusinessException(ErrorCode.FORBIDDEN);
        }

        // 硬编码合法状态流转
        boolean valid = (order.getStatus() == 1 && status == 2)
                || (order.getStatus() == 2 && status == 3)
                || (order.getStatus() == 3 && status == 4);
        if (!valid) throw new BusinessException(ErrorCode.ORDER_STATUS_INVALID);

        // 确认取餐必须校验取餐码
        if (status == 4 && (pickupCode == null || !pickupCode.equals(order.getPickupCode()))) {
            throw new BusinessException(ErrorCode.PICKUP_CODE_INVALID);
        }

        order.setStatus(status);
        if (status == 4) order.setFinishTime(LocalDateTime.now());
        orderInfoMapper.updateById(order);

        // 制作完成时发送取餐提醒站内信
        if (status == 3) {
            messageService.createMessage(order.getUserId(), "订单已完成",
                    "您的订单已制作完成，请前往窗口取餐。取餐号：" + order.getPickupNumber()
                            + "，取餐码：" + order.getPickupCode() + "。", 2);
        }
        return getDetail(orderId, order.getUserId(), "STUDENT");
    }

    @Override
    public PageResult<OrderVO> getUserOrders(Long userId, Integer status, int page, int size) {
        LambdaQueryWrapper<OrderInfo> wrapper = new LambdaQueryWrapper<OrderInfo>()
                .eq(OrderInfo::getUserId, userId).orderByDesc(OrderInfo::getId);
        if (status != null) wrapper.eq(OrderInfo::getStatus, status);
        Page<OrderInfo> pageResult = orderInfoMapper.selectPage(new Page<>(page, size), wrapper);
        return new PageResult<>(wrapperOrders(pageResult.getRecords(), true), pageResult.getTotal(), page, size);
    }

    @Override
    public PageResult<OrderVO> getWindowOrders(Long windowId, Integer status, int page, int size) {
        LambdaQueryWrapper<OrderInfo> wrapper = new LambdaQueryWrapper<OrderInfo>()
                .eq(OrderInfo::getWindowId, windowId).orderByDesc(OrderInfo::getId);
        if (status != null) wrapper.eq(OrderInfo::getStatus, status);
        Page<OrderInfo> pageResult = orderInfoMapper.selectPage(new Page<>(page, size), wrapper);
        return new PageResult<>(wrapperOrders(pageResult.getRecords(), false), pageResult.getTotal(), page, size);
    }

    /** 订单详情，按角色校验权限：学生只能看自己的，管理员只能看自己窗口的 */
    @Override
    public OrderVO getDetail(Long orderId, Long userId, String role) {
        OrderInfo order = orderInfoMapper.selectById(orderId);
        if (order == null) throw new BusinessException(ErrorCode.ORDER_NOT_FOUND);
        if ("STUDENT".equals(role) && !order.getUserId().equals(userId)) throw new BusinessException(ErrorCode.FORBIDDEN);
        if ("CANTEEN_ADMIN".equals(role)) {
            SysUser admin = sysUserMapper.selectById(userId);
            if (admin == null || admin.getWindowId() == null || !admin.getWindowId().equals(order.getWindowId())) {
                throw new BusinessException(ErrorCode.FORBIDDEN);
            }
        }
        return wrapperOrders(List.of(order), "STUDENT".equals(role)).get(0);
    }

    /** 查询用户自己的订单，否则抛异常 */
    private OrderInfo ownedOrder(Long orderId, Long userId) {
        OrderInfo order = orderInfoMapper.selectById(orderId);
        if (order == null) throw new BusinessException(ErrorCode.ORDER_NOT_FOUND);
        if (!order.getUserId().equals(userId)) throw new BusinessException(ErrorCode.FORBIDDEN);
        return order;
    }

    /** 订单实体列表 → VO 列表，批量加载窗口/食堂/订单明细，学生端包含取餐码 */
    private List<OrderVO> wrapperOrders(List<OrderInfo> orders, boolean includePickupCode) {
        if (orders.isEmpty()) return List.of();

        // 批量加载关联数据
        Map<Long, List<OrderItem>> itemsMap = orderItemMapper.selectList(new LambdaQueryWrapper<OrderItem>()
                        .in(OrderItem::getOrderId, orders.stream().map(OrderInfo::getId).toList()))
                .stream().collect(Collectors.groupingBy(OrderItem::getOrderId));
        Map<Long, Window> windowMap = windowMapper.selectBatchIds(orders.stream().map(OrderInfo::getWindowId).distinct().toList())
                .stream().collect(Collectors.toMap(Window::getId, Function.identity()));
        Map<Long, Canteen> canteenMap = canteenMapper.selectList(new LambdaQueryWrapper<>())
                .stream().collect(Collectors.toMap(Canteen::getId, Function.identity()));

        return orders.stream().map(order -> {
            OrderVO vo = new OrderVO();
            vo.setId(order.getId());
            vo.setOrderNo(order.getOrderNo());
            vo.setPickupNumber(order.getPickupNumber());
            if (includePickupCode) vo.setPickupCode(order.getPickupCode());
            vo.setUserId(order.getUserId());
            vo.setWindowId(order.getWindowId());
            vo.setTotalAmount(order.getTotalAmount());
            vo.setStatus(order.getStatus());
            vo.setStatusText(OrderStatusUtil.text(order.getStatus()));
            vo.setPickupTimeSlot(order.getPickupTimeSlot());
            vo.setPaymentMethod(order.getPaymentMethod());
            vo.setCreateTime(order.getCreateTime());
            vo.setPaymentTime(order.getPaymentTime());
            vo.setFinishTime(order.getFinishTime());

            // 填充窗口和食堂名称
            Window window = windowMap.get(order.getWindowId());
            if (window != null) {
                vo.setWindowName(window.getName());
                Canteen canteen = canteenMap.get(window.getCanteenId());
                if (canteen != null) vo.setCanteenName(canteen.getName());
            }

            // 填充订单明细
            List<OrderItemVO> itemVOs = itemsMap.getOrDefault(order.getId(), List.of()).stream().map(item -> {
                OrderItemVO itemVO = new OrderItemVO();
                itemVO.setMenuId(item.getMenuId());
                itemVO.setMenuName(item.getMenuName());
                itemVO.setQuantity(item.getQuantity());
                itemVO.setUnitPrice(item.getUnitPrice());
                itemVO.setSubtotal(item.getSubtotal());
                return itemVO;
            }).toList();
            vo.setItems(itemVOs);
            return vo;
        }).toList();
    }

    /** 生成 6 位随机取餐码 */
    private String generatePickupCode() {
        return String.valueOf(ThreadLocalRandom.current().nextInt(100000, 1000000));
    }
}
