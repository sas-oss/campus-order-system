package com.ordersystem.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 食堂请求DTO
 */
@Data
public class CanteenRequest {
    @NotBlank(message = "食堂名称不能为空")
    private String name;
    private String address;
    private String description;
}
