package com.ordersystem.controller;

import com.ordersystem.common.Result;
import com.ordersystem.service.StatisticsService;
import com.ordersystem.service.SysUserService;
import com.ordersystem.utils.AuthUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@Tag(name = "统计分析")
@RestController
@RequestMapping("/api/statistics")
@RequiredArgsConstructor
public class StatisticsController {

    private final StatisticsService statisticsService;
    private final SysUserService sysUserService;

    @GetMapping("/daily")
    @Operation(summary = "日订单统计")
    public Result<?> daily(@RequestAttribute("userId") Long userId,
                           @RequestAttribute("role") String role,
                           @RequestParam(required = false) String date) {
        AuthUtil.requireAnyRole(role, "CANTEEN_ADMIN", "SYSTEM_ADMIN");
        Long windowId = sysUserService.getProfile(userId).getWindowId();
        return Result.success(statisticsService.getDailyStats(windowId, parseDate(date)));
    }

    @GetMapping("/hot-dishes")
    @Operation(summary = "热门菜品")
    public Result<?> hotDishes(@RequestAttribute("userId") Long userId,
                               @RequestAttribute("role") String role,
                               @RequestParam(defaultValue = "7") int days) {
        AuthUtil.requireAnyRole(role, "CANTEEN_ADMIN", "SYSTEM_ADMIN");
        Long windowId = sysUserService.getProfile(userId).getWindowId();
        return Result.success(statisticsService.getHotDishes(windowId, days));
    }

    @GetMapping("/time-slots")
    @Operation(summary = "取餐时段分布")
    public Result<?> timeSlots(@RequestAttribute("userId") Long userId,
                               @RequestAttribute("role") String role,
                               @RequestParam(required = false) String date) {
        AuthUtil.requireAnyRole(role, "CANTEEN_ADMIN", "SYSTEM_ADMIN");
        Long windowId = sysUserService.getProfile(userId).getWindowId();
        return Result.success(statisticsService.getTimeSlotStats(windowId, parseDate(date)));
    }

    @GetMapping("/overview")
    @Operation(summary = "全局统计")
    public Result<?> overview(@RequestAttribute("role") String role) {
        AuthUtil.requireRole(role, "SYSTEM_ADMIN");
        return Result.success(statisticsService.getOverview());
    }

    @GetMapping("/rankings")
    @Operation(summary = "窗口评分排行")
    public Result<?> rankings(@RequestAttribute("role") String role) {
        AuthUtil.requireRole(role, "SYSTEM_ADMIN");
        return Result.success(statisticsService.getRankings());
    }

    @GetMapping("/order-trend")
    @Operation(summary = "全校订单量趋势")
    public Result<?> orderTrend(@RequestAttribute("role") String role,
                                @RequestParam(required = false) String startDate,
                                @RequestParam(required = false) String endDate,
                                @RequestParam(required = false) Integer days) {
        AuthUtil.requireRole(role, "SYSTEM_ADMIN");
        LocalDate end = parseDate(endDate);
        LocalDate start;
        if (startDate != null && !startDate.isBlank()) {
            start = LocalDate.parse(startDate);
        } else if (days != null && days > 0) {
            start = end.minusDays(days - 1L);
        } else {
            start = end.minusDays(6);
        }
        return Result.success(statisticsService.getOrderTrend(start, end));
    }

    private LocalDate parseDate(String value) {
        return value == null || value.isBlank() ? LocalDate.now() : LocalDate.parse(value);
    }
}
