package com.ordersystem.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * AI 点餐助手响应
 */
@Data
public class AiMealAssistantResponse {

    /** AI 生成的推荐回复文本 */
    private String reply;

    /** 推荐菜品所属食堂名称 */
    private String canteenName;

    /** 推荐菜品所属食堂 ID */
    private Long canteenId;

    /** 推荐菜品所属窗口名称 */
    private String windowName;

    /** 推荐菜品所属窗口 ID */
    private Long windowId;

    /** 推荐组合合计金额 */
    private BigDecimal totalAmount;

    /** 匹配到的用户需求标签 */
    private List<String> matchedTags;

    /** 推荐菜品列表 */
    private List<AiRecommendationVO> menus;
}
