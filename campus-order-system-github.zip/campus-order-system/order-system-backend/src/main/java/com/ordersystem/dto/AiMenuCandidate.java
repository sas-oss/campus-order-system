package com.ordersystem.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;

/**
 * AI 菜品候选，扁平化打包菜品/窗口/食堂信息，用于拼装 AI Prompt
 */
@Data
@AllArgsConstructor
public class AiMenuCandidate {

    /** 菜品 ID */
    private Long menuId;

    /** 菜品名称 */
    private String name;

    /** 分类（主食/小吃/饮料） */
    private String category;

    /** 单价 */
    private BigDecimal price;

    /** 库存 */
    private Integer stock;

    /** 窗口名称 */
    private String windowName;

    /** 食堂名称 */
    private String canteenName;
}
