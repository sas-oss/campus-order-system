package com.ordersystem.dto;

import jakarta.validation.constraints.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * 菜品请求DTO
 */
@Data
public class MenuRequest {
    @NotNull(message = "窗口ID不能为空")
    private Long windowId;
    @NotBlank(message = "菜品名称不能为空")
    private String name;
    @NotBlank(message = "分类不能为空")
    private String category;
    @NotNull(message = "价格不能为空")
    @DecimalMin(value = "0.01", message = "价格必须大于0")
    private BigDecimal price;
    @NotNull(message = "库存不能为空")
    @Min(value = 0, message = "库存不能为负数")
    private Integer stock;
    private String imageUrl;
    private String description;
    private LocalDate saleDate;
}
