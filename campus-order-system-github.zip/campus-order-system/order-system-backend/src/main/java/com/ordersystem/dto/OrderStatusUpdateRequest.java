package com.ordersystem.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class OrderStatusUpdateRequest {
    @NotNull(message = "订单状态不能为空")
    private Integer status;
    private String pickupCode;
}
