package com.ordersystem.controller;

import com.ordersystem.common.Result;
import com.ordersystem.dto.AiMealAssistantRequest;
import com.ordersystem.service.AiRecommendationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * AI 推荐控制器，提供今日推荐和点餐助手两个接口。
 */
@Tag(name = "AI 推荐")
@RestController
@RequestMapping("/api/ai")
@RequiredArgsConstructor
public class AiRecommendationController {

    private final AiRecommendationService aiRecommendationService;

    /** 获取今日 AI 推荐菜品，limit 默认 3，范围 1-6 */
    @GetMapping("/recommendations")
    @Operation(summary = "获取今日 AI 推荐菜品")
    public Result<?> recommendations(@RequestParam(defaultValue = "3") int limit) {
        return Result.success(aiRecommendationService.getTodayRecommendations(limit));
    }

    /** AI 点餐助手：根据偏好/口味/场景/预算推荐搭配，AI 不可用时本地兜底 */
    @PostMapping("/meal-assistant")
    @Operation(summary = "AI 点餐助手")
    public Result<?> mealAssistant(@RequestBody AiMealAssistantRequest request) {
        return Result.success(aiRecommendationService.createMealPlan(request));
    }
}
