package com.ordersystem.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class OrderTrendVO {
    private LocalDate date;
    private Integer orderCount;
    private Double revenue;
}
