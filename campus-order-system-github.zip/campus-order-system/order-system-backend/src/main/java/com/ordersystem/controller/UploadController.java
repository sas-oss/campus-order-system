package com.ordersystem.controller;

import com.ordersystem.common.Result;
import com.ordersystem.utils.AuthUtil;
import com.ordersystem.utils.FileUploadUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

@Tag(name = "文件上传")
@RestController
@RequestMapping("/api/upload")
@RequiredArgsConstructor
public class UploadController {

    private final FileUploadUtil fileUploadUtil;

    @PostMapping(value = "/menu-image", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "上传菜品图片")
    public Result<?> uploadMenuImage(@RequestPart("imageFile") MultipartFile imageFile,
                                     @RequestAttribute("role") String role,
                                     @RequestAttribute("userId") Long userId) {
        AuthUtil.requireAnyRole(role, "CANTEEN_ADMIN", "SYSTEM_ADMIN");
        String imageUrl = fileUploadUtil.upload(imageFile);
        if (imageUrl == null) {
            return Result.error(7001, "文件上传失败：文件为空或不是有效图片");
        }
        return Result.success(Map.of("imageUrl", imageUrl));
    }
}
