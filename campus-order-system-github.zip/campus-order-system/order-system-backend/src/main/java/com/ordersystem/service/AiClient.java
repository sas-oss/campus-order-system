package com.ordersystem.service;

import com.ordersystem.dto.AiMenuCandidate;
import com.ordersystem.dto.AiMealAssistantRequest;

import java.util.List;
import java.util.Map;

/**
 * AI 客户端接口，对接 OpenAI 兼容的 Chat Completions API。
 * api-key 未配置或调用失败时返回空结果，不抛异常。
 */
public interface AiClient {

    /** 为候选菜品生成推荐理由，返回 menuId → reason 映射 */
    Map<Long, String> generateRecommendationReasons(List<AiMenuCandidate> candidates);

    /** 根据用户需求和选中菜品生成点餐助手的自然语言回复 */
    String generateMealAssistantReply(AiMealAssistantRequest request,
                                      List<AiMenuCandidate> candidates,
                                      List<AiMenuCandidate> selectedMenus);
}
