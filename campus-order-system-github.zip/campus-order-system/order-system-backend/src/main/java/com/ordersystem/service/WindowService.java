package com.ordersystem.service;

import com.ordersystem.dto.*;
import java.util.List;

/**
 * 窗口服务接口
 */
public interface WindowService {
    List<WindowVO> listByCanteenId(Long canteenId);
    WindowVO getById(Long id);
    List<WindowVO> listByAdmin(Long adminWindowId);
    List<WindowVO> listForCurrentUser(Long canteenId, Long adminWindowId, String role, Long userId);
    void create(WindowRequest request, Long operatorId);
    void update(Long id, WindowRequest request, Long operatorId);
    void delete(Long id, Long operatorId);
}
