package com.ordersystem.dto;

import lombok.Data;

@Data
public class OverviewStatsVO {
    private Long totalUsers;
    private Long totalCanteens;
    private Long totalWindows;
    private Long totalOrders;
    private Double totalRevenue;
    private Long todayOrders;
    private Double todayRevenue;
}
