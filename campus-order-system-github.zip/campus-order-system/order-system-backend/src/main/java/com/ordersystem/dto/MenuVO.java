package com.ordersystem.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 菜品视图DTO
 */
@Data
public class MenuVO {
    private Long id;
    private Long windowId;
    private String windowName;
    private Long canteenId;
    private String canteenName;
    private String name;
    private String category;
    private BigDecimal price;
    private Integer stock;
    private Boolean soldOut;
    private String imageUrl;
    private String description;
    private Integer status;
    private LocalDate saleDate;
    private LocalDateTime createTime;
}
