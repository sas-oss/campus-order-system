package com.ordersystem.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI orderSystemOpenApi() {
        return new OpenAPI()
                .info(new Info()
                        .title("校园食堂在线订餐系统接口文档")
                        .version("1.0.0")
                        .description("Spring Boot + MyBatis-Plus + JWT")
                        .contact(new Contact().name("Codex")))
                .servers(List.of(new Server().url("/").description("default")));
    }
}
