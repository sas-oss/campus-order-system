package com.ordersystem.config;

import com.ordersystem.interceptor.JwtInterceptor;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.io.File;

/**
 * Web MVC 配置
 */
@Configuration
@RequiredArgsConstructor
public class WebMvcConfig implements WebMvcConfigurer {

    private final JwtInterceptor jwtInterceptor;
    @Value("${upload.path:./uploads/menu-images/}")
    private String uploadPath;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(jwtInterceptor)
                .addPathPatterns("/api/**")
                .excludePathPatterns(
                        "/api/auth/login",
                        "/api/auth/register",
                        "/uploads/**",
                        "/doc.html",
                        "/swagger-resources/**",
                        "/v3/api-docs/**",
                        "/webjars/**"
                );
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        File imageDirectory = new File(uploadPath);
        File uploadRoot = imageDirectory.getParentFile() == null ? imageDirectory : imageDirectory.getParentFile();
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations(
                        "file:" + uploadRoot.getAbsolutePath() + File.separator,
                        "file:uploads/",
                        "classpath:/static/uploads/"
                );
    }
}
