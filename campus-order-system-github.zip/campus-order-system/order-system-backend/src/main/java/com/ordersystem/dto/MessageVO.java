package com.ordersystem.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class MessageVO {
    private Long id;
    private String title;
    private String content;
    private Integer type;
    private String typeText;
    private Boolean read;
    private LocalDateTime createTime;
}
