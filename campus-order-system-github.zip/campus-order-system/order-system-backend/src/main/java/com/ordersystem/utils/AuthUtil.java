package com.ordersystem.utils;

import com.ordersystem.common.BusinessException;
import com.ordersystem.common.ErrorCode;

public final class AuthUtil {

    private AuthUtil() {
    }

    public static void requireRole(String role, String expectedRole) {
        if (!expectedRole.equals(role)) {
            throw new BusinessException(ErrorCode.FORBIDDEN);
        }
    }

    public static void requireAnyRole(String role, String... expectedRoles) {
        for (String expectedRole : expectedRoles) {
            if (expectedRole.equals(role)) {
                return;
            }
        }
        throw new BusinessException(ErrorCode.FORBIDDEN);
    }
}
