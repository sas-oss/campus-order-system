package com.ordersystem.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ordersystem.common.BusinessException;
import com.ordersystem.common.ErrorCode;
import com.ordersystem.dto.CartItemRequest;
import com.ordersystem.dto.CartItemVO;
import com.ordersystem.dto.CartVO;
import com.ordersystem.entity.Canteen;
import com.ordersystem.entity.Cart;
import com.ordersystem.entity.Menu;
import com.ordersystem.entity.Window;
import com.ordersystem.mapper.CanteenMapper;
import com.ordersystem.mapper.CartMapper;
import com.ordersystem.mapper.MenuMapper;
import com.ordersystem.mapper.WindowMapper;
import com.ordersystem.service.CartService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;
//购物车服务类
@Service
@RequiredArgsConstructor
public class CartServiceImpl implements CartService {

    private final CartMapper cartMapper;
    private final MenuMapper menuMapper;
    private final WindowMapper windowMapper;
    private final CanteenMapper canteenMapper;

    @Override
    public CartVO getCart(Long userId) {
        List<Cart> cartList = cartMapper.selectList(new LambdaQueryWrapper<Cart>()
                .eq(Cart::getUserId, userId)
                .orderByAsc(Cart::getId));
        CartVO cartVO = new CartVO();
        if (cartList.isEmpty()) {
            cartVO.setItems(List.of());
            cartVO.setTotalAmount(BigDecimal.ZERO);
            return cartVO;
        }
        Map<Long, Menu> menuMap = menuMapper.selectBatchIds(cartList.stream().map(Cart::getMenuId).toList()).stream()
                .collect(Collectors.toMap(Menu::getId, Function.identity(), (left, right) -> left));
        Map<Long, Window> windowMap = windowMapper.selectBatchIds(cartList.stream().map(Cart::getWindowId).distinct().toList()).stream()
                .collect(Collectors.toMap(Window::getId, Function.identity(), (left, right) -> left));
        List<Long> canteenIds = windowMap.values().stream()
                        .map(Window::getCanteenId)
                        .filter(Objects::nonNull)
                        .distinct()
                        .toList();
        Map<Long, Canteen> canteenMap = canteenIds.isEmpty()
                ? Map.of()
                : canteenMapper.selectBatchIds(canteenIds).stream()
                .collect(Collectors.toMap(Canteen::getId, Function.identity(), (left, right) -> left));
        List<CartItemVO> items = cartList.stream().map(cart -> {
            CartItemVO itemVO = new CartItemVO();
            itemVO.setId(cart.getId());
            itemVO.setMenuId(cart.getMenuId());
            itemVO.setQuantity(cart.getQuantity());
            itemVO.setWindowId(cart.getWindowId());
            Menu menu = menuMap.get(cart.getMenuId());
            if (menu != null) {
                itemVO.setMenuName(menu.getName());
                itemVO.setCategoryName(menu.getCategory());
                itemVO.setPrice(menu.getPrice());
                itemVO.setImageUrl(menu.getImageUrl());
                itemVO.setStock(menu.getStock());
                itemVO.setSoldOut(menu.getStock() == null || menu.getStock() <= 0);
                itemVO.setSubtotal(menu.getPrice().multiply(BigDecimal.valueOf(cart.getQuantity())));
            } else {
                itemVO.setSoldOut(true);
                itemVO.setSubtotal(BigDecimal.ZERO);
            }
            Window window = windowMap.get(cart.getWindowId());
            if (window != null) {
                itemVO.setWindowName(window.getName());
                itemVO.setCanteenId(window.getCanteenId());
                Canteen canteen = canteenMap.get(window.getCanteenId());
                if (canteen != null) {
                    itemVO.setCanteenName(canteen.getName());
                }
            }
            return itemVO;
        }).toList();
        cartVO.setItems(items);
        cartVO.setWindowId(cartList.get(0).getWindowId());
        cartVO.setTotalAmount(items.stream().map(CartItemVO::getSubtotal).reduce(BigDecimal.ZERO, BigDecimal::add));
        return cartVO;
    }

    @Override
    @Transactional
    public void addToCart(Long userId, CartItemRequest request) {
        Menu menu = menuMapper.selectById(request.getMenuId());
        if (menu == null) {
            throw new BusinessException(ErrorCode.MENU_NOT_FOUND);
        }
        Cart cart = cartMapper.selectOne(new LambdaQueryWrapper<Cart>()
                .eq(Cart::getUserId, userId)
                .eq(Cart::getMenuId, request.getMenuId()));
        if (cart == null) {
            validateStock(menu, request.getQuantity());
            cart = new Cart();
            cart.setUserId(userId);
            cart.setMenuId(menu.getId());
            cart.setWindowId(menu.getWindowId());
            cart.setQuantity(request.getQuantity());
            cartMapper.insert(cart);
            return;
        }
        int newQuantity = cart.getQuantity() + request.getQuantity();
        validateStock(menu, newQuantity);
        cart.setQuantity(newQuantity);
        cartMapper.updateById(cart);
    }

    @Override
    @Transactional
    public void updateQuantity(Long userId, Long cartId, Integer quantity) {
        Cart cart = ownedCart(userId, cartId);
        Menu menu = menuMapper.selectById(cart.getMenuId());
        if (menu == null) {
            throw new BusinessException(ErrorCode.MENU_NOT_FOUND);
        }
        validateStock(menu, quantity);
        cart.setQuantity(quantity);
        cartMapper.updateById(cart);
    }

    @Override
    @Transactional
    public void removeItem(Long userId, Long cartId) {
        Cart cart = ownedCart(userId, cartId);
        cartMapper.deleteById(cart.getId());
    }

    @Override
    @Transactional
    public void clearCart(Long userId) {
        cartMapper.delete(new LambdaQueryWrapper<Cart>().eq(Cart::getUserId, userId));
    }

    private Cart ownedCart(Long userId, Long cartId) {
        Cart cart = cartMapper.selectById(cartId);
        if (cart == null || !cart.getUserId().equals(userId)) {
            throw new BusinessException(ErrorCode.FORBIDDEN);
        }
        return cart;
    }

    private void validateStock(Menu menu, Integer quantity) {
        if (quantity == null || quantity <= 0) {
            return;
        }
        if (menu.getStock() == null || menu.getStock() < quantity) {
            throw new BusinessException(ErrorCode.INSUFFICIENT_STOCK);
        }
    }
}
