package com.ordersystem.dto;

import lombok.Data;

import java.math.BigDecimal;

/**
 * AI 点餐助手请求
 */
@Data
public class AiMealAssistantRequest {

    /** 自然语言偏好描述，如"想吃辣一点、要管饱" */
    private String preference;

    /** 口味标签，如"偏辣"、"清淡" */
    private String flavor;

    /** 场景标签，如"赶时间"、"午餐" */
    private String scene;

    /** 预算上限（元），未指定时从 preference 提取或默认 25 */
    private BigDecimal budget;
}
