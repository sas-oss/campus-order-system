package com.ordersystem.service;

import com.ordersystem.dto.CartItemRequest;
import com.ordersystem.dto.CartVO;

/**
 * 购物车服务接口
 */
public interface CartService {
    CartVO getCart(Long userId);
    void addToCart(Long userId, CartItemRequest request);
    void updateQuantity(Long userId, Long cartId, Integer quantity);
    void removeItem(Long userId, Long cartId);
    void clearCart(Long userId);
}
