package com.ordersystem.dto;

import lombok.Data;

@Data
public class DailyStatsVO {
    private Integer totalOrders;
    private Integer completedOrders;
    private Double totalRevenue;
    private Integer uniqueCustomers;
}
