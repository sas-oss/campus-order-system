package com.ordersystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ordersystem.entity.Menu;
import org.apache.ibatis.annotations.Mapper;

/**
 * 菜品 Mapper
 */
@Mapper
public interface MenuMapper extends BaseMapper<Menu> {
}
