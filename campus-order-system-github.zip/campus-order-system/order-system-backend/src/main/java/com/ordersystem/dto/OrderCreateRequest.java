package com.ordersystem.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class OrderCreateRequest {
    @NotBlank(message = "取餐时间段不能为空")
    private String pickupTimeSlot;
    @NotBlank(message = "支付方式不能为空")
    private String paymentMethod;
}
