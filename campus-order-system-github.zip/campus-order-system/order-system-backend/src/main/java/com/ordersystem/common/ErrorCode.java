package com.ordersystem.common;

/**
 * 业务错误码枚举，按模块分段：
 * 1xxx 用户，2xxx 食堂/窗口，3xxx 菜品，4xxx 购物车，5xxx 订单，6xxx 评价，7xxx 文件，401/403 权限，9999 系统。
 */
public enum ErrorCode {
    // 用户 1xxx
    USER_NOT_FOUND(1001, "用户不存在"),
    INVALID_CREDENTIALS(1002, "用户名或密码错误"),
    USER_DISABLED(1003, "用户已被禁用"),
    REGISTER_FAILED(1004, "注册失败，学号可能已存在"),
    INVALID_STUDENT_NUMBER(1005, "学生账号必须为6-12位数字学号"),
    INVALID_PASSWORD_FORMAT(1006, "密码长度至少6位"),

    // 食堂/窗口 2xxx
    CANTEEN_NOT_FOUND(2001, "食堂不存在"),
    WINDOW_NOT_FOUND(2002, "窗口不存在"),

    // 菜品 3xxx
    MENU_NOT_FOUND(3001, "菜品不存在"),
    MENU_OFF_SHELF(3002, "菜品已下架"),
    INSUFFICIENT_STOCK(3003, "库存不足"),

    // 购物车 4xxx
    CART_EMPTY(4001, "购物车为空"),
    CART_CROSS_WINDOW(4002, "购物车中不能包含不同窗口的菜品"),

    // 订单 5xxx
    ORDER_NOT_FOUND(5001, "订单不存在"),
    ORDER_STATUS_INVALID(5002, "订单状态不允许此操作"),
    ORDER_LIMIT_EXCEEDED(5003, "未取餐订单不能超过3个"),
    ORDER_EXPIRED(5004, "订单已超时，无法支付"),
    PICKUP_CODE_INVALID(5005, "取餐码不正确"),

    // 评价 6xxx
    REVIEW_ALREADY_SUBMITTED(6001, "您已经对该订单进行过评价"),
    REVIEW_ORDER_NOT_COMPLETED(6002, "只有已取餐的订单才能评价"),

    // 权限
    UNAUTHORIZED(401, "未登录或Token无效"),
    FORBIDDEN(403, "无权访问该资源"),

    // 文件 7xxx
    FILE_UPLOAD_FAILED(7001, "文件上传失败"),

    // 系统
    SYSTEM_ERROR(9999, "系统内部错误");

    private final int code;
    private final String message;

    ErrorCode(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() { return code; }
    public String getMessage() { return message; }
}
