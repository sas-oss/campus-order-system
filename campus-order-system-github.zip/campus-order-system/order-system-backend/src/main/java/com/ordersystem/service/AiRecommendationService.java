package com.ordersystem.service;

import com.ordersystem.dto.AiMealAssistantRequest;
import com.ordersystem.dto.AiMealAssistantResponse;
import com.ordersystem.dto.AiRecommendationVO;

import java.util.List;

/**
 * AI 推荐服务接口。AI 不可用时自动降级为本地规则。
 */
public interface AiRecommendationService {

    /** 获取今日推荐菜品，limit 限制 1-6 */
    List<AiRecommendationVO> getTodayRecommendations(int limit);

    /** AI 点餐助手：按预算和偏好推荐同窗口菜品搭配 */
    AiMealAssistantResponse createMealPlan(AiMealAssistantRequest request);
}
