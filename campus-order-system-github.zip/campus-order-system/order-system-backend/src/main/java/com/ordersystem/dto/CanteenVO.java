package com.ordersystem.dto;

import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 食堂视图DTO
 */
@Data
public class CanteenVO {
    private Long id;
    private String name;
    private String address;
    private String description;
    private Integer status;
    private LocalDateTime createTime;
    private Long orderCount;
    private Long totalOrders;
    private List<WindowSimpleVO> windows;

    @Data
    public static class WindowSimpleVO {
        private Long id;
        private String name;
        private Integer floor;
        private String pickupNumberPrefix;
        private Integer status;
    }
}
