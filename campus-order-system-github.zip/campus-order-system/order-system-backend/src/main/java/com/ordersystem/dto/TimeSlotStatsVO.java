package com.ordersystem.dto;

import lombok.Data;

@Data
public class TimeSlotStatsVO {
    private String timeSlot;
    private Integer orderCount;
}
