package com.ordersystem.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Data
public class ReviewRequest {
    @NotNull(message = "订单ID不能为空")
    private Long orderId;
    @Min(value = 1, message = "评分不能小于1")
    @Max(value = 5, message = "评分不能大于5")
    private Integer score;
    @Min(value = 1, message = "评分不能小于1")
    @Max(value = 5, message = "评分不能大于5")
    private Integer windowScore;
    private String content;
    @Valid
    private List<DishReviewItem> items;

    public Integer effectiveWindowScore() {
        return windowScore == null ? score : windowScore;
    }

    @Data
    public static class DishReviewItem {
        @NotNull(message = "菜品ID不能为空")
        private Long menuId;
        @NotNull(message = "菜品评分不能为空")
        @Min(value = 1, message = "评分不能小于1")
        @Max(value = 5, message = "评分不能大于5")
        private Integer score;
        private String content;
    }
}
