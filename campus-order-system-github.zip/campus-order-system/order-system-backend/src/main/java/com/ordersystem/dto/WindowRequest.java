package com.ordersystem.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 窗口请求DTO
 */
@Data
public class WindowRequest {
    @NotNull(message = "食堂ID不能为空")
    private Long canteenId;
    @NotBlank(message = "窗口名称不能为空")
    private String name;
    private Integer floor = 1;
    private String pickupNumberPrefix = "A";
}
