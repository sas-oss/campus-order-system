package com.ordersystem.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class OrderItemVO {
    private Long menuId;
    private String menuName;
    private Integer quantity;
    private BigDecimal unitPrice;
    private BigDecimal subtotal;
}
