package com.ordersystem.task;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ordersystem.entity.Menu;
import com.ordersystem.entity.OrderInfo;
import com.ordersystem.entity.OrderItem;
import com.ordersystem.mapper.MenuMapper;
import com.ordersystem.mapper.OrderInfoMapper;
import com.ordersystem.mapper.OrderItemMapper;
import com.ordersystem.service.MessageService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 订单超时自动取消定时任务。
 * 每 60 秒扫描一次，将创建超过 30 分钟仍待支付的订单自动取消并恢复库存。
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class OrderTimeoutTask {

    private final OrderInfoMapper orderInfoMapper;
    private final OrderItemMapper orderItemMapper;
    private final MenuMapper menuMapper;
    private final MessageService messageService;

    /** 每 60 秒执行一次：查询状态为 0 且超过 30 分钟的订单，取消并恢复库存 */
    @Scheduled(fixedDelay = 60000)
    @Transactional
    public void cancelExpiredOrders() {
        LocalDateTime threshold = LocalDateTime.now().minusMinutes(30);
        List<OrderInfo> expiredOrders = orderInfoMapper.selectList(new LambdaQueryWrapper<OrderInfo>()
                .eq(OrderInfo::getStatus, 0)
                .le(OrderInfo::getCreateTime, threshold));

        for (OrderInfo order : expiredOrders) {
            restoreStock(order.getId());
            order.setStatus(5);
            order.setCancelTime(LocalDateTime.now());
            orderInfoMapper.updateById(order);

            messageService.createMessage(order.getUserId(), "订单已取消",
                    "您的订单（取餐号：" + order.getPickupNumber() + "）因超时未支付已自动取消。", 3);
            log.info("超时订单已自动取消: orderId={}, pickupNumber={}", order.getId(), order.getPickupNumber());
        }
    }

    /** 恢复订单占用的库存 */
    private void restoreStock(Long orderId) {
        List<OrderItem> items = orderItemMapper.selectList(new LambdaQueryWrapper<OrderItem>()
                .eq(OrderItem::getOrderId, orderId));
        for (OrderItem item : items) {
            Menu menu = menuMapper.selectById(item.getMenuId());
            if (menu != null) {
                menu.setStock(menu.getStock() + item.getQuantity());
                menuMapper.updateById(menu);
            }
        }
    }
}
