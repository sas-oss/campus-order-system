package com.ordersystem.common;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * 全局异常处理器：将 BusinessException / 参数校验异常 / 未知异常统一转为 Result 响应。
 */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    /** 业务异常：返回对应错误码和消息 */
    @ExceptionHandler(BusinessException.class)
    public Result<?> handleBusinessException(BusinessException exception, HttpServletRequest request) {
        log.warn("Business exception on [{}]: {}", request.getRequestURI(), exception.getMessage());
        return Result.error(exception.getCode(), exception.getMessage());
    }

    /** @Valid 校验失败：提取字段错误信息 */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Result<?> handleMethodArgumentNotValidException(MethodArgumentNotValidException exception) {
        String message = exception.getBindingResult().getFieldErrors().stream()
                .map(error -> error.getField() + ": " + error.getDefaultMessage())
                .reduce((left, right) -> left + "; " + right)
                .orElse("参数校验失败");
        return Result.error(HttpStatus.BAD_REQUEST.value(), message);
    }

    /** 表单绑定失败 */
    @ExceptionHandler(BindException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Result<?> handleBindException(BindException exception) {
        String message = exception.getBindingResult().getFieldErrors().stream()
                .map(error -> error.getField() + ": " + error.getDefaultMessage())
                .reduce((left, right) -> left + "; " + right)
                .orElse("参数绑定失败");
        return Result.error(HttpStatus.BAD_REQUEST.value(), message);
    }

    /** 未知异常：记录日志，返回系统内部错误 */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public Result<?> handleException(Exception exception, HttpServletRequest request) {
        log.error("Unhandled exception on [{}]", request.getRequestURI(), exception);
        return Result.error(ErrorCode.SYSTEM_ERROR);
    }
}
