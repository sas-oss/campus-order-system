package com.ordersystem.service;

import com.ordersystem.common.PageResult;
import com.ordersystem.dto.OrderCreateRequest;
import com.ordersystem.dto.OrderVO;

import java.util.List;

public interface OrderService {
    List<OrderVO> createOrder(Long userId, OrderCreateRequest request);
    OrderVO payOrder(Long orderId, Long userId, String paymentMethod);
    OrderVO cancelOrder(Long orderId, Long userId);
    OrderVO updateStatus(Long orderId, Integer status, Long adminId);
    OrderVO updateStatus(Long orderId, Integer status, Long adminId, String pickupCode);
    PageResult<OrderVO> getUserOrders(Long userId, Integer status, int page, int size);
    PageResult<OrderVO> getWindowOrders(Long windowId, Integer status, int page, int size);
    OrderVO getDetail(Long orderId, Long userId, String role);
}
