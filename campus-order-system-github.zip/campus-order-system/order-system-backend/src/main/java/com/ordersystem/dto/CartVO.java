package com.ordersystem.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.util.List;

/**
 * 购物车VO
 */
@Data
public class CartVO {
    private List<CartItemVO> items;
    private BigDecimal totalAmount;
    private Long windowId;
}
