package com.ordersystem.dto;

import lombok.Data;

/**
 * 用户信息 VO（返回给前端）
 */
@Data
public class UserVO {
    private Long id;
    private String username;
    private String realName;
    private String phone;
    private String role;
    private String roleName;
    private String avatar;
    private Long canteenId;
    private Long windowId;
    private Integer status;
}
