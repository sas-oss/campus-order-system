package com.ordersystem.db;

import org.junit.jupiter.api.Test;
import org.springframework.core.io.Resource;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.ResourceLoader;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.FileNotFoundException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

class DemoDataInitializerTest {

    @Test
    void initializerSeedsEmptyDatabaseAndDoesNotDuplicateExistingData() throws Exception {
        DriverManagerDataSource dataSource = new DriverManagerDataSource(
                "jdbc:h2:mem:demo-init;MODE=MySQL;DATABASE_TO_UPPER=false;DB_CLOSE_DELAY=-1",
                "",
                ""
        );
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        try (Connection connection = dataSource.getConnection()) {
            runScript(connection, "/db/init.sql");
        }
        clearSeedRows(jdbcTemplate);

        DemoDataInitializer initializer = new DemoDataInitializer(jdbcTemplate, new DefaultResourceLoader());
        ReflectionTestUtils.setField(initializer, "enabled", true);

        initializer.run();
        initializer.run();

        assertEquals(48, jdbcTemplate.queryForObject("SELECT COUNT(*) FROM menu", Integer.class));
        assertEquals(12, jdbcTemplate.queryForObject("SELECT COUNT(*) FROM order_info", Integer.class));
        assertEquals(16, jdbcTemplate.queryForObject("SELECT COUNT(*) FROM message", Integer.class));
        assertEquals(10, jdbcTemplate.queryForObject("SELECT COUNT(*) FROM review_item", Integer.class));
    }

    @Test
    void initializerCreatesSchemaAndDemoDataWhenDatabaseIsBlank() throws Exception {
        DriverManagerDataSource dataSource = new DriverManagerDataSource(
                "jdbc:h2:mem:demo-init-blank;MODE=MySQL;DATABASE_TO_UPPER=false;DB_CLOSE_DELAY=-1",
                "",
                ""
        );
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        DemoDataInitializer initializer = new DemoDataInitializer(jdbcTemplate, new DefaultResourceLoader());
        ReflectionTestUtils.setField(initializer, "enabled", true);

        initializer.run();

        assertEquals(3, jdbcTemplate.queryForObject("SELECT COUNT(*) FROM canteen", Integer.class));
        assertEquals(48, jdbcTemplate.queryForObject("SELECT COUNT(*) FROM menu", Integer.class));
        assertEquals(12, jdbcTemplate.queryForObject("SELECT COUNT(*) FROM order_info", Integer.class));
        assertEquals(6, jdbcTemplate.queryForObject("SELECT COUNT(*) FROM review", Integer.class));
        assertEquals(10, jdbcTemplate.queryForObject("SELECT COUNT(*) FROM review_item", Integer.class));
    }

    @Test
    void initializerSkipsReseedingWhenDatabaseAlreadyContainsDemoDataFromPreviousDay() throws Exception {
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);
        ResourceLoader resourceLoader = mock(ResourceLoader.class);
        DemoDataInitializer initializer = new DemoDataInitializer(jdbcTemplate, resourceLoader);
        ReflectionTestUtils.setField(initializer, "enabled", true);

        stubSchemaCounts(jdbcTemplate);
        stubDemoCounts(jdbcTemplate, 6, 12, 48, 9, 3, 6, 0, 0, 0);
        when(resourceLoader.getResource(anyString())).thenThrow(new AssertionError("seed scripts should not be loaded"));

        assertDoesNotThrow(() -> initializer.run());
        verifyNoInteractions(resourceLoader);
    }

    @Test
    void initializerDoesNotFailStartupWhenSeedScriptIsMissing() throws Exception {
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);
        ResourceLoader resourceLoader = mock(ResourceLoader.class);
        Resource resource = mock(Resource.class);
        DemoDataInitializer initializer = new DemoDataInitializer(jdbcTemplate, resourceLoader);
        ReflectionTestUtils.setField(initializer, "enabled", true);

        stubSchemaCounts(jdbcTemplate);
        stubDemoCounts(jdbcTemplate, 1, 1, 1, 0, 0, 0, 0, 0, 0);
        when(resourceLoader.getResource("classpath:db/test-data.sql")).thenReturn(resource);
        when(resourceLoader.getResource("classpath:db/init.sql")).thenReturn(resource);
        when(resource.exists()).thenReturn(false);
        when(resource.getInputStream()).thenThrow(new FileNotFoundException("db/test-data.sql"));

        assertDoesNotThrow(() -> initializer.run());
    }

    private static void runScript(Connection connection, String resourceName) throws Exception {
        String script = new String(DemoDataInitializerTest.class.getResourceAsStream(resourceName).readAllBytes(), StandardCharsets.UTF_8)
                .replace("\uFEFF", "")
                .lines()
                .map(String::trim)
                .filter(line -> !line.startsWith("--") && !line.startsWith("/*!"))
                .reduce("", (left, right) -> left + System.lineSeparator() + right);
        try (var statement = connection.createStatement()) {
            for (String sql : Arrays.stream(script.split(";")).map(String::trim).filter(item -> !item.isBlank()).toList()) {
                if (DemoDataInitializer.isScriptControlStatement(sql)) {
                    continue;
                }
                statement.execute(DemoDataInitializer.adaptSqlForH2(sql));
            }
        }
    }

    private static void clearSeedRows(JdbcTemplate jdbcTemplate) {
        jdbcTemplate.execute("DELETE FROM message");
        jdbcTemplate.execute("DELETE FROM review_item");
        jdbcTemplate.execute("DELETE FROM review");
        jdbcTemplate.execute("DELETE FROM order_item");
        jdbcTemplate.execute("DELETE FROM order_info");
        jdbcTemplate.execute("DELETE FROM cart");
        jdbcTemplate.execute("DELETE FROM menu");
        jdbcTemplate.execute("DELETE FROM sys_user");
        jdbcTemplate.execute("DELETE FROM canteen_window");
        jdbcTemplate.execute("DELETE FROM canteen");
        jdbcTemplate.execute("DELETE FROM sys_role");
    }

    private static void stubSchemaCounts(JdbcTemplate jdbcTemplate) {
        when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM sys_role", Integer.class)).thenReturn(3);
        when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM order_info", Integer.class)).thenReturn(12);
        when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM review", Integer.class)).thenReturn(6);
    }

    private static void stubDemoCounts(
            JdbcTemplate jdbcTemplate,
            int userCount,
            int windowCount,
            int menuCount,
            int orderCount,
            int reviewCount,
            int messageCount,
            int todayMenuCount,
            int todayOrderCount,
            int todayMessageCount
    ) {
        when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM sys_user", Integer.class)).thenReturn(userCount);
        when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM canteen_window", Integer.class)).thenReturn(windowCount);
        when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM menu", Integer.class)).thenReturn(menuCount);
        when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM order_info", Integer.class)).thenReturn(orderCount);
        when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM review", Integer.class)).thenReturn(reviewCount);
        when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM message", Integer.class)).thenReturn(messageCount);
        when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM menu WHERE sale_date = CURDATE()", Integer.class)).thenReturn(todayMenuCount);
        when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM order_info WHERE CAST(create_time AS DATE) = CURDATE()", Integer.class)).thenReturn(todayOrderCount);
        when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM message WHERE CAST(create_time AS DATE) = CURDATE()", Integer.class)).thenReturn(todayMessageCount);
    }
}
