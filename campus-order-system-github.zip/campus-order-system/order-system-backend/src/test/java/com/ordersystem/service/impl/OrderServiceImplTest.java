package com.ordersystem.service.impl;

import com.ordersystem.common.BusinessException;
import com.ordersystem.common.ErrorCode;
import com.ordersystem.dto.OrderCreateRequest;
import com.ordersystem.dto.OrderVO;
import com.ordersystem.entity.Canteen;
import com.ordersystem.entity.Cart;
import com.ordersystem.entity.Menu;
import com.ordersystem.entity.OrderInfo;
import com.ordersystem.entity.OrderItem;
import com.ordersystem.entity.SysUser;
import com.ordersystem.entity.Window;
import com.ordersystem.mapper.CanteenMapper;
import com.ordersystem.mapper.CartMapper;
import com.ordersystem.mapper.MenuMapper;
import com.ordersystem.mapper.OrderInfoMapper;
import com.ordersystem.mapper.OrderItemMapper;
import com.ordersystem.mapper.SysUserMapper;
import com.ordersystem.mapper.WindowMapper;
import com.ordersystem.service.MessageService;
import com.ordersystem.utils.PickupNumberGenerator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OrderServiceImplTest {

    @Mock
    private OrderInfoMapper orderInfoMapper;
    @Mock
    private OrderItemMapper orderItemMapper;
    @Mock
    private CartMapper cartMapper;
    @Mock
    private MenuMapper menuMapper;
    @Mock
    private WindowMapper windowMapper;
    @Mock
    private CanteenMapper canteenMapper;
    @Mock
    private SysUserMapper sysUserMapper;
    @Mock
    private PickupNumberGenerator pickupNumberGenerator;
    @Mock
    private MessageService messageService;
    @InjectMocks
    private OrderServiceImpl orderService;

    @Test
    void getDetailRejectsCanteenAdminFromAnotherWindow() {
        OrderInfo order = new OrderInfo();
        order.setId(9L);
        order.setUserId(100L);
        order.setWindowId(2L);
        order.setStatus(1);
        when(orderInfoMapper.selectById(9L)).thenReturn(order);

        SysUser admin = new SysUser();
        admin.setId(7L);
        admin.setRoleId(2L);
        admin.setWindowId(5L);
        when(sysUserMapper.selectById(7L)).thenReturn(admin);

        BusinessException exception = assertThrows(BusinessException.class,
                () -> orderService.getDetail(9L, 7L, "CANTEEN_ADMIN"));
        assertEquals(ErrorCode.FORBIDDEN.getCode(), exception.getCode());
    }

    @Test
    void updateStatusRequiresPickupCodeWhenConfirmingPickup() {
        OrderInfo order = order(9L, 100L, 2L);
        order.setStatus(3);
        order.setPickupCode("654321");
        when(orderInfoMapper.selectById(9L)).thenReturn(order);

        SysUser admin = new SysUser();
        admin.setId(7L);
        admin.setRoleId(2L);
        admin.setWindowId(2L);
        when(sysUserMapper.selectById(7L)).thenReturn(admin);

        BusinessException exception = assertThrows(BusinessException.class,
                () -> orderService.updateStatus(9L, 4, 7L, "111111"));

        assertEquals(ErrorCode.PICKUP_CODE_INVALID.getCode(), exception.getCode());
    }

    @Test
    void updateStatusSendsPickupDetailsWhenOrderIsReady() {
        OrderInfo order = order(9L, 100L, 2L);
        order.setStatus(2);
        order.setPickupNumber("A009");
        order.setPickupCode("654321");
        when(orderInfoMapper.selectById(9L)).thenReturn(order);

        SysUser admin = new SysUser();
        admin.setId(7L);
        admin.setRoleId(2L);
        admin.setWindowId(2L);
        when(sysUserMapper.selectById(7L)).thenReturn(admin);
        when(orderItemMapper.selectList(any())).thenReturn(List.of(orderItem(9L, 10L, 1)));
        when(windowMapper.selectBatchIds(List.of(2L))).thenReturn(List.of(window(2L, 5L)));
        when(canteenMapper.selectList(any())).thenReturn(List.of(canteen(5L)));

        orderService.updateStatus(9L, 3, 7L);

        verify(messageService).createMessage(
                org.mockito.ArgumentMatchers.eq(100L),
                org.mockito.ArgumentMatchers.eq("订单已完成"),
                org.mockito.ArgumentMatchers.contains("取餐号：A009，取餐码：654321"),
                org.mockito.ArgumentMatchers.eq(2)
        );
    }

    @Test
    void createOrderDeductsStockForCartItems() {
        Cart cart = cart(1L, 100L, 10L, 2L, 3);
        Menu menu = menu(10L, 2L, 20);
        OrderCreateRequest request = orderRequest();
        when(cartMapper.selectList(any())).thenReturn(List.of(cart));
        when(orderInfoMapper.selectCount(any())).thenReturn(0L);
        when(menuMapper.selectBatchIds(List.of(10L))).thenReturn(List.of(menu));
        when(menuMapper.update(isNull(), any())).thenReturn(1);
        when(pickupNumberGenerator.generate(2L)).thenReturn("A0001");
        doAnswer(invocation -> {
            OrderInfo inserted = invocation.getArgument(0);
            inserted.setId(99L);
            return 1;
        }).when(orderInfoMapper).insert(any(OrderInfo.class));
        when(orderInfoMapper.selectById(99L)).thenReturn(order(99L, 100L, 2L));
        when(orderItemMapper.selectList(any())).thenReturn(List.of(orderItem(99L, 10L, 3)));
        when(windowMapper.selectBatchIds(List.of(2L))).thenReturn(List.of(window(2L, 5L)));
        when(canteenMapper.selectList(any())).thenReturn(List.of(canteen(5L)));

        orderService.createOrder(100L, request);

        verify(menuMapper).update(isNull(), any());
    }

    @Test
    void createOrderSplitsCartItemsIntoOrdersByWindow() {
        Cart firstCart = cart(1L, 100L, 10L, 2L, 2);
        Cart secondCart = cart(2L, 100L, 20L, 3L, 1);
        Menu firstMenu = menu(10L, 2L, 20);
        Menu secondMenu = menu(20L, 3L, 20);
        when(cartMapper.selectList(any())).thenReturn(List.of(firstCart, secondCart));
        when(orderInfoMapper.selectCount(any())).thenReturn(0L);
        when(menuMapper.selectBatchIds(List.of(10L, 20L))).thenReturn(List.of(firstMenu, secondMenu));
        when(menuMapper.update(isNull(), any())).thenReturn(1);
        when(pickupNumberGenerator.generate(2L)).thenReturn("A0001");
        when(pickupNumberGenerator.generate(3L)).thenReturn("B0001");
        doAnswer(invocation -> {
            OrderInfo inserted = invocation.getArgument(0);
            inserted.setId(inserted.getWindowId().equals(2L) ? 201L : 202L);
            return 1;
        }).when(orderInfoMapper).insert(any(OrderInfo.class));
        when(orderInfoMapper.selectById(201L)).thenReturn(order(201L, 100L, 2L, new BigDecimal("24.00")));
        when(orderInfoMapper.selectById(202L)).thenReturn(order(202L, 100L, 3L, new BigDecimal("12.00")));
        when(orderItemMapper.selectList(any())).thenReturn(
                List.of(orderItem(201L, 10L, 2)),
                List.of(orderItem(202L, 20L, 1)));
        when(windowMapper.selectBatchIds(List.of(2L))).thenReturn(List.of(window(2L, 5L)));
        when(windowMapper.selectBatchIds(List.of(3L))).thenReturn(List.of(window(3L, 6L)));
        when(canteenMapper.selectList(any())).thenReturn(List.of(canteen(5L), canteen(6L)));

        List<OrderVO> orders = orderService.createOrder(100L, orderRequest());

        assertEquals(2, orders.size());
        assertEquals(List.of(2L, 3L), orders.stream().map(OrderVO::getWindowId).toList());
        verify(orderInfoMapper, times(2)).insert(any(OrderInfo.class));
        verify(orderItemMapper, times(2)).insert(any(OrderItem.class));
        verify(menuMapper, times(2)).update(isNull(), any());
        verify(cartMapper).delete(any());
    }

    @Test
    void createOrderRejectsWhenStockCannotBeDeducted() {
        Cart cart = cart(1L, 100L, 10L, 2L, 3);
        Menu menu = menu(10L, 2L, 2);
        when(cartMapper.selectList(any())).thenReturn(List.of(cart));
        when(orderInfoMapper.selectCount(any())).thenReturn(0L);
        when(menuMapper.selectBatchIds(List.of(10L))).thenReturn(List.of(menu));

        BusinessException exception = assertThrows(BusinessException.class,
                () -> orderService.createOrder(100L, orderRequest()));

        assertEquals(ErrorCode.INSUFFICIENT_STOCK.getCode(), exception.getCode());
    }

    private static OrderCreateRequest orderRequest() {
        OrderCreateRequest request = new OrderCreateRequest();
        request.setPickupTimeSlot("11:30-12:00");
        request.setPaymentMethod("ALIPAY");
        return request;
    }

    private static Cart cart(Long id, Long userId, Long menuId, Long windowId, Integer quantity) {
        Cart cart = new Cart();
        cart.setId(id);
        cart.setUserId(userId);
        cart.setMenuId(menuId);
        cart.setWindowId(windowId);
        cart.setQuantity(quantity);
        return cart;
    }

    private static Menu menu(Long id, Long windowId, Integer stock) {
        Menu menu = new Menu();
        menu.setId(id);
        menu.setWindowId(windowId);
        menu.setName("测试菜品");
        menu.setPrice(new BigDecimal("12.00"));
        menu.setStock(stock);
        return menu;
    }

    private static OrderInfo order(Long id, Long userId, Long windowId) {
        return order(id, userId, windowId, new BigDecimal("36.00"));
    }

    private static OrderInfo order(Long id, Long userId, Long windowId, BigDecimal totalAmount) {
        OrderInfo order = new OrderInfo();
        order.setId(id);
        order.setOrderNo("NO001");
        order.setPickupNumber("A0001");
        order.setUserId(userId);
        order.setWindowId(windowId);
        order.setTotalAmount(totalAmount);
        order.setStatus(0);
        order.setPickupTimeSlot("11:30-12:00");
        order.setPaymentMethod("ALIPAY");
        return order;
    }

    private static OrderItem orderItem(Long orderId, Long menuId, Integer quantity) {
        OrderItem item = new OrderItem();
        item.setOrderId(orderId);
        item.setMenuId(menuId);
        item.setMenuName("测试菜品");
        item.setQuantity(quantity);
        item.setUnitPrice(new BigDecimal("12.00"));
        item.setSubtotal(new BigDecimal("36.00"));
        return item;
    }

    private static Window window(Long id, Long canteenId) {
        Window window = new Window();
        window.setId(id);
        window.setCanteenId(canteenId);
        window.setName("测试窗口");
        return window;
    }

    private static Canteen canteen(Long id) {
        Canteen canteen = new Canteen();
        canteen.setId(id);
        canteen.setName("测试食堂");
        return canteen;
    }
}
