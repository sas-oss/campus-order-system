package com.ordersystem.db;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SeedDataScriptTest {

    @Test
    void initScriptUsesDynamicDatesForTeacherDemo() throws Exception {
        String script = new String(SeedDataScriptTest.class.getResourceAsStream("/db/init.sql").readAllBytes(), StandardCharsets.UTF_8);

        assertFalse(script.contains("2026-06-26"), "init.sql should not contain fixed June 26 demo dates");
        assertFalse(script.contains("2026-06-27"), "init.sql should not contain fixed June 27 demo dates");
        assertTrue(script.contains("CURDATE()"), "init.sql should use CURDATE() for menu sale dates");
        assertFalse(script.contains("TIMESTAMP(CURDATE(), '')"), "init.sql should not contain invalid empty timestamp expressions");
        assertTrue(script.contains("学生"), "init.sql should preserve readable Chinese demo data");
    }

    @Test
    void seedDataScriptLoadsDemoDataForAllCoreFeatures() throws Exception {
        try (Connection connection = DriverManager.getConnection("jdbc:h2:mem:seed-data;MODE=MySQL;DATABASE_TO_UPPER=false")) {
            runScript(connection, "/db/init.sql");

            assertEquals(3, count(connection, "sys_role"));
            assertEquals(3, count(connection, "canteen"));
            assertEquals(12, count(connection, "canteen_window"));
            assertEquals(6, count(connection, "sys_user"));
            assertEquals(48, count(connection, "menu"));
            assertEquals(1, count(connection, "cart"));
            assertEquals(12, count(connection, "order_info"));
            assertEquals(20, count(connection, "order_item"));
            assertEquals(6, count(connection, "review"));
            assertEquals(10, count(connection, "review_item"));
            assertEquals(16, count(connection, "message"));

            assertEquals(new BigDecimal("18.00"), queryPrice(connection, "经典麻辣烫"));
            assertFalse(queryImageUrl(connection, "经典麻辣烫").isBlank());
            assertTrue(scalarInt(connection, "SELECT COUNT(*) FROM order_info WHERE user_id = 1 AND status IN (0, 1, 2, 3)") < 3);
            assertEquals(6, scalarInt(connection, "SELECT COUNT(*) FROM order_info WHERE window_id = 1 AND CAST(create_time AS DATE) = CURDATE()"));
            assertEquals(9, scalarInt(connection, "SELECT COUNT(*) FROM order_info WHERE status IN (1, 2, 3, 4) AND CAST(create_time AS DATE) = CURDATE()"));
            assertEquals(9, scalarInt(connection, "SELECT COUNT(*) FROM message WHERE user_id = 1 AND is_read = 0"));
        }
    }

    private static void runScript(Connection connection, String resourceName) throws Exception {
        String script = new String(SeedDataScriptTest.class.getResourceAsStream(resourceName).readAllBytes(), StandardCharsets.UTF_8)
                .replace("\uFEFF", "")
                .lines()
                .map(String::trim)
                .filter(line -> !line.startsWith("--") && !line.startsWith("/*!"))
                .reduce("", (left, right) -> left + System.lineSeparator() + right);
        try (Statement statement = connection.createStatement()) {
            for (String sql : Arrays.stream(script.split(";")).map(String::trim).filter(item -> !item.isBlank()).toList()) {
                if (DemoDataInitializer.isScriptControlStatement(sql)) {
                    continue;
                }
                statement.execute(DemoDataInitializer.adaptSqlForH2(sql));
            }
        }
    }

    private static int count(Connection connection, String tableName) throws Exception {
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT COUNT(*) FROM " + tableName)) {
            resultSet.next();
            return resultSet.getInt(1);
        }
    }

    private static BigDecimal queryPrice(Connection connection, String menuName) throws Exception {
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT price FROM menu WHERE name = '" + menuName + "'")) {
            resultSet.next();
            return resultSet.getBigDecimal(1);
        }
    }

    private static String queryImageUrl(Connection connection, String menuName) throws Exception {
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT image_url FROM menu WHERE name = '" + menuName + "'")) {
            resultSet.next();
            return resultSet.getString(1);
        }
    }

    private static int scalarInt(Connection connection, String sql) throws Exception {
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            resultSet.next();
            return resultSet.getInt(1);
        }
    }
}
