package com.ordersystem.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ordersystem.entity.Window;
import com.ordersystem.mapper.CanteenMapper;
import com.ordersystem.mapper.SysUserMapper;
import com.ordersystem.mapper.WindowMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class WindowServiceImplTest {

    @Mock
    private WindowMapper windowMapper;
    @Mock
    private CanteenMapper canteenMapper;
    @Mock
    private SysUserMapper sysUserMapper;
    @InjectMocks
    private WindowServiceImpl windowService;

    @Test
    void canteenAdminCanListWindowsByRequestedCanteen() {
        Window window = new Window();
        window.setId(4L);
        window.setCanteenId(2L);
        window.setName("Baozi Window");
        window.setStatus(1);
        when(windowMapper.selectList(any(LambdaQueryWrapper.class))).thenReturn(List.of(window));

        var windows = windowService.listForCurrentUser(2L, 1L, "CANTEEN_ADMIN", 4L);

        assertEquals(1, windows.size());
        assertEquals(4L, windows.get(0).getId());
        verify(windowMapper).selectList(any(LambdaQueryWrapper.class));
    }
}
