package com.ordersystem.service.impl;

import com.ordersystem.dto.CartItemRequest;
import com.ordersystem.dto.CartVO;
import com.ordersystem.common.BusinessException;
import com.ordersystem.common.ErrorCode;
import com.ordersystem.entity.Canteen;
import com.ordersystem.entity.Cart;
import com.ordersystem.entity.Menu;
import com.ordersystem.entity.Window;
import com.ordersystem.mapper.CanteenMapper;
import com.ordersystem.mapper.CartMapper;
import com.ordersystem.mapper.MenuMapper;
import com.ordersystem.mapper.WindowMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CartServiceImplTest {

    @Mock
    private CartMapper cartMapper;
    @Mock
    private MenuMapper menuMapper;
    @Mock
    private WindowMapper windowMapper;
    @Mock
    private CanteenMapper canteenMapper;
    @InjectMocks
    private CartServiceImpl cartService;

    @Test
    void getCartIncludesCanteenInfo() {
        Cart cart = cart(3L, 9L, 10L, 2L, 2);
        Menu menu = menu(10L, 2L, 10);
        Window window = window(2L, 5L, "1号窗口");
        Canteen canteen = canteen(5L, "第一食堂");
        when(cartMapper.selectList(any())).thenReturn(List.of(cart));
        when(menuMapper.selectBatchIds(List.of(10L))).thenReturn(List.of(menu));
        when(windowMapper.selectBatchIds(List.of(2L))).thenReturn(List.of(window));
        when(canteenMapper.selectBatchIds(List.of(5L))).thenReturn(List.of(canteen));

        CartVO result = cartService.getCart(9L);

        assertEquals(1, result.getItems().size());
        assertEquals(5L, result.getItems().get(0).getCanteenId());
        assertEquals("第一食堂", result.getItems().get(0).getCanteenName());
        assertEquals("1号窗口", result.getItems().get(0).getWindowName());
    }

    @Test
    void addToCartDoesNotDeductStockBeforeOrderIsCreated() {
        Menu menu = menu(1L, 1L, 10);
        when(menuMapper.selectById(1L)).thenReturn(menu);
        when(cartMapper.selectOne(any())).thenReturn(null);
        CartItemRequest request = new CartItemRequest();
        request.setMenuId(1L);
        request.setQuantity(2);

        cartService.addToCart(9L, request);

        verify(menuMapper, never()).update(isNull(), any());
    }

    @Test
    void addToCartRejectsQuantityAboveCurrentStock() {
        Menu menu = menu(1L, 1L, 1);
        when(menuMapper.selectById(1L)).thenReturn(menu);
        when(cartMapper.selectOne(any())).thenReturn(null);
        CartItemRequest request = new CartItemRequest();
        request.setMenuId(1L);
        request.setQuantity(2);

        BusinessException exception = assertThrows(BusinessException.class,
                () -> cartService.addToCart(9L, request));

        assertEquals(ErrorCode.INSUFFICIENT_STOCK.getCode(), exception.getCode());
    }

    @Test
    void addToCartAllowsItemsFromDifferentWindows() {
        Menu menu = menu(2L, 2L, 10);
        when(menuMapper.selectById(2L)).thenReturn(menu);
        when(cartMapper.selectOne(any())).thenReturn(null);
        CartItemRequest request = new CartItemRequest();
        request.setMenuId(2L);
        request.setQuantity(3);

        cartService.addToCart(9L, request);

        ArgumentCaptor<Cart> captor = ArgumentCaptor.forClass(Cart.class);
        verify(cartMapper).insert(captor.capture());
        assertEquals(2L, captor.getValue().getWindowId());
        assertEquals(3, captor.getValue().getQuantity());
    }

    @Test
    void updateQuantityOnlyValidatesStock() {
        Cart cart = cart(3L, 9L, 1L, 1L, 2);
        Menu menu = menu(1L, 1L, 10);
        when(cartMapper.selectById(3L)).thenReturn(cart);
        when(menuMapper.selectById(1L)).thenReturn(menu);

        cartService.updateQuantity(9L, 3L, 5);

        verify(menuMapper, never()).update(isNull(), any());
        verify(cartMapper).updateById(cart);
    }

    @Test
    void removeItemDoesNotRestoreStockBeforeOrderIsCreated() {
        Cart cart = cart(3L, 9L, 1L, 1L, 4);
        when(cartMapper.selectById(3L)).thenReturn(cart);

        cartService.removeItem(9L, 3L);

        verify(menuMapper, never()).update(isNull(), any());
        verify(cartMapper).deleteById(3L);
    }

    private static Menu menu(Long id, Long windowId, Integer stock) {
        Menu menu = new Menu();
        menu.setId(id);
        menu.setWindowId(windowId);
        menu.setName("测试菜品");
        menu.setPrice(new BigDecimal("10.00"));
        menu.setStock(stock);
        return menu;
    }

    private static Cart cart(Long id, Long userId, Long menuId, Long windowId, Integer quantity) {
        Cart cart = new Cart();
        cart.setId(id);
        cart.setUserId(userId);
        cart.setMenuId(menuId);
        cart.setWindowId(windowId);
        cart.setQuantity(quantity);
        return cart;
    }

    private static Window window(Long id, Long canteenId, String name) {
        Window window = new Window();
        window.setId(id);
        window.setCanteenId(canteenId);
        window.setName(name);
        return window;
    }

    private static Canteen canteen(Long id, String name) {
        Canteen canteen = new Canteen();
        canteen.setId(id);
        canteen.setName(name);
        return canteen;
    }
}
