package com.ordersystem.controller;

import com.ordersystem.dto.MenuRequest;
import com.ordersystem.service.MenuService;
import com.ordersystem.utils.FileUploadUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpMethod;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class MenuControllerMultipartTest {

    @Mock
    private MenuService menuService;
    @Mock
    private FileUploadUtil fileUploadUtil;
    @InjectMocks
    private MenuController menuController;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(menuController).build();
    }

    @Test
    void updateMenuAcceptsMultipartImageUpload() throws Exception {
        when(fileUploadUtil.upload(any())).thenReturn("/uploads/menu-images/new.png");
        MockMultipartFile image = new MockMultipartFile("imageFile", "dish.png", "image/png", new byte[]{1, 2, 3});

        mockMvc.perform(multipart(HttpMethod.PUT, "/api/menus/41")
                        .file(image)
                        .param("windowId", "1")
                        .param("name", "Tomato Beef Malatang")
                        .param("category", "主食")
                        .param("price", "24.00")
                        .param("stock", "26")
                        .param("description", "Fresh tomato broth")
                        .requestAttr("role", "CANTEEN_ADMIN")
                        .requestAttr("userId", 4L))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200));

        ArgumentCaptor<MenuRequest> requestCaptor = ArgumentCaptor.forClass(MenuRequest.class);
        verify(menuService).updateMenu(eq(41L), requestCaptor.capture(), eq(4L));
        assertEquals("/uploads/menu-images/new.png", requestCaptor.getValue().getImageUrl());
    }
}
