package com.ordersystem.interceptor;

import com.ordersystem.common.BusinessException;
import com.ordersystem.config.JwtUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class JwtInterceptorTest {

    @Mock
    private JwtUtils jwtUtils;

    @Test
    void publicMenuGetRequestDoesNotRequireToken() throws Exception {
        JwtInterceptor interceptor = new JwtInterceptor(jwtUtils);
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/menus");

        assertTrue(interceptor.preHandle(request, new MockHttpServletResponse(), new Object()));
    }

    @Test
    void menuMutationRequiresToken() {
        JwtInterceptor interceptor = new JwtInterceptor(jwtUtils);
        MockHttpServletRequest request = new MockHttpServletRequest("POST", "/api/menus");

        assertThrows(BusinessException.class, () -> interceptor.preHandle(request, new MockHttpServletResponse(), new Object()));
    }

    @Test
    void validTokenPopulatesRequestAttributes() throws Exception {
        JwtInterceptor interceptor = new JwtInterceptor(jwtUtils);
        MockHttpServletRequest request = new MockHttpServletRequest("POST", "/api/menus");
        request.addHeader("Authorization", "Bearer token-value");
        when(jwtUtils.validateToken("token-value")).thenReturn(true);
        when(jwtUtils.getUserIdFromToken("token-value")).thenReturn(4L);
        when(jwtUtils.getUsernameFromToken("token-value")).thenReturn("admin001");
        when(jwtUtils.getRoleFromToken("token-value")).thenReturn("CANTEEN_ADMIN");

        assertTrue(interceptor.preHandle(request, new MockHttpServletResponse(), new Object()));
        assertEquals(4L, request.getAttribute("userId"));
        assertEquals("admin001", request.getAttribute("username"));
        assertEquals("CANTEEN_ADMIN", request.getAttribute("role"));
    }
}
