package com.ordersystem.service.impl;

import com.ordersystem.dto.AiRecommendationVO;
import com.ordersystem.dto.AiMealAssistantRequest;
import com.ordersystem.dto.AiMealAssistantResponse;
import com.ordersystem.entity.Canteen;
import com.ordersystem.entity.Menu;
import com.ordersystem.entity.Window;
import com.ordersystem.mapper.CanteenMapper;
import com.ordersystem.mapper.MenuMapper;
import com.ordersystem.mapper.WindowMapper;
import com.ordersystem.service.AiClient;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AiRecommendationServiceImplTest {

    @Mock
    private MenuMapper menuMapper;
    @Mock
    private WindowMapper windowMapper;
    @Mock
    private CanteenMapper canteenMapper;
    @Mock
    private AiClient aiClient;
    @InjectMocks
    private AiRecommendationServiceImpl recommendationService;

    @Test
    void getTodayRecommendationsUsesAiReasonsForAvailableMenus() {
        Menu menu = menu(1L, "番茄牛腩饭", 2L);
        when(menuMapper.selectList(any())).thenReturn(List.of(menu));
        when(windowMapper.selectList(any())).thenReturn(List.of(window(2L, "盖饭窗口", 3L)));
        when(canteenMapper.selectList(any())).thenReturn(List.of(canteen(3L, "一食堂")));
        when(aiClient.generateRecommendationReasons(any())).thenReturn(Map.of(1L, "酸甜开胃，午餐很合适。"));

        List<AiRecommendationVO> recommendations = recommendationService.getTodayRecommendations(3);

        assertEquals(1, recommendations.size());
        AiRecommendationVO recommendation = recommendations.get(0);
        assertEquals(1L, recommendation.getId());
        assertEquals("番茄牛腩饭", recommendation.getName());
        assertEquals("一食堂", recommendation.getCanteenName());
        assertEquals("盖饭窗口", recommendation.getWindowName());
        assertEquals("酸甜开胃，午餐很合适。", recommendation.getReason());
    }

    @Test
    void getTodayRecommendationsFallsBackWhenAiClientFails() {
        when(menuMapper.selectList(any())).thenReturn(List.of(menu(2L, "香菇滑鸡饭", 5L)));
        when(windowMapper.selectList(any())).thenReturn(List.of(window(5L, "快餐窗口", 6L)));
        when(canteenMapper.selectList(any())).thenReturn(List.of(canteen(6L, "二食堂")));
        when(aiClient.generateRecommendationReasons(any())).thenThrow(new RuntimeException("network error"));

        List<AiRecommendationVO> recommendations = recommendationService.getTodayRecommendations(3);

        assertEquals(1, recommendations.size());
        assertTrue(recommendations.get(0).getReason().contains("库存充足"));
    }

    @Test
    void getTodayRecommendationsFallsBackToAvailableMenusWhenTodayHasNoMenus() {
        when(menuMapper.selectList(any())).thenReturn(List.of(), List.of(menu(3L, "黑椒鸡排饭", 7L)));
        when(windowMapper.selectList(any())).thenReturn(List.of(window(7L, "套餐窗口", 8L)));
        when(canteenMapper.selectList(any())).thenReturn(List.of(canteen(8L, "三食堂")));
        when(aiClient.generateRecommendationReasons(any())).thenReturn(Map.of());

        List<AiRecommendationVO> recommendations = recommendationService.getTodayRecommendations(3);

        assertEquals(1, recommendations.size());
        assertEquals("黑椒鸡排饭", recommendations.get(0).getName());
        assertEquals("库存充足，适合现在下单。", recommendations.get(0).getReason());
    }

    @Test
    void createMealPlanUsesUserPreferenceAndKeepsMenusInSameWindow() {
        when(menuMapper.selectList(any())).thenReturn(List.of(
                menu(11L, "麻辣香锅", 1L, "主食", new BigDecimal("18.00"), "香辣下饭"),
                menu(12L, "冰红茶", 1L, "饮料", new BigDecimal("5.00"), "清爽解辣"),
                menu(21L, "牛肉面", 2L, "主食", new BigDecimal("16.00"), "热乎管饱")
        ));
        when(windowMapper.selectList(any())).thenReturn(List.of(window(1L, "香锅窗口", 3L), window(2L, "面食窗口", 3L)));
        when(canteenMapper.selectList(any())).thenReturn(List.of(canteen(3L, "一食堂")));
        when(aiClient.generateMealAssistantReply(any(), any(), any()))
                .thenReturn("我理解你想吃辣一点，推荐麻辣香锅配冰红茶，口味明显又不超过预算。");

        AiMealAssistantResponse response = recommendationService.createMealPlan(mealRequest("想吃辣一点，25元以内", new BigDecimal("25.00")));

        assertEquals("香锅窗口", response.getWindowName());
        assertEquals(new BigDecimal("23.00"), response.getTotalAmount());
        assertEquals(List.of(11L, 12L), response.getMenus().stream().map(AiRecommendationVO::getId).toList());
        assertEquals("我理解你想吃辣一点，推荐麻辣香锅配冰红茶，口味明显又不超过预算。", response.getReply());
    }

    @Test
    void createMealPlanFallsBackWhenAiClientFails() {
        when(menuMapper.selectList(any())).thenReturn(List.of(
                menu(31L, "番茄鸡蛋饭", 4L, "主食", new BigDecimal("14.00"), "酸甜开胃")
        ));
        when(windowMapper.selectList(any())).thenReturn(List.of(window(4L, "盖饭窗口", 5L)));
        when(canteenMapper.selectList(any())).thenReturn(List.of(canteen(5L, "二食堂")));
        when(aiClient.generateMealAssistantReply(any(), any(), any())).thenThrow(new RuntimeException("network error"));

        AiMealAssistantResponse response = recommendationService.createMealPlan(mealRequest("清淡一点", new BigDecimal("20.00")));

        assertEquals(1, response.getMenus().size());
        assertEquals("番茄鸡蛋饭", response.getMenus().get(0).getName());
        assertTrue(response.getReply().contains("AI"));
        assertTrue(response.getReply().contains("番茄鸡蛋饭"));
    }

    private static Menu menu(Long id, String name, Long windowId) {
        Menu menu = new Menu();
        menu.setId(id);
        menu.setWindowId(windowId);
        menu.setName(name);
        menu.setCategory("主食");
        menu.setPrice(new BigDecimal("16.00"));
        menu.setStock(20);
        menu.setImageUrl("/uploads/menu-images/default-dish.svg");
        menu.setDescription("热乎现做");
        menu.setStatus(1);
        return menu;
    }

    private static Menu menu(Long id, String name, Long windowId, String category, BigDecimal price, String description) {
        Menu menu = menu(id, name, windowId);
        menu.setCategory(category);
        menu.setPrice(price);
        menu.setDescription(description);
        return menu;
    }

    private static AiMealAssistantRequest mealRequest(String preference, BigDecimal budget) {
        AiMealAssistantRequest request = new AiMealAssistantRequest();
        request.setPreference(preference);
        request.setBudget(budget);
        return request;
    }

    private static Window window(Long id, String name, Long canteenId) {
        Window window = new Window();
        window.setId(id);
        window.setName(name);
        window.setCanteenId(canteenId);
        return window;
    }

    private static Canteen canteen(Long id, String name) {
        Canteen canteen = new Canteen();
        canteen.setId(id);
        canteen.setName(name);
        return canteen;
    }
}
