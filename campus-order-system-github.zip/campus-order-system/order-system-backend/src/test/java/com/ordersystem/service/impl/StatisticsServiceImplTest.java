package com.ordersystem.service.impl;

import com.ordersystem.dto.OrderTrendVO;
import com.ordersystem.entity.OrderInfo;
import com.ordersystem.mapper.CanteenMapper;
import com.ordersystem.mapper.OrderInfoMapper;
import com.ordersystem.mapper.OrderItemMapper;
import com.ordersystem.mapper.ReviewMapper;
import com.ordersystem.mapper.SysUserMapper;
import com.ordersystem.mapper.WindowMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class StatisticsServiceImplTest {

    @Mock
    private OrderInfoMapper orderInfoMapper;
    @Mock
    private OrderItemMapper orderItemMapper;
    @Mock
    private ReviewMapper reviewMapper;
    @Mock
    private SysUserMapper sysUserMapper;
    @Mock
    private CanteenMapper canteenMapper;
    @Mock
    private WindowMapper windowMapper;
    @InjectMocks
    private StatisticsServiceImpl statisticsService;

    @Test
    void getOrderTrendFillsMissingDatesAndIgnoresCanceledRevenue() {
        LocalDate start = LocalDate.of(2026, 6, 1);
        LocalDate end = LocalDate.of(2026, 6, 3);
        when(orderInfoMapper.selectList(any())).thenReturn(List.of(
                order(start.atTime(10, 0), 1, "12.50"),
                order(start.atTime(11, 0), 5, "99.00"),
                order(end.atTime(12, 0), 4, "20.00")
        ));

        List<OrderTrendVO> trend = statisticsService.getOrderTrend(start, end);

        assertEquals(3, trend.size());
        assertEquals(start, trend.get(0).getDate());
        assertEquals(2, trend.get(0).getOrderCount());
        assertEquals(12.5D, trend.get(0).getRevenue());
        assertEquals(start.plusDays(1), trend.get(1).getDate());
        assertEquals(0, trend.get(1).getOrderCount());
        assertEquals(0D, trend.get(1).getRevenue());
        assertEquals(end, trend.get(2).getDate());
        assertEquals(1, trend.get(2).getOrderCount());
        assertEquals(20D, trend.get(2).getRevenue());
    }

    private static OrderInfo order(LocalDateTime createTime, Integer status, String amount) {
        OrderInfo order = new OrderInfo();
        order.setCreateTime(createTime);
        order.setStatus(status);
        order.setTotalAmount(new BigDecimal(amount));
        return order;
    }
}
