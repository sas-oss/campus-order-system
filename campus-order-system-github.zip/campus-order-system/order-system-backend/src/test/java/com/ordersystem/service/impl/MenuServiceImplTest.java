package com.ordersystem.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ordersystem.common.PageResult;
import com.ordersystem.dto.MenuQueryDTO;
import com.ordersystem.dto.MenuRequest;
import com.ordersystem.entity.Menu;
import com.ordersystem.entity.SysUser;
import com.ordersystem.mapper.CanteenMapper;
import com.ordersystem.mapper.MenuMapper;
import com.ordersystem.mapper.SysUserMapper;
import com.ordersystem.mapper.WindowMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MenuServiceImplTest {

    @Mock
    private MenuMapper menuMapper;
    @Mock
    private WindowMapper windowMapper;
    @Mock
    private CanteenMapper canteenMapper;
    @Mock
    private SysUserMapper sysUserMapper;
    @InjectMocks
    private MenuServiceImpl menuService;

    @Test
    void updateMenuKeepsExistingImageWhenNoImageUrlIsProvided() {
        Menu existing = menuWithImage("/uploads/menu-images/old.png");
        when(menuMapper.selectById(1L)).thenReturn(existing);
        when(sysUserMapper.selectById(4L)).thenReturn(adminUser());

        menuService.updateMenu(1L, requestWithImage(null), 4L);

        ArgumentCaptor<Menu> captor = ArgumentCaptor.forClass(Menu.class);
        verify(menuMapper).updateById(captor.capture());
        assertEquals("/uploads/menu-images/old.png", captor.getValue().getImageUrl());
    }

    @Test
    void updateMenuClearsImageWhenEmptyImageUrlIsProvided() {
        Menu existing = menuWithImage("/uploads/menu-images/old.png");
        when(menuMapper.selectById(1L)).thenReturn(existing);
        when(sysUserMapper.selectById(4L)).thenReturn(adminUser());

        menuService.updateMenu(1L, requestWithImage(""), 4L);

        ArgumentCaptor<Menu> captor = ArgumentCaptor.forClass(Menu.class);
        verify(menuMapper).updateById(captor.capture());
        assertEquals("", captor.getValue().getImageUrl());
    }

    @Test
    void updateMenuAllowsCanteenAdminToMoveMenuToAnyWindow() {
        Menu existing = menuWithImage("/uploads/menu-images/old.png");
        when(menuMapper.selectById(1L)).thenReturn(existing);
        when(sysUserMapper.selectById(4L)).thenReturn(adminUser());

        MenuRequest request = requestWithImage("/uploads/menu-images/new.png");
        request.setWindowId(4L);

        menuService.updateMenu(1L, request, 4L);

        ArgumentCaptor<Menu> captor = ArgumentCaptor.forClass(Menu.class);
        verify(menuMapper).updateById(captor.capture());
        assertEquals(4L, captor.getValue().getWindowId());
    }

    @Test
    void listMenusFallsBackToLatestAvailableDateWhenTodayHasNoMenus() {
        Menu menu = menuWithImage("/uploads/menu-images/old.png");
        menu.setName("经典麻辣烫");
        menu.setCategory("主食");
        menu.setPrice(new BigDecimal("18.00"));
        menu.setStock(20);
        menu.setStatus(1);
        menu.setSaleDate(LocalDate.now().minusDays(1));

        Page<Menu> emptyPage = new Page<>(1, 10);
        emptyPage.setRecords(List.of());
        emptyPage.setTotal(0);

        Page<Menu> fallbackPage = new Page<>(1, 10);
        fallbackPage.setRecords(List.of(menu));
        fallbackPage.setTotal(1);

        when(menuMapper.selectPage(any(Page.class), any(LambdaQueryWrapper.class)))
                .thenReturn(emptyPage)
                .thenReturn(fallbackPage);
        when(menuMapper.selectList(any(LambdaQueryWrapper.class))).thenReturn(List.of(menu));
        when(windowMapper.selectList(any(LambdaQueryWrapper.class))).thenReturn(List.of());
        when(canteenMapper.selectList(any(LambdaQueryWrapper.class))).thenReturn(List.of());

        PageResult<?> result = menuService.listMenus(new MenuQueryDTO(), 1, 10);

        assertEquals(1, result.getTotal());
        assertEquals(1, result.getRecords().size());
        verify(menuMapper, times(2)).selectPage(any(Page.class), any(LambdaQueryWrapper.class));
    }

    private static Menu menuWithImage(String imageUrl) {
        Menu menu = new Menu();
        menu.setId(1L);
        menu.setWindowId(1L);
        menu.setImageUrl(imageUrl);
        return menu;
    }

    private static MenuRequest requestWithImage(String imageUrl) {
        MenuRequest request = new MenuRequest();
        request.setWindowId(1L);
        request.setName("经典麻辣烫");
        request.setCategory("主食");
        request.setPrice(new BigDecimal("18.00"));
        request.setStock(20);
        request.setImageUrl(imageUrl);
        request.setDescription("热乎乎");
        return request;
    }

    private static SysUser adminUser() {
        SysUser user = new SysUser();
        user.setId(4L);
        user.setRoleId(2L);
        user.setWindowId(1L);
        return user;
    }
}
