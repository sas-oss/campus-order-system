package com.ordersystem.task;

import com.ordersystem.entity.Menu;
import com.ordersystem.entity.OrderInfo;
import com.ordersystem.entity.OrderItem;
import com.ordersystem.mapper.MenuMapper;
import com.ordersystem.mapper.OrderInfoMapper;
import com.ordersystem.mapper.OrderItemMapper;
import com.ordersystem.service.MessageService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OrderTimeoutTaskTest {

    @Mock
    private OrderInfoMapper orderInfoMapper;
    @Mock
    private OrderItemMapper orderItemMapper;
    @Mock
    private MenuMapper menuMapper;
    @Mock
    private MessageService messageService;
    @InjectMocks
    private OrderTimeoutTask orderTimeoutTask;

    @Test
    void cancelExpiredOrdersRestoresReservedStock() {
        OrderInfo order = new OrderInfo();
        order.setId(9L);
        order.setUserId(3L);
        order.setPickupNumber("A018");
        order.setStatus(0);
        order.setCreateTime(LocalDateTime.now().minusMinutes(35));
        when(orderInfoMapper.selectList(any())).thenReturn(List.of(order));

        OrderItem item = new OrderItem();
        item.setOrderId(9L);
        item.setMenuId(12L);
        item.setQuantity(2);
        when(orderItemMapper.selectList(any())).thenReturn(List.of(item));

        Menu menu = new Menu();
        menu.setId(12L);
        menu.setStock(6);
        when(menuMapper.selectById(12L)).thenReturn(menu);

        orderTimeoutTask.cancelExpiredOrders();

        verify(menuMapper).updateById(argThat(updated -> updated.getId().equals(12L) && updated.getStock() == 8));
    }
}
