package com.ordersystem;

import org.junit.jupiter.api.Test;

class OrderSystemApplicationTests {

    @Test
    void contextLoads() {
    }
}
