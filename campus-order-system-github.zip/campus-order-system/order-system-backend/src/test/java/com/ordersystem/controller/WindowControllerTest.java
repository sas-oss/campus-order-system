package com.ordersystem.controller;

import com.ordersystem.service.WindowService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Collections;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class WindowControllerTest {

    @Mock
    private WindowService windowService;
    @InjectMocks
    private WindowController windowController;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(windowController).build();
    }

    @Test
    void canteenAdminWindowListUsesRequestedCanteenFilter() throws Exception {
        when(windowService.listForCurrentUser(eq(2L), eq(4L), eq("CANTEEN_ADMIN"), eq(4L)))
                .thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/windows")
                        .param("canteenId", "2")
                        .param("adminWindowId", "4")
                        .requestAttr("role", "CANTEEN_ADMIN")
                        .requestAttr("userId", 4L))
                .andExpect(status().isOk());

        verify(windowService).listForCurrentUser(2L, 4L, "CANTEEN_ADMIN", 4L);
    }
}
