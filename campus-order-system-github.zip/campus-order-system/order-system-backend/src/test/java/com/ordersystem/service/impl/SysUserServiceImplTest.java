package com.ordersystem.service.impl;

import com.ordersystem.dto.UserSaveRequest;
import com.ordersystem.entity.SysUser;
import com.ordersystem.entity.Window;
import com.ordersystem.mapper.SysUserMapper;
import com.ordersystem.mapper.WindowMapper;
import com.ordersystem.common.BusinessException;
import com.ordersystem.common.ErrorCode;
import com.ordersystem.dto.RegisterRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SysUserServiceImplTest {

    @Mock
    private SysUserMapper sysUserMapper;
    @Mock
    private PasswordEncoder passwordEncoder;
    @Mock
    private com.ordersystem.config.JwtUtils jwtUtils;
    @Mock
    private WindowMapper windowMapper;
    @InjectMocks
    private SysUserServiceImpl sysUserService;

    @Test
    void createUserBindsCanteenAdminToSelectedWindow() {
        when(sysUserMapper.selectCount(any())).thenReturn(0L);
        when(passwordEncoder.encode("123456")).thenReturn("encoded-password");
        when(windowMapper.selectById(8L)).thenReturn(window(8L, 3L));

        UserSaveRequest request = new UserSaveRequest();
        request.setUsername("admin008");
        request.setPassword("123456");
        request.setRealName("窗口管理员");
        request.setPhone("13800008888");
        request.setRole("CANTEEN_ADMIN");
        request.setWindowId(8L);

        sysUserService.createUser(request);

        ArgumentCaptor<SysUser> captor = ArgumentCaptor.forClass(SysUser.class);
        verify(sysUserMapper).insert(captor.capture());
        SysUser saved = captor.getValue();
        assertEquals(2L, saved.getRoleId());
        assertEquals(8L, saved.getWindowId());
        assertEquals(3L, saved.getCanteenId());
        assertEquals(1, saved.getStatus());
        assertEquals("encoded-password", saved.getPassword());
    }

    @Test
    void registerRejectsCanteenAdminSelfRegistration() {
        RegisterRequest request = new RegisterRequest();
        request.setUsername("admin009");
        request.setPassword("123456");
        request.setRealName("自助管理员");
        request.setPhone("13800009999");
        request.setRole("CANTEEN_ADMIN");

        BusinessException exception = assertThrows(BusinessException.class,
                () -> sysUserService.register(request));

        assertEquals(ErrorCode.FORBIDDEN.getCode(), exception.getCode());
    }

    private static Window window(Long id, Long canteenId) {
        Window window = new Window();
        window.setId(id);
        window.setCanteenId(canteenId);
        return window;
    }
}
