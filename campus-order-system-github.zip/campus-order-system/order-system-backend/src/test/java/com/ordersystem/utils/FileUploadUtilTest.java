package com.ordersystem.utils;

import com.ordersystem.common.BusinessException;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class FileUploadUtilTest {

    @Test
    void uploadStoresImageAndReturnsPublicMenuImageUrl() throws Exception {
        Path uploadDirectory = Files.createTempDirectory("menu-images");
        FileUploadUtil uploadUtil = new FileUploadUtil();
        ReflectionTestUtils.setField(uploadUtil, "uploadPath", uploadDirectory.toString());
        MockMultipartFile image = new MockMultipartFile("imageFile", "dish.png", "image/png", new byte[]{1, 2, 3});

        String imageUrl = uploadUtil.upload(image);

        assertNotNull(imageUrl);
        assertTrue(imageUrl.startsWith("/uploads/menu-images/"));
        assertTrue(imageUrl.endsWith(".png"));
        assertTrue(Files.exists(uploadDirectory.resolve(Path.of(imageUrl).getFileName().toString())));
    }

    @Test
    void uploadTransfersToAbsolutePathWhenUploadPathIsRelative() {
        FileUploadUtil uploadUtil = new FileUploadUtil();
        ReflectionTestUtils.setField(uploadUtil, "uploadPath", "target/test-uploads/menu-images");
        MockMultipartFile image = new MockMultipartFile("imageFile", "dish.png", "image/png", new byte[]{1, 2, 3}) {
            @Override
            public void transferTo(File dest) throws IOException, IllegalStateException {
                assertTrue(dest.isAbsolute());
                super.transferTo(dest);
            }
        };

        String imageUrl = uploadUtil.upload(image);

        assertNotNull(imageUrl);
        assertTrue(imageUrl.startsWith("/uploads/menu-images/"));
    }

    @Test
    void uploadReturnsNullWhenNoFileSelected() {
        FileUploadUtil uploadUtil = new FileUploadUtil();

        assertNull(uploadUtil.upload(null));
    }

    @Test
    void uploadRejectsNonImageFiles() throws Exception {
        Path uploadDirectory = Files.createTempDirectory("menu-images");
        FileUploadUtil uploadUtil = new FileUploadUtil();
        ReflectionTestUtils.setField(uploadUtil, "uploadPath", uploadDirectory.toString());
        MockMultipartFile text = new MockMultipartFile("imageFile", "note.txt", "text/plain", "hello".getBytes());

        assertThrows(BusinessException.class, () -> uploadUtil.upload(text));
    }
}
