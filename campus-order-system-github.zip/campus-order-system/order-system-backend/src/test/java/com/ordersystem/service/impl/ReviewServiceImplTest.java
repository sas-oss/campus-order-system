package com.ordersystem.service.impl;

import com.ordersystem.common.BusinessException;
import com.ordersystem.common.ErrorCode;
import com.ordersystem.dto.ReviewRequest;
import com.ordersystem.entity.OrderInfo;
import com.ordersystem.entity.OrderItem;
import com.ordersystem.entity.Review;
import com.ordersystem.entity.ReviewItem;
import com.ordersystem.mapper.CanteenMapper;
import com.ordersystem.mapper.MenuMapper;
import com.ordersystem.mapper.OrderInfoMapper;
import com.ordersystem.mapper.OrderItemMapper;
import com.ordersystem.mapper.ReviewItemMapper;
import com.ordersystem.mapper.ReviewMapper;
import com.ordersystem.mapper.SysUserMapper;
import com.ordersystem.mapper.WindowMapper;
import com.ordersystem.service.MessageService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ReviewServiceImplTest {

    @Mock
    private ReviewMapper reviewMapper;
    @Mock
    private ReviewItemMapper reviewItemMapper;
    @Mock
    private OrderInfoMapper orderInfoMapper;
    @Mock
    private OrderItemMapper orderItemMapper;
    @Mock
    private WindowMapper windowMapper;
    @Mock
    private MenuMapper menuMapper;
    @Mock
    private SysUserMapper sysUserMapper;
    @Mock
    private CanteenMapper canteenMapper;
    @Mock
    private MessageService messageService;
    @InjectMocks
    private ReviewServiceImpl reviewService;

    @Test
    void submitReviewStoresWindowScoreAndDishScoresSeparately() {
        OrderInfo order = completedOrder();
        when(orderInfoMapper.selectById(7L)).thenReturn(order);
        when(reviewMapper.selectCount(any())).thenReturn(0L);
        when(orderItemMapper.selectList(any())).thenReturn(List.of(orderItem(101L), orderItem(102L)));
        doAnswer(invocation -> {
            Review review = invocation.getArgument(0);
            review.setId(88L);
            return 1;
        }).when(reviewMapper).insert(any(Review.class));

        ReviewRequest request = new ReviewRequest();
        request.setOrderId(7L);
        request.setWindowScore(4);
        request.setContent("窗口服务不错");
        request.setItems(List.of(
                dishScore(101L, 5, "麻辣烫好吃"),
                dishScore(102L, 3, "饮料一般")
        ));

        reviewService.submitReview(1L, request);

        ArgumentCaptor<Review> reviewCaptor = ArgumentCaptor.forClass(Review.class);
        verify(reviewMapper).insert(reviewCaptor.capture());
        assertEquals(4, reviewCaptor.getValue().getScore());
        assertEquals(null, reviewCaptor.getValue().getMenuId());

        ArgumentCaptor<ReviewItem> itemCaptor = ArgumentCaptor.forClass(ReviewItem.class);
        verify(reviewItemMapper, org.mockito.Mockito.times(2)).insert(itemCaptor.capture());
        List<ReviewItem> savedItems = itemCaptor.getAllValues();
        assertEquals(List.of(101L, 102L), savedItems.stream().map(ReviewItem::getMenuId).toList());
        assertEquals(List.of(5, 3), savedItems.stream().map(ReviewItem::getScore).toList());
        assertEquals(List.of("麻辣烫好吃", "饮料一般"), savedItems.stream().map(ReviewItem::getContent).toList());
    }

    @Test
    void submitReviewRejectsDishScoreForMenuOutsideOrder() {
        when(orderInfoMapper.selectById(7L)).thenReturn(completedOrder());
        when(reviewMapper.selectCount(any())).thenReturn(0L);
        when(orderItemMapper.selectList(any())).thenReturn(List.of(orderItem(101L)));

        ReviewRequest request = new ReviewRequest();
        request.setOrderId(7L);
        request.setWindowScore(4);
        request.setItems(List.of(dishScore(999L, 5, "不是本订单菜品")));

        BusinessException exception = assertThrows(BusinessException.class,
                () -> reviewService.submitReview(1L, request));

        assertEquals(ErrorCode.MENU_NOT_FOUND.getCode(), exception.getCode());
    }

    @Test
    void replyReviewSendsMessageToReviewer() {
        Review review = new Review();
        review.setId(88L);
        review.setOrderId(7L);
        review.setUserId(1L);
        review.setWindowId(2L);
        when(reviewMapper.selectById(88L)).thenReturn(review);

        com.ordersystem.entity.SysUser admin = new com.ordersystem.entity.SysUser();
        admin.setId(9L);
        admin.setWindowId(2L);
        when(sysUserMapper.selectById(9L)).thenReturn(admin);

        reviewService.replyReview(88L, "Thanks for your feedback", 9L);

        verify(messageService).createMessage(
                org.mockito.ArgumentMatchers.eq(1L),
                org.mockito.ArgumentMatchers.eq("评价回复通知"),
                org.mockito.ArgumentMatchers.contains("Thanks for your feedback"),
                org.mockito.ArgumentMatchers.eq(3)
        );
    }

    private static OrderInfo completedOrder() {
        OrderInfo order = new OrderInfo();
        order.setId(7L);
        order.setUserId(1L);
        order.setWindowId(2L);
        order.setStatus(4);
        return order;
    }

    private static OrderItem orderItem(Long menuId) {
        OrderItem item = new OrderItem();
        item.setMenuId(menuId);
        item.setMenuName("菜品" + menuId);
        return item;
    }

    private static ReviewRequest.DishReviewItem dishScore(Long menuId, Integer score, String content) {
        ReviewRequest.DishReviewItem item = new ReviewRequest.DishReviewItem();
        item.setMenuId(menuId);
        item.setScore(score);
        item.setContent(content);
        return item;
    }
}
