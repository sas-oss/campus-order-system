<template>
  <el-container style="min-height: 100vh">
    <el-aside :width="isCollapsed ? '64px' : '220px'" style="background: #38244a; color: white; transition: width 0.3s">
      <div v-if="!isCollapsed" style="padding: 24px; font-size: 20px; font-weight: 700;">系统管理端</div>
      <div v-else style="padding: 24px; font-size: 20px; font-weight: 700; text-align: center;">系</div>
      <el-menu :default-active="$route.path" router background-color="#38244a" text-color="#eadff7" active-text-color="#d8a8ff" :collapse="isCollapsed">
        <el-menu-item index="/system-admin/dashboard">工作台</el-menu-item>
        <el-menu-item index="/system-admin/canteens">食堂管理</el-menu-item>
        <el-menu-item index="/system-admin/windows">窗口管理</el-menu-item>
        <el-menu-item index="/system-admin/users">用户管理</el-menu-item>
        <el-menu-item index="/system-admin/reviews">评价总览</el-menu-item>
        <el-menu-item index="/system-admin/statistics">数据统计</el-menu-item>
      </el-menu>
    </el-aside>
    <el-container>
      <el-header style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #e3d8cb;background:#fffaf3">
        <div style="display:flex;align-items:center;gap:12px">
          <el-button text @click="isCollapsed = !isCollapsed" style="font-size:20px;padding:4px;width:36px;height:36px">
            <span v-if="isCollapsed">☰</span>
            <span v-else>✕</span>
          </el-button>
          <strong>系统后台</strong>
        </div>
        <div>
          <span style="margin-right: 12px">{{ userStore.userInfo.realName || userStore.userInfo.username }}</span>
          <el-button @click="logout">退出</el-button>
        </div>
      </el-header>
      <el-main><router-view /></el-main>
    </el-container>
  </el-container>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { confirmAction } from '@/composables/useConfirm'

const router = useRouter()
const userStore = useUserStore()
const isCollapsed = ref(false)

async function logout() {
  const confirmed = await confirmAction('确定退出登录吗？', '退出确认')
  if (!confirmed) return
  userStore.logout()
  router.push('/login')
}
</script>
