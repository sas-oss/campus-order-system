<template>
  <el-container style="min-height: 100vh">
    <el-aside :width="isCollapsed ? '64px' : '220px'" style="background: #1f3c36; color: white; transition: width 0.3s">
      <div v-if="!isCollapsed" style="padding: 24px; font-size: 20px; font-weight: 700;">窗口管理端</div>
      <div v-else style="padding: 24px; font-size: 20px; font-weight: 700; text-align: center;">窗</div>
      <el-menu :default-active="$route.path" router background-color="#1f3c36" text-color="#dcefe8" active-text-color="#8fe0c6" :collapse="isCollapsed">
        <el-menu-item index="/canteen-admin/dashboard">工作台</el-menu-item>
        <el-menu-item index="/canteen-admin/menus">菜单管理</el-menu-item>
        <el-menu-item index="/canteen-admin/orders">订单管理</el-menu-item>
        <el-menu-item index="/canteen-admin/reviews">评价管理</el-menu-item>
        <el-menu-item index="/canteen-admin/statistics">数据统计</el-menu-item>
      </el-menu>
    </el-aside>
    <el-container>
      <el-header style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #e3d8cb;background:#fffaf3">
        <div style="display:flex;align-items:center;gap:12px">
          <el-button text @click="isCollapsed = !isCollapsed" style="font-size:20px;padding:4px;width:36px;height:36px">
            <span v-if="isCollapsed">☰</span>
            <span v-else>✕</span>
          </el-button>
          <strong>食堂窗口管理</strong>
        </div>
        <div>
          <span style="margin-right: 12px">{{ userStore.userInfo.realName || userStore.userInfo.username }}</span>
          <el-button @click="logout">退出</el-button>
        </div>
      </el-header>
      <el-main><router-view /></el-main>
    </el-container>
  </el-container>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { confirmAction } from '@/composables/useConfirm'

const router = useRouter()
const userStore = useUserStore()
const isCollapsed = ref(false)

async function logout() {
  const confirmed = await confirmAction('确定退出登录吗？', '退出确认')
  if (!confirmed) return
  userStore.logout()
  router.push('/login')
}
</script>
