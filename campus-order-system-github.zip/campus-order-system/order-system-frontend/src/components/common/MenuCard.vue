<template>
  <el-card
    class="menu-card"
    :class="{ 'is-sold-out': menu.soldOut }"
    shadow="hover"
    :body-style="{ padding: '0' }"
  >
    <!-- Sold out overlay -->
    <div v-if="menu.soldOut" class="sold-out-overlay">
      <span class="sold-out-text">已售罄</span>
    </div>

    <!-- Image area -->
    <div class="image-wrapper">
      <img
        v-if="menu.imageUrl"
        :src="menu.imageUrl"
        :alt="menu.name"
        class="menu-image"
      />
      <div v-else class="image-placeholder">
        <span class="placeholder-emoji">🍽️</span>
      </div>
      <!-- Category badge -->
      <el-tag
        class="category-badge"
        :style="{ backgroundColor: categoryColor, borderColor: categoryColor }"
        effect="dark"
        size="small"
      >
        {{ menu.category }}
      </el-tag>
    </div>

    <!-- Info area -->
    <div class="info-wrapper">
      <div class="menu-name">{{ menu.name }}</div>
      <div v-if="menu.description" class="menu-desc">{{ menu.description }}</div>
      <div v-if="menu.windowName" class="menu-window">
        <span class="window-label">窗口：</span>{{ menu.windowName }}
      </div>

      <div class="bottom-row">
        <!-- Price -->
        <span class="menu-price">¥{{ menu.price }}</span>

        <!-- Stock indicator -->
        <span class="stock-indicator">
          <span class="stock-dot" :class="stockClass"></span>
          <span class="stock-text">{{ stockLabel }}</span>
        </span>
      </div>

      <!-- Add to cart controls -->
      <div v-if="showAdd && !menu.soldOut" class="add-row">
        <el-input-number
          v-model="quantity"
          :min="1"
          :max="menu.stock"
          size="small"
          class="quantity-input"
        />
        <el-button type="primary" size="small" @click="handleAddToCart">
          加入购物车
        </el-button>
      </div>
    </div>
  </el-card>
</template>

<script setup>
import { ref, computed } from 'vue'

const props = defineProps({
  menu: {
    type: Object,
    required: true
  },
  showAdd: {
    type: Boolean,
    default: true
  }
})

const emit = defineEmits(['add-to-cart'])

const quantity = ref(1)

const categoryColorMap = {
  '主食': '#E6A23C',
  '小吃': '#67C23A',
  '饮料': '#409EFF'
}

const categoryColor = computed(() => {
  return categoryColorMap[props.menu.category] || '#909399'
})

const stockClass = computed(() => {
  const stock = props.menu.stock
  if (stock === 0) return 'stock-red'
  if (stock <= 10) return 'stock-yellow'
  return 'stock-green'
})

const stockLabel = computed(() => {
  const stock = props.menu.stock
  if (stock === 0) return '售罄'
  if (stock <= 10) return `仅剩${stock}份`
  return `库存${stock}份`
})

function handleAddToCart() {
  emit('add-to-cart', props.menu, quantity.value)
  quantity.value = 1
}
</script>

<style scoped>
.menu-card {
  width: 100%;
  border-radius: 12px;
  overflow: hidden;
  cursor: pointer;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
  position: relative;
}

.menu-card:hover {
  transform: scale(1.03);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
}

.menu-card.is-sold-out {
  cursor: default;
}

/* Sold out overlay */
.sold-out-overlay {
  position: absolute;
  inset: 0;
  z-index: 10;
  background: rgba(128, 128, 128, 0.55);
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 12px;
}

.sold-out-text {
  font-size: 32px;
  font-weight: bold;
  color: #fff;
  text-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
  letter-spacing: 6px;
}

/* Image */
.image-wrapper {
  position: relative;
  width: 100%;
  height: 180px;
  overflow: hidden;
}

.menu-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.image-placeholder {
  width: 100%;
  height: 100%;
  background: linear-gradient(135deg, #ff9a56 0%, #ff6b6b 50%, #ee5a6f 100%);
  display: flex;
  align-items: center;
  justify-content: center;
}

.placeholder-emoji {
  font-size: 56px;
  opacity: 0.8;
}

/* Category badge */
.category-badge {
  position: absolute;
  top: 8px;
  left: 8px;
  border: none;
  color: #fff;
}

/* Info area */
.info-wrapper {
  padding: 12px 14px 14px;
}

.menu-name {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 4px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.menu-desc {
  font-size: 12px;
  color: #909399;
  margin-bottom: 6px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.menu-window {
  font-size: 12px;
  color: #909399;
  margin-bottom: 6px;
}

.window-label {
  color: #C0C4CC;
}

/* Bottom row: price + stock */
.bottom-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
}

.menu-price {
  font-size: 22px;
  font-weight: 700;
  color: #f56c6c;
}

/* Stock indicator */
.stock-indicator {
  display: flex;
  align-items: center;
  gap: 4px;
}

.stock-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  display: inline-block;
}

.stock-dot.stock-green {
  background-color: #67c23a;
}

.stock-dot.stock-yellow {
  background-color: #e6a23c;
}

.stock-dot.stock-red {
  background-color: #f56c6c;
}

.stock-text {
  font-size: 12px;
  color: #909399;
}

/* Add row */
.add-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.quantity-input {
  width: 110px;
}

.add-row .el-button {
  flex: 1;
}
</style>
