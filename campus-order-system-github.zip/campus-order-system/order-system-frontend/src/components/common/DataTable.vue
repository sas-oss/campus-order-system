<template>
  <div v-loading="loading">
    <el-table v-if="!isEmpty" :data="data" v-bind="$attrs" @selection-change="onSelect">
      <el-table-column v-if="selectable" type="selection" width="50" />
      <slot />
    </el-table>
    <el-empty v-else :description="emptyText" :image-size="100" />
    <div v-if="showPagination && total > 0" class="pagination-wrap">
      <el-pagination
        background
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
        :page-size="pageSize"
        :current-page="currentPage"
        @size-change="$emit('size-change', $event)"
        @current-change="$emit('page-change', $event)"
      />
    </div>
  </div>
</template>

<script setup>
defineProps({
  data: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
  isEmpty: { type: Boolean, default: false },
  emptyText: { type: String, default: '暂无数据' },
  showPagination: { type: Boolean, default: false },
  total: { type: Number, default: 0 },
  pageSize: { type: Number, default: 10 },
  currentPage: { type: Number, default: 1 },
  selectable: { type: Boolean, default: false }
})

const emit = defineEmits(['size-change', 'page-change', 'selection-change'])

function onSelect(selection) {
  emit('selection-change', selection)
}
</script>

<style scoped>
.pagination-wrap {
  display: flex;
  justify-content: flex-end;
  margin-top: 16px;
}
</style>
