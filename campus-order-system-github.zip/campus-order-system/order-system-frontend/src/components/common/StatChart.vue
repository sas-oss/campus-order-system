<template>
  <div
    v-loading="loading"
    class="stat-chart-wrapper"
    :style="{ height: height }"
  >
    <div ref="chartRef" class="chart-container"></div>
  </div>
</template>

<script setup>
import { ref, watch, onMounted, onBeforeUnmount } from 'vue'
import * as echarts from 'echarts'

const props = defineProps({
  option: {
    type: Object,
    required: true
  },
  height: {
    type: String,
    default: '300px'
  },
  loading: {
    type: Boolean,
    default: false
  }
})

const chartRef = ref(null)
let chartInstance = null
let resizeObserver = null

function initChart() {
  if (!chartRef.value) return
  chartInstance = echarts.init(chartRef.value)
  chartInstance.setOption(props.option, { notMerge: true })

  resizeObserver = new ResizeObserver(() => {
    chartInstance?.resize()
  })
  resizeObserver.observe(chartRef.value)
}

function destroyChart() {
  resizeObserver?.disconnect()
  resizeObserver = null
  chartInstance?.dispose()
  chartInstance = null
}

onMounted(() => {
  initChart()
})

onBeforeUnmount(() => {
  destroyChart()
})

watch(
  () => props.option,
  (newOption) => {
    if (chartInstance && newOption) {
      chartInstance.setOption(newOption, { notMerge: true })
    }
  },
  { deep: true }
)
</script>

<style scoped>
.stat-chart-wrapper {
  width: 100%;
}

.chart-container {
  width: 100%;
  height: 100%;
}
</style>
