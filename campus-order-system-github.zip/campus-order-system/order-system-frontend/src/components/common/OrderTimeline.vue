<template>
  <div class="order-timeline">
    <el-steps
      :active="activeStep"
      finish-status="success"
      process-status="process"
      align-center
    >
      <el-step
        v-for="(step, index) in steps"
        :key="index"
        :title="step.title"
        :description="step.description"
        :status="step.status"
      />
    </el-steps>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  status: {
    type: Number,
    required: true
  },
  createTime: {
    type: String,
    default: ''
  },
  paymentTime: {
    type: String,
    default: ''
  },
  finishTime: {
    type: String,
    default: ''
  }
})

const steps = computed(() => {
  if (props.status === 5) {
    return [
      { title: '下单', description: props.createTime || '', status: undefined },
      { title: '已支付', description: props.paymentTime || '', status: undefined },
      { title: '制作中', description: '', status: undefined },
      { title: '待取餐', description: '', status: undefined },
      { title: '已取消', description: '', status: 'error' }
    ]
  }
  return [
    { title: '下单', description: props.createTime || '', status: undefined },
    { title: '已支付', description: props.paymentTime || '', status: undefined },
    { title: '制作中', description: '', status: undefined },
    { title: '待取餐', description: '', status: undefined },
    { title: '已取餐', description: props.finishTime || '', status: undefined }
  ]
})

const activeStep = computed(() => {
  if (props.status === 5) return 4
  return Math.min(props.status, 4)
})
</script>

<style scoped>
.order-timeline {
  padding: 20px 0;
}

/* Override the error step to show dashed red line */
:deep(.el-step__head.is-error) {
  color: #f56c6c;
  border-color: #f56c6c;
}

:deep(.el-step__title.is-error) {
  color: #f56c6c;
  font-weight: 600;
}

/* Make cancelled step title appear slightly different */
:deep(.el-step__title.is-error) {
  text-decoration: line-through;
  text-decoration-style: dashed;
}

/* Description text styling for times */
:deep(.el-step__description) {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}
</style>
