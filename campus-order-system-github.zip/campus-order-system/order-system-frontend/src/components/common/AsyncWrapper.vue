<template>
  <div v-loading="loading" :element-loading-text="loadingText">
    <!-- 错误状态 -->
    <el-result v-if="error" status="error" :title="error" sub-title="请检查网络后重试">
      <template #extra>
        <el-button type="primary" @click="$emit('retry')">重试</el-button>
      </template>
    </el-result>

    <!-- 空状态 -->
    <el-empty v-else-if="isEmpty" :description="emptyText" :image-size="120" />

    <!-- 正常内容 -->
    <slot v-else />
  </div>
</template>

<script setup>
defineProps({
  loading: { type: Boolean, default: false },
  loadingText: { type: String, default: '加载中...' },
  error: { type: [String, null], default: null },
  isEmpty: { type: Boolean, default: false },
  emptyText: { type: String, default: '暂无数据' }
})

defineEmits(['retry'])
</script>
