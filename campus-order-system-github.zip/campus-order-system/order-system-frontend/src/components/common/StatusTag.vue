<template>
  <el-tag :type="tagType" :size="size" v-bind="$attrs">
    <slot>{{ label }}</slot>
  </el-tag>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  status: { type: Number, required: true },
  size: { type: String, default: 'default' }
})

const statusMap = {
  0: { type: 'warning', label: '待支付' },
  1: { type: 'primary', label: '已支付待制作' },
  2: { type: '', label: '制作中' },
  3: { type: 'success', label: '制作完成待取餐' },
  4: { type: 'info', label: '已取餐' },
  5: { type: 'danger', label: '已取消' }
}

const tagType = computed(() => statusMap[props.status]?.type || 'info')
const label = computed(() => statusMap[props.status]?.label || '未知')
</script>
