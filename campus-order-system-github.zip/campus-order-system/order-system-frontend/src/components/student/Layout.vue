<template>
  <el-container style="min-height: 100vh">
    <el-aside :width="isCollapsed ? '64px' : '220px'" style="background: #2d241d; color: white; transition: width 0.3s">
      <div v-if="!isCollapsed" class="student-brand">学生端</div>
      <div v-else class="student-brand collapsed">食</div>
      <el-menu
        class="student-menu"
        :default-active="$route.path"
        router
        background-color="#2d241d"
        text-color="#f7e5d5"
        active-text-color="#ffb179"
        :collapse="isCollapsed"
      >
        <el-menu-item index="/student/home"><span class="nav-label">首页</span></el-menu-item>
        <el-menu-item index="/student/menu"><span class="nav-label">菜单</span></el-menu-item>
        <el-menu-item index="/student/cart"><span class="nav-label">购物车</span></el-menu-item>
        <el-menu-item index="/student/checkout"><span class="nav-label">下单</span></el-menu-item>
        <el-menu-item index="/student/orders"><span class="nav-label">订单</span></el-menu-item>
        <el-menu-item index="/student/messages">
          <span class="nav-row">
            <span class="nav-label">消息</span>
            <span v-if="unreadCount > 0" class="nav-badge">{{ unreadCount > 99 ? '99+' : unreadCount }}</span>
          </span>
        </el-menu-item>
        <el-menu-item index="/student/profile"><span class="nav-label">个人中心</span></el-menu-item>
      </el-menu>
    </el-aside>
    <el-container>
      <el-header style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #e3d8cb;background:#fffaf3">
        <div style="display:flex;align-items:center;gap:12px">
          <el-button text @click="isCollapsed = !isCollapsed" style="font-size:20px;padding:4px;width:36px;height:36px">
            <span v-if="isCollapsed">☰</span>
            <span v-else>✕</span>
          </el-button>
          <strong>校园食堂在线订餐系统</strong>
        </div>
        <div>
          <span style="margin-right: 12px">{{ userStore.userInfo.realName || userStore.userInfo.username }}</span>
          <el-badge :value="unreadCount" :max="99" :hidden="unreadCount <= 0">
            <el-button type="primary" plain @click="goMessages">消息</el-button>
          </el-badge>
          <el-button @click="logout">退出</el-button>
        </div>
      </el-header>
      <el-main><router-view /></el-main>
    </el-container>
  </el-container>
</template>

<script setup>
import { onBeforeUnmount, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { api } from '@/api/request'
import { confirmAction } from '@/composables/useConfirm'

const router = useRouter()
const userStore = useUserStore()
const unreadCount = ref(0)
const isCollapsed = ref(false)
let timer = null

async function fetchUnread() {
  try {
    const res = await api.unreadCount()
    const count = res.data ?? 0
    if (count > unreadCount.value) {
      // 有新消息到达
    }
    unreadCount.value = count
  } catch (e) {
    // ignore polling errors
  }
}

function goMessages() {
  router.push('/student/messages')
}

async function logout() {
  const confirmed = await confirmAction('确定退出登录吗？', '退出确认')
  if (!confirmed) return
  userStore.logout()
  router.push('/login')
}

onMounted(() => {
  fetchUnread()
  timer = setInterval(fetchUnread, 8000)
})

onBeforeUnmount(() => {
  if (timer) clearInterval(timer)
})
</script>

<style scoped>
.student-brand {
  padding: 24px;
  font-size: 20px;
  font-weight: 700;
  letter-spacing: 0;
}

.student-brand.collapsed {
  text-align: center;
}

.student-menu {
  border-right: 0;
}

.student-menu :deep(.el-menu-item) {
  height: 52px;
  padding: 0 24px !important;
}

.student-menu :deep(.el-menu-item.is-active) {
  background: rgba(255, 177, 121, 0.12);
}

.nav-row {
  width: 100%;
  display: inline-flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}

.nav-label {
  line-height: 1;
}

.nav-badge {
  min-width: 22px;
  height: 20px;
  padding: 0 7px;
  border-radius: 999px;
  background: #f56c6c;
  color: #fff;
  border: 1px solid rgba(255, 255, 255, 0.9);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 700;
  line-height: 20px;
  box-shadow: 0 2px 6px rgba(245, 108, 108, 0.28);
}

.student-menu.el-menu--collapse :deep(.el-menu-item) {
  padding: 0 !important;
  justify-content: center;
}

.student-menu.el-menu--collapse .nav-row {
  justify-content: center;
  position: relative;
}

.student-menu.el-menu--collapse .nav-badge {
  position: absolute;
  top: -10px;
  right: -18px;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  font-size: 11px;
  line-height: 18px;
}
</style>
