import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import { api } from '@/api/request'

export const useUserStore = defineStore('user', () => {
  const token = ref(localStorage.getItem('token') || '')
  const role = ref(localStorage.getItem('role') || '')
  const userInfo = ref(JSON.parse(localStorage.getItem('userInfo') || '{}'))

  const isLogin = computed(() => Boolean(token.value))

  async function login(payload) {
    const res = await api.login(payload)
    token.value = res.data.token
    role.value = res.data.role
    userInfo.value = res.data.userInfo
    localStorage.setItem('token', token.value)
    localStorage.setItem('role', role.value)
    localStorage.setItem('userInfo', JSON.stringify(userInfo.value))
    return res
  }

  function logout() {
    token.value = ''
    role.value = ''
    userInfo.value = {}
    localStorage.removeItem('token')
    localStorage.removeItem('role')
    localStorage.removeItem('userInfo')
  }

  async function refreshProfile() {
    if (!token.value) return
    const res = await api.profile()
    userInfo.value = res.data
    role.value = res.data.role
    localStorage.setItem('role', role.value)
    localStorage.setItem('userInfo', JSON.stringify(userInfo.value))
  }

  return { token, role, userInfo, isLogin, login, logout, refreshProfile }
})
