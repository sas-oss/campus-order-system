import axios from 'axios'
import { ElMessage } from 'element-plus'

const request = axios.create({
  baseURL: '/api',
  timeout: 15000
})

request.interceptors.request.use((config) => {
  const token = localStorage.getItem('token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

request.interceptors.response.use(
  (response) => {
    const payload = response.data
    if (payload && typeof payload === 'object' && 'code' in payload && payload.code !== 200) {
      const error = new Error(payload.message || '请求失败')
      error.isBusinessError = true
      ElMessage.error(error.message)
      return Promise.reject(error)
    }
    return payload
  },
  (error) => {
    ElMessage.error(error.response?.data?.message || error.message || '请求失败')
    return Promise.reject(error)
  }
)

export const api = {
  login: (data) => request.post('/auth/login', data),
  register: (data) => request.post('/auth/register', data),
  profile: () => request.get('/auth/profile'),
  updateProfile: (data) => request.put('/auth/profile', data),
  changePassword: (data) => request.put('/auth/password', data),

  canteens: () => request.get('/canteens'),
  canteenDetail: (id) => request.get(`/canteens/${id}`),
  createCanteen: (data) => request.post('/canteens', data),
  updateCanteen: (id, data) => request.put(`/canteens/${id}`, data),
  deleteCanteen: (id) => request.delete(`/canteens/${id}`),

  windows: (params) => request.get('/windows', { params }),
  createWindow: (data) => request.post('/windows', data),
  updateWindow: (id, data) => request.put(`/windows/${id}`, data),
  deleteWindow: (id) => request.delete(`/windows/${id}`),

  menus: (params) => request.get('/menus', { params }),
  aiRecommendations: (params) => request.get('/ai/recommendations', { params }),
  aiMealAssistant: (data) => request.post('/ai/meal-assistant', data),
  menuDetail: (id) => request.get(`/menus/${id}`),
  createMenu: (data) => request.post('/menus', data),
  updateMenu: (id, data) => request.put(`/menus/${id}`, data),
  deleteMenu: (id) => request.delete(`/menus/${id}`),
  updateStock: (id, data) => request.put(`/menus/${id}/stock`, data),
  uploadMenuImage: (data, config) => request.post('/upload/menu-image', data, config),

  cart: () => request.get('/cart'),
  addCart: (data) => request.post('/cart/items', data),
  updateCart: (id, data) => request.put(`/cart/items/${id}`, data),
  removeCart: (id) => request.delete(`/cart/items/${id}`),
  clearCart: () => request.delete('/cart/clear'),

  orders: (params) => request.get('/orders', { params }),
  orderDetail: (id) => request.get(`/orders/${id}`),
  createOrder: (data) => request.post('/orders', data),
  payOrder: (id, data) => request.post(`/orders/${id}/pay`, data),
  cancelOrder: (id) => request.post(`/orders/${id}/cancel`),
  updateOrderStatus: (id, data) => request.put(`/orders/${id}/status`, data),

  messages: (params) => request.get('/messages', { params }),
  unreadCount: () => request.get('/messages/unread-count'),
  readMessage: (id) => request.put(`/messages/${id}/read`),
  markAllRead: () => request.put('/messages/read-all'),

  createReview: (data) => request.post('/reviews', data),
  myReviews: (params) => request.get('/reviews/my', { params }),
  windowReviews: (windowId, params) => request.get(`/reviews/window/${windowId}`, { params }),
  replyReview: (id, data) => request.put(`/reviews/${id}/reply`, data),
  reviewStats: () => request.get('/reviews/statistics'),
  windowReviewStats: (windowId) => request.get(`/reviews/statistics/window/${windowId}`),

  dailyStats: (params) => request.get('/statistics/daily', { params }),
  hotDishes: (params) => request.get('/statistics/hot-dishes', { params }),
  timeSlots: (params) => request.get('/statistics/time-slots', { params }),
  overviewStats: () => request.get('/statistics/overview'),
  rankings: () => request.get('/statistics/rankings'),
  orderTrend: (params) => request.get('/statistics/order-trend', { params }),

  users: (params) => request.get('/users', { params }),
  createUser: (data) => request.post('/users', data),
  updateUser: (id, data) => request.put(`/users/${id}`, data),
  updateUserStatus: (id, data) => request.put(`/users/${id}/status`, data)
}

export default request
