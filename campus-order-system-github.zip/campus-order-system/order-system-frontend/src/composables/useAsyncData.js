import { ref, unref } from 'vue'

/**
 * 统一管理异步数据获取的 loading / error / data 状态
 * @param {Function} fetcher - 异步获取函数，返回 Promise
 * @returns {{ data, loading, error, refresh }}
 */
export function useAsyncData(fetcher) {
  const data = ref(null)
  const loading = ref(false)
  const error = ref(null)

  async function refresh() {
    loading.value = true
    error.value = null
    try {
      const res = await fetcher()
      data.value = res
      return res
    } catch (e) {
      error.value = e?.response?.data?.message || e?.message || '请求失败'
      return null
    } finally {
      loading.value = false
    }
  }

  const isEmpty = () => {
    const d = unref(data)
    if (d == null) return true
    if (Array.isArray(d)) return d.length === 0
    if (d.records) return d.records.length === 0
    return false
  }

  return { data, loading, error, refresh, isEmpty }
}
