import { reactive, computed, toRefs } from 'vue'

/**
 * 统一分页逻辑
 * @param {Function} fetchFn - 接收 { page, size } 参数的获取函数
 * @param {number} defaultSize - 默认每页条数
 * @returns
 */
export function usePagination(fetchFn, defaultSize = 10) {
  const state = reactive({
    page: 1,
    size: defaultSize,
    total: 0
  })

  const totalPages = computed(() => Math.ceil(state.total / state.size))

  function onPageChange(page) {
    state.page = page
    fetchFn({ page: state.page, size: state.size })
  }

  function onSizeChange(size) {
    state.size = size
    state.page = 1
    fetchFn({ page: 1, size })
  }

  function reset() {
    state.page = 1
    state.total = 0
  }

  function setTotal(total) {
    state.total = total
  }

  const params = computed(() => ({ page: state.page, size: state.size }))

  return {
    ...toRefs(state),
    totalPages,
    params,
    onPageChange,
    onSizeChange,
    reset,
    setTotal
  }
}
