import { ElMessageBox } from 'element-plus'

const defaultOptions = {
  confirmButtonText: '确定',
  cancelButtonText: '取消',
  type: 'warning'
}

/**
 * 删除确认弹窗
 * @param {string} message
 * @returns {Promise<boolean>}
 */
export function confirmDelete(message = '确定删除吗？此操作不可恢复。') {
  return ElMessageBox.confirm(message, '操作确认', { ...defaultOptions })
    .then(() => true)
    .catch(() => false)
}

/**
 * 通用确认弹窗
 * @param {string} message
 * @param {string} title
 * @returns {Promise<boolean>}
 */
export function confirmAction(message, title = '操作确认') {
  return ElMessageBox.confirm(message, title, { ...defaultOptions })
    .then(() => true)
    .catch(() => false)
}
