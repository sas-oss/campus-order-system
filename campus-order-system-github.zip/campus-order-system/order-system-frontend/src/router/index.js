import { createRouter, createWebHistory } from 'vue-router'
import { useUserStore } from '@/stores/user'

const routes = [
  { path: '/', redirect: '/login' },
  { path: '/login', component: () => import('@/views/Login.vue'), meta: { public: true, title: '登录' } },
  {
    path: '/student',
    component: () => import('@/components/student/Layout.vue'),
    meta: { role: 'STUDENT', title: '学生端' },
    children: [
      { path: 'home', component: () => import('@/views/student/HomePage.vue'), meta: { title: '首页' } },
      { path: 'menu', component: () => import('@/views/student/MenuPage.vue'), meta: { title: '菜单' } },
      { path: 'cart', component: () => import('@/views/student/CartPage.vue'), meta: { title: '购物车' } },
      { path: 'checkout', component: () => import('@/views/student/CheckoutPage.vue'), meta: { title: '确认订单' } },
      { path: 'orders', component: () => import('@/views/student/OrderListPage.vue'), meta: { title: '我的订单' } },
      { path: 'orders/:id', component: () => import('@/views/student/OrderDetailPage.vue'), meta: { title: '订单详情' } },
      { path: 'review/:id', component: () => import('@/views/student/ReviewPage.vue'), meta: { title: '评价' } },
      { path: 'profile', component: () => import('@/views/student/ProfilePage.vue'), meta: { title: '个人中心' } },
      { path: 'messages', component: () => import('@/views/student/MessagePage.vue'), meta: { title: '消息中心' } }
    ]
  },
  {
    path: '/canteen-admin',
    component: () => import('@/components/admin/Layout.vue'),
    meta: { role: 'CANTEEN_ADMIN', title: '窗口管理端' },
    children: [
      { path: 'dashboard', component: () => import('@/views/canteen-admin/Dashboard.vue'), meta: { title: '工作台' } },
      { path: 'menus', component: () => import('@/views/canteen-admin/MenuManagePage.vue'), meta: { title: '菜单管理' } },
      { path: 'orders', component: () => import('@/views/canteen-admin/OrderManagePage.vue'), meta: { title: '订单管理' } },
      { path: 'reviews', component: () => import('@/views/canteen-admin/ReviewManagePage.vue'), meta: { title: '评价管理' } },
      { path: 'statistics', component: () => import('@/views/canteen-admin/StatisticsPage.vue'), meta: { title: '数据统计' } }
    ]
  },
  {
    path: '/system-admin',
    component: () => import('@/components/system/Layout.vue'),
    meta: { role: 'SYSTEM_ADMIN', title: '系统管理端' },
    children: [
      { path: 'dashboard', component: () => import('@/views/system-admin/Dashboard.vue'), meta: { title: '工作台' } },
      { path: 'canteens', component: () => import('@/views/system-admin/CanteenManagePage.vue'), meta: { title: '食堂管理' } },
      { path: 'windows', component: () => import('@/views/system-admin/WindowManagePage.vue'), meta: { title: '窗口管理' } },
      { path: 'users', component: () => import('@/views/system-admin/UserManagePage.vue'), meta: { title: '用户管理' } },
      { path: 'reviews', component: () => import('@/views/system-admin/ReviewOverviewPage.vue'), meta: { title: '评价总览' } },
      { path: 'statistics', component: () => import('@/views/system-admin/StatisticsPage.vue'), meta: { title: '数据统计' } }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to) => {
  document.title = `${to.meta.title || '校园食堂在线订餐系统'}`
  const userStore = useUserStore()
  if (to.meta.public) return true
  if (!userStore.isLogin) return '/login'
  if (to.meta.role && userStore.role !== to.meta.role) {
    if (userStore.role === 'STUDENT') return '/student/home'
    if (userStore.role === 'CANTEEN_ADMIN') return '/canteen-admin/dashboard'
    if (userStore.role === 'SYSTEM_ADMIN') return '/system-admin/dashboard'
    return '/login'
  }
  return true
})

export default router
