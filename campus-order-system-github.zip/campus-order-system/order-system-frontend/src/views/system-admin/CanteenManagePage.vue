<template>
  <div class="page-shell">
    <div class="page-card">
      <div class="toolbar">
        <el-button type="primary" @click="dialogVisible = true">新增食堂</el-button>
      </div>
      <el-table :data="canteens" v-loading="loading">
        <el-table-column prop="name" label="名称" />
        <el-table-column prop="address" label="地址" />
        <el-table-column prop="description" label="描述" />
        <el-table-column label="操作">
          <template #default="{ row }">
            <el-button link @click="edit(row)">编辑</el-button>
            <el-button link type="danger" @click="remove(row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-dialog v-model="dialogVisible" title="食堂信息">
        <el-form ref="formRef" :model="form" :rules="formRules" label-position="top">
          <el-form-item label="名称"><el-input v-model="form.name" /></el-form-item>
          <el-form-item label="地址"><el-input v-model="form.address" /></el-form-item>
          <el-form-item label="描述"><el-input v-model="form.description" /></el-form-item>
        </el-form>
        <template #footer>
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="save">保存</el-button>
        </template>
      </el-dialog>
    </div>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { api } from '@/api/request'
import { confirmDelete } from '@/composables/useConfirm'

const canteens = ref([])
const dialogVisible = ref(false)
const formRef = ref(null)
const loading = ref(false)
const emptyForm = () => ({ id: null, name: '', address: '', description: '' })
const form = reactive(emptyForm())

const formRules = {
  name: [{ required: true, message: '请输入食堂名称', trigger: 'blur' }],
  address: [{ required: true, message: '请输入食堂地址', trigger: 'blur' }]
}

async function loadCanteens() {
  loading.value = true
  try {
    canteens.value = (await api.canteens()).data || []
  } finally {
    loading.value = false
  }
}

function edit(row) {
  Object.assign(form, row)
  dialogVisible.value = true
}

async function save() {
  const valid = await formRef.value.validate().catch(() => false)
  if (!valid) return
  if (form.id) await api.updateCanteen(form.id, form)
  else await api.createCanteen(form)
  ElMessage.success(form.id ? '编辑成功' : '新增成功')
  dialogVisible.value = false
  Object.assign(form, emptyForm())
  await loadCanteens()
}

async function remove(id) {
  const ok = await confirmDelete('确定删除该食堂吗？此操作将同时删除其下所有窗口。')
  if (!ok) return
  loading.value = true
  try {
    await api.deleteCanteen(id)
    ElMessage.success('删除成功')
    await loadCanteens()
  } finally {
    loading.value = false
  }
}

onMounted(loadCanteens)
</script>
