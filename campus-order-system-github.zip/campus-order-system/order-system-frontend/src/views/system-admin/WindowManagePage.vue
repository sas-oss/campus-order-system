<template>
  <div class="page-shell">
    <div class="page-card">
      <div class="toolbar">
        <el-button type="primary" @click="dialogVisible = true">新增窗口</el-button>
      </div>
      <el-table :data="windows" v-loading="loading">
        <el-table-column prop="canteenName" label="食堂" />
        <el-table-column prop="name" label="窗口" />
        <el-table-column prop="floor" label="楼层" />
        <el-table-column prop="pickupNumberPrefix" label="取餐前缀" />
        <el-table-column label="操作">
          <template #default="{ row }">
            <el-button link @click="edit(row)">编辑</el-button>
            <el-button link type="danger" @click="remove(row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-dialog v-model="dialogVisible" title="窗口信息">
        <el-form ref="formRef" :model="form" :rules="formRules" label-position="top">
          <el-form-item label="食堂" prop="canteenId">
            <el-select v-model="form.canteenId" style="width:100%">
              <el-option v-for="c in canteens" :key="c.id" :label="c.name" :value="c.id" />
            </el-select>
          </el-form-item>
          <el-form-item label="窗口名" prop="name"><el-input v-model="form.name" /></el-form-item>
          <el-form-item label="楼层" prop="floor"><el-input v-model.number="form.floor" /></el-form-item>
          <el-form-item label="取餐前缀"><el-input v-model="form.pickupNumberPrefix" /></el-form-item>
        </el-form>
        <template #footer>
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="save">保存</el-button>
        </template>
      </el-dialog>
    </div>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { api } from '@/api/request'
import { confirmDelete } from '@/composables/useConfirm'

const windows = ref([])
const canteens = ref([])
const dialogVisible = ref(false)
const formRef = ref(null)
const loading = ref(false)
const emptyForm = () => ({ id: null, canteenId: null, name: '', floor: 1, pickupNumberPrefix: 'A' })
const form = reactive(emptyForm())

const formRules = {
  canteenId: [{ required: true, message: '请选择食堂', trigger: 'change' }],
  name: [{ required: true, message: '请输入窗口名称', trigger: 'blur' }],
  floor: [
    { required: true, message: '请输入楼层', trigger: 'blur' },
    { type: 'number', min: 1, message: '楼层必须大于等于1', trigger: 'blur' }
  ]
}

async function loadCanteens() {
  try {
    canteens.value = (await api.canteens()).data || []
  } catch (e) {
    // ignore
  }
}

async function loadWindows() {
  loading.value = true
  try {
    windows.value = (await api.windows({})).data || []
  } finally {
    loading.value = false
  }
}

function edit(row) {
  Object.assign(form, row)
  dialogVisible.value = true
}

async function save() {
  const valid = await formRef.value.validate().catch(() => false)
  if (!valid) return
  if (form.id) await api.updateWindow(form.id, form)
  else await api.createWindow(form)
  ElMessage.success(form.id ? '编辑成功' : '新增成功')
  dialogVisible.value = false
  Object.assign(form, emptyForm())
  await loadWindows()
}

async function remove(id) {
  const ok = await confirmDelete('确定删除该窗口吗？')
  if (!ok) return
  loading.value = true
  try {
    await api.deleteWindow(id)
    ElMessage.success('删除成功')
    await loadWindows()
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  loadCanteens()
  loadWindows()
})
</script>
