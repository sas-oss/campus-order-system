<template>
  <div class="page-shell" v-loading="loading">
    <div class="stats-grid">
      <StatChart :option="trendOption" height="360px" :loading="loading" />
      <StatChart :option="rankingsOption" height="360px" :loading="loading" />
    </div>
    <el-empty v-if="!loading && rankings.length === 0" description="暂无排行数据" style="margin-top:16px" />
  </div>
</template>

<script setup>
import { onMounted, ref, computed } from 'vue'
import { api } from '@/api/request'
import StatChart from '@/components/common/StatChart.vue'

const rankings = ref([])
const trend = ref([])
const loading = ref(false)

const trendOption = computed(() => {
  const records = trend.value || []
  return {
    title: { text: '近7日全校订单趋势', left: 'center', textStyle: { fontSize: 15, color: '#27211b' } },
    tooltip: { trigger: 'axis' },
    grid: { left: 40, right: 30, top: 50, bottom: 30 },
    xAxis: {
      type: 'category',
      data: records.map(item => {
        const value = item.date || ''
        return value.length >= 10 ? value.slice(5) : value
      }),
      axisLine: { lineStyle: { color: '#e3d8cb' } }
    },
    yAxis: { type: 'value', minInterval: 1, splitLine: { lineStyle: { color: '#f0ebe0' } } },
    series: [{
      name: '订单量',
      data: records.map(item => item.orderCount || 0),
      type: 'line',
      smooth: true,
      symbol: 'circle',
      symbolSize: 8,
      itemStyle: { color: '#409E67' },
      areaStyle: { color: 'rgba(64,158,103,0.1)' }
    }]
  }
})

const rankingsOption = computed(() => {
  const data = rankings.value || []
  const names = data.map(r => (r.canteenName || '') + ' - ' + (r.windowName || ''))
  const scores = data.map(r => r.averageScore || 0)
  return {
    title: { text: '窗口评分排行榜', left: 'center', textStyle: { fontSize: 15, color: '#27211b' } },
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    grid: { left: 160, right: 40, top: 50, bottom: 30 },
    xAxis: { type: 'value', min: 0, max: 5, splitLine: { lineStyle: { color: '#f0ebe0' } } },
    yAxis: {
      type: 'category',
      data: names,
      inverse: true,
      axisLine: { lineStyle: { color: '#e3d8cb' } }
    },
    series: [{
      data: scores,
      type: 'bar',
      itemStyle: {
        color: '#409E67',
        borderRadius: [0, 6, 6, 0]
      }
    }]
  }
})

onMounted(async () => {
  loading.value = true
  try {
    const [rankingRes, trendRes] = await Promise.all([
      api.rankings(),
      api.orderTrend({ days: 7 })
    ])
    rankings.value = rankingRes.data || []
    trend.value = trendRes.data || []
  } finally {
    loading.value = false
  }
})
</script>

<style scoped>
.stats-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

@media (max-width: 768px) {
  .stats-grid {
    grid-template-columns: 1fr;
  }
}
</style>
