<template>
  <div class="page-shell" v-loading="loading">
    <!-- 整体统计 -->
    <div class="panel-grid" style="margin-bottom:16px">
      <div class="stat-box">
        <h4>窗口总数</h4>
        <strong>{{ stats.length }}</strong>
      </div>
      <div class="stat-box">
        <h4>总评价数</h4>
        <strong>{{ totalReviews }}</strong>
      </div>
      <div class="stat-box">
        <h4>整体均分</h4>
        <strong>{{ overallAvg.toFixed(1) }} ⭐</strong>
      </div>
      <div class="stat-box">
        <h4>总差评数</h4>
        <strong style="color:#f56c6c">{{ totalNegatives }}</strong>
      </div>
    </div>

    <div class="page-card">
      <h3 style="margin:0 0 16px">📊 各窗口评分详情</h3>
      <el-table :data="stats" @row-click="showDetail" style="cursor:pointer">
        <el-table-column prop="windowName" label="窗口" min-width="140" />
        <el-table-column label="平均评分" width="180">
          <template #default="{ row }">
            <div class="score-cell">
              <el-rate :model-value="Math.round(row.averageScore)" disabled :max="5" size="small" />
              <span class="score-num">{{ (row.averageScore || 0).toFixed(1) }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="totalReviews" label="评价数" width="100" />
        <el-table-column label="差评数" width="100">
          <template #default="{ row }">
            <span :class="row.negativeReviews > 0 ? 'neg-count' : ''">{{ row.negativeReviews || 0 }}</span>
          </template>
        </el-table-column>
        <el-table-column label="差评率" width="100">
          <template #default="{ row }">
            <span v-if="row.totalReviews > 0">
              {{ ((row.negativeReviews / row.totalReviews) * 100).toFixed(1) }}%
            </span>
            <span v-else>-</span>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="!loading && stats.length === 0" description="暂无评价数据" />
    </div>

    <el-dialog v-model="detailVisible" title="窗口评价详情" width="800px">
      <el-table :data="detailReviews" max-height="400">
        <el-table-column prop="realName" label="学生" width="80" />
        <el-table-column label="评分" width="160">
          <template #default="{ row: r }">
            <el-rate :model-value="r.score" disabled :max="5" size="small" />
          </template>
        </el-table-column>
        <el-table-column prop="content" label="评价" min-width="180" show-overflow-tooltip />
        <el-table-column prop="replyContent" label="回复" min-width="120" show-overflow-tooltip>
          <template #default="{ row: r }">
            <span v-if="r.replyContent" style="color:#409E67">{{ r.replyContent }}</span>
            <span v-else style="color:#c0c4cc">-</span>
          </template>
        </el-table-column>
        <el-table-column prop="createTime" label="时间" width="160" />
      </el-table>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { api } from '@/api/request'

const stats = ref([])
const loading = ref(false)
const detailVisible = ref(false)
const detailReviews = ref([])

const totalReviews = computed(() => stats.value.reduce((sum, s) => sum + (s.totalReviews || 0), 0))
const totalNegatives = computed(() => stats.value.reduce((sum, s) => sum + (s.negativeReviews || 0), 0))
const overallAvg = computed(() => {
  if (stats.value.length === 0) return 0
  return stats.value.reduce((sum, s) => sum + (s.averageScore || 0), 0) / stats.value.length
})

onMounted(async () => {
  loading.value = true
  try {
    stats.value = (await api.reviewStats()).data || []
  } finally {
    loading.value = false
  }
})

async function showDetail(row) {
  detailVisible.value = true
  const res = await api.windowReviews(row.windowId)
  detailReviews.value = res.data?.records || res.data || []
}
</script>

<style scoped>
.score-cell {
  display: flex;
  align-items: center;
  gap: 8px;
}
.score-num {
  font-size: 14px;
  font-weight: 600;
  color: #303133;
}
.neg-count {
  color: #f56c6c;
  font-weight: 600;
}
</style>
