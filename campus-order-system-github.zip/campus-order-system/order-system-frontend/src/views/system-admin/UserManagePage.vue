<template>
  <div class="page-shell" v-loading="loading">
    <div class="page-card">
      <div class="toolbar">
        <el-select v-model="roleFilter" clearable placeholder="筛选角色" style="width: 180px" @change="loadUsers">
          <el-option label="全部角色" value="" />
          <el-option label="学生" value="STUDENT" />
          <el-option label="食堂管理员" value="CANTEEN_ADMIN" />
          <el-option label="系统管理员" value="SYSTEM_ADMIN" />
        </el-select>
        <el-button type="primary" @click="openCreate">新增用户</el-button>
      </div>

      <el-table :data="users">
        <el-table-column prop="username" label="账号" />
        <el-table-column prop="realName" label="姓名" />
        <el-table-column prop="roleName" label="角色" />
        <el-table-column prop="phone" label="手机号" />
        <el-table-column prop="canteenId" label="食堂">
          <template #default="{ row }">
            {{ canteenNameMap[row.canteenId] || '-' }}
          </template>
        </el-table-column>
        <el-table-column prop="windowId" label="窗口">
          <template #default="{ row }">
            {{ windowNameMap[row.windowId] || '-' }}
          </template>
        </el-table-column>
        <el-table-column label="状态">
          <template #default="{ row }">
            <el-tag :type="row.status === 1 ? 'success' : 'danger'">{{ row.status === 1 ? '正常' : '禁用' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="220">
          <template #default="{ row }">
            <el-button link @click="openEdit(row)">编辑</el-button>
            <el-button link @click="toggle(row)">{{ row.status === 1 ? '禁用' : '启用' }}</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-empty v-if="!loading && users.length === 0" description="暂无用户" />

      <el-dialog v-model="dialogVisible" :title="form.id ? '编辑用户' : '新增用户'" width="520px">
        <el-form ref="formRef" :model="form" :rules="formRules" label-position="top">
          <el-form-item label="账号" prop="username">
            <el-input v-model="form.username" />
          </el-form-item>
          <el-form-item label="姓名" prop="realName">
            <el-input v-model="form.realName" />
          </el-form-item>
          <el-form-item label="手机号" prop="phone">
            <el-input v-model="form.phone" />
          </el-form-item>
          <el-form-item label="角色" prop="role">
            <el-select v-model="form.role" style="width: 100%">
              <el-option label="学生" value="STUDENT" />
              <el-option label="食堂管理员" value="CANTEEN_ADMIN" />
              <el-option label="系统管理员" value="SYSTEM_ADMIN" />
            </el-select>
          </el-form-item>
          <el-form-item v-if="form.role === 'CANTEEN_ADMIN'" label="食堂" prop="canteenId">
            <el-select v-model="form.canteenId" style="width: 100%">
              <el-option v-for="item in canteens" :key="item.id" :label="item.name" :value="item.id" />
            </el-select>
          </el-form-item>
          <el-form-item v-if="form.role === 'CANTEEN_ADMIN'" label="窗口" prop="windowId">
            <el-select v-model="form.windowId" style="width: 100%" :disabled="!form.canteenId">
              <el-option v-for="item in windowOptions" :key="item.id" :label="item.name" :value="item.id" />
            </el-select>
          </el-form-item>
          <el-form-item :label="form.id ? '密码（留空则不修改）' : '密码'" prop="password">
            <el-input v-model="form.password" type="password" show-password />
          </el-form-item>
          <el-form-item label="状态" prop="status">
            <el-radio-group v-model="form.status">
              <el-radio :value="1">正常</el-radio>
              <el-radio :value="0">禁用</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-form>
        <template #footer>
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="save">保存</el-button>
        </template>
      </el-dialog>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { api } from '@/api/request'
import { confirmAction } from '@/composables/useConfirm'

const users = ref([])
const canteens = ref([])
const allWindows = ref([])
const windowOptions = ref([])
const loading = ref(false)
const dialogVisible = ref(false)
const formRef = ref(null)
const roleFilter = ref('')

const emptyForm = () => ({
  id: null,
  username: '',
  realName: '',
  phone: '',
  role: 'CANTEEN_ADMIN',
  canteenId: null,
  windowId: null,
  password: '',
  status: 1
})

const form = reactive(emptyForm())

const canteenNameMap = computed(() => Object.fromEntries(canteens.value.map(item => [item.id, item.name])))
const windowNameMap = computed(() => Object.fromEntries(allWindows.value.map(item => [item.id, item.name])))

const formRules = {
  username: [
    { required: true, message: '请输入账号', trigger: 'blur' },
    { pattern: /^[a-zA-Z0-9_]{4,20}$/, message: '账号必须为4-20位字母、数字或下划线', trigger: 'blur' }
  ],
  realName: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
  phone: [{ pattern: /^(1[3-9]\d{9})?$/, message: '请输入正确的手机号', trigger: 'blur' }],
  role: [{ required: true, message: '请选择角色', trigger: 'change' }],
  canteenId: [{
    validator: (_rule, value, callback) => {
      if (form.role !== 'CANTEEN_ADMIN' || value) callback()
      else callback(new Error('请选择食堂'))
    },
    trigger: 'change'
  }],
  windowId: [{
    validator: (_rule, value, callback) => {
      if (form.role !== 'CANTEEN_ADMIN' || value) callback()
      else callback(new Error('请选择窗口'))
    },
    trigger: 'change'
  }],
  password: [{
    validator: (_rule, value, callback) => {
      if (!value && form.id) {
        callback()
        return
      }
      if (value && value.length >= 6) {
        callback()
        return
      }
      callback(new Error('密码至少6位'))
    },
    trigger: 'blur'
  }]
}

watch(() => form.role, (role) => {
  if (role !== 'CANTEEN_ADMIN') {
    form.canteenId = null
    form.windowId = null
    windowOptions.value = []
  }
})

watch(() => form.canteenId, async (canteenId, previousCanteenId) => {
  if (canteenId === previousCanteenId) return
  if (!canteenId) {
    form.windowId = null
    windowOptions.value = []
    return
  }
  form.windowId = null
  const res = await api.windows({ canteenId })
  windowOptions.value = res.data || []
})

async function loadCanteens() {
  canteens.value = (await api.canteens()).data || []
}

async function loadAllWindows() {
  allWindows.value = (await api.windows({})).data || []
}

async function loadUsers() {
  loading.value = true
  try {
    const params = {}
    if (roleFilter.value) {
      params.role = roleFilter.value
    }
    const res = await api.users(params)
    users.value = res.data?.records || res.data || []
  } finally {
    loading.value = false
  }
}

function openCreate() {
  Object.assign(form, emptyForm())
  windowOptions.value = []
  dialogVisible.value = true
}

async function openEdit(row) {
  Object.assign(form, {
    id: row.id,
    username: row.username,
    realName: row.realName,
    phone: row.phone,
    role: row.role,
    canteenId: row.canteenId,
    windowId: row.windowId,
    password: '',
    status: row.status
  })
  if (form.role === 'CANTEEN_ADMIN' && form.canteenId) {
    const res = await api.windows({ canteenId: form.canteenId })
    windowOptions.value = res.data || []
    form.windowId = row.windowId
  } else {
    windowOptions.value = []
  }
  dialogVisible.value = true
}

async function save() {
  const valid = await formRef.value.validate().catch(() => false)
  if (!valid) return

  const payload = {
    username: form.username,
    realName: form.realName,
    phone: form.phone,
    role: form.role,
    canteenId: form.canteenId,
    windowId: form.windowId,
    password: form.password,
    status: form.status
  }

  if (form.id) await api.updateUser(form.id, payload)
  else await api.createUser(payload)

  ElMessage.success(form.id ? '编辑成功' : '新增成功')
  dialogVisible.value = false
  Object.assign(form, emptyForm())
  windowOptions.value = []
  await Promise.all([loadUsers(), loadAllWindows()])
}

async function toggle(row) {
  const ok = await confirmAction('确定变更该用户状态吗？')
  if (!ok) return
  await api.updateUserStatus(row.id, { status: row.status === 1 ? 0 : 1 })
  ElMessage.success('操作成功')
  await loadUsers()
}

onMounted(async () => {
  await Promise.all([loadCanteens(), loadAllWindows(), loadUsers()])
})
</script>

<style scoped>
.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}
</style>
