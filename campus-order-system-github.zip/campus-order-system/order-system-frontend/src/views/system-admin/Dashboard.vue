<template>
  <div class="page-shell" v-loading="loading">
    <div v-if="error" class="page-card" style="text-align:center;padding:40px">
      <el-empty description="加载失败" />
      <el-button type="primary" @click="loadData" style="margin-top:16px">重试</el-button>
    </div>
    <template v-else>
      <div class="panel-grid">
        <div class="stat-box"><h4>总用户数</h4><strong>{{ overview.totalUsers || 0 }}</strong></div>
        <div class="stat-box"><h4>总食堂数</h4><strong>{{ overview.totalCanteens || 0 }}</strong></div>
        <div class="stat-box"><h4>总窗口数</h4><strong>{{ overview.totalWindows || 0 }}</strong></div>
        <div class="stat-box"><h4>总订单数</h4><strong>{{ overview.totalOrders || 0 }}</strong></div>
      </div>
      <div class="chart-grid" style="margin-top:16px">
        <StatChart :option="canteenBarOption" height="320px" :loading="loading" />
        <StatChart :option="trendLineOption" height="320px" :loading="loading" />
      </div>
    </template>
  </div>
</template>

<script setup>
import { onMounted, ref, computed } from 'vue'
import { api } from '@/api/request'
import StatChart from '@/components/common/StatChart.vue'

const overview = ref({})
const canteensData = ref([])
const trendData = ref([])
const loading = ref(false)
const error = ref(false)

async function loadData() {
  loading.value = true
  error.value = false
  try {
    overview.value = (await api.overviewStats()).data || {}
    const [canteenRes, trendRes] = await Promise.all([
      api.canteens(),
      api.orderTrend({ days: 7 })
    ])
    canteensData.value = canteenRes.data || []
    trendData.value = trendRes.data || []
  } catch (e) {
    error.value = true
  } finally {
    loading.value = false
  }
}

const canteenBarOption = computed(() => {
  const canteens = canteensData.value || []
  const names = canteens.map(c => c.name || '')
  const orderCounts = canteens.map(c => c.orderCount || c.totalOrders || 0)
  return {
    title: { text: '各食堂订单量', left: 'center', textStyle: { fontSize: 15, color: '#27211b' } },
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    grid: { left: 30, right: 30, top: 50, bottom: 30 },
    xAxis: {
      type: 'category',
      data: names,
      axisLine: { lineStyle: { color: '#e3d8cb' } }
    },
    yAxis: { type: 'value', minInterval: 1, splitLine: { lineStyle: { color: '#f0ebe0' } } },
    series: [{
      data: orderCounts,
      type: 'bar',
      itemStyle: {
        color: '#409eff',
        borderRadius: [6, 6, 0, 0]
      }
    }]
  }
})

const trendLineOption = computed(() => {
  const records = trendData.value || []
  const days = records.map(item => {
    const value = item.date || ''
    return value.length >= 10 ? value.slice(5) : value
  })
  const trend = records.map(item => item.orderCount || 0)
  return {
    title: { text: '近7日订单趋势', left: 'center', textStyle: { fontSize: 15, color: '#27211b' } },
    tooltip: { trigger: 'axis' },
    grid: { left: 40, right: 20, top: 50, bottom: 30 },
    xAxis: { type: 'category', data: days, axisLine: { lineStyle: { color: '#e3d8cb' } } },
    yAxis: { type: 'value', minInterval: 1, splitLine: { lineStyle: { color: '#f0ebe0' } } },
    series: [{
      data: trend,
      type: 'line',
      smooth: true,
      symbol: 'circle',
      symbolSize: 8,
      itemStyle: { color: '#409E67' },
      areaStyle: { color: 'rgba(64,158,103,0.1)' }
    }]
  }
})

onMounted(loadData)
</script>

<style scoped>
.chart-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}
@media (max-width: 768px) {
  .chart-grid {
    grid-template-columns: 1fr;
  }
}
</style>
