<template>
  <div class="page-shell" v-loading="loading">
    <div class="page-card">
      <!-- 统计概览 -->
      <div class="panel-grid" style="margin-bottom:16px" v-if="stats">
        <div class="stat-box">
          <h4>总评价数</h4>
          <strong>{{ stats.totalReviews || 0 }}</strong>
        </div>
        <div class="stat-box">
          <h4>平均评分</h4>
          <strong>{{ (stats.averageScore || 0).toFixed(1) }} ⭐</strong>
        </div>
        <div class="stat-box">
          <h4>差评数</h4>
          <strong style="color:#f56c6c">{{ stats.negativeReviews || 0 }}</strong>
        </div>
      </div>

      <div class="toolbar" style="margin-bottom:16px">
        <el-radio-group v-model="scoreFilter">
          <el-radio-button :value="-1">全部</el-radio-button>
          <el-radio-button :value="1">1-2星差评</el-radio-button>
        </el-radio-group>
      </div>
      <el-table :data="filteredReviews">
        <el-table-column prop="realName" label="学生" width="80" />
        <el-table-column label="菜品评分" min-width="180">
          <template #default="{ row }">
            <div v-if="row.items && row.items.length" class="dish-review-list">
              <el-tag v-for="item in row.items" :key="item.id || item.menuId" size="small" effect="plain">
                {{ item.menuName || item.menuId }} {{ item.score }}星
              </el-tag>
            </div>
            <span v-else class="no-reply">无菜品明细</span>
          </template>
        </el-table-column>
        <el-table-column label="评分" width="160">
          <template #default="{ row }">
            <div class="score-cell">
              <el-rate :model-value="row.score" disabled :max="5" size="small" />
              <span class="score-num">{{ row.score }}分</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="content" label="评价内容" min-width="200" show-overflow-tooltip />
        <el-table-column prop="replyContent" label="回复" min-width="150" show-overflow-tooltip>
          <template #default="{ row }">
            <span v-if="row.replyContent" class="reply-text">{{ row.replyContent }}</span>
            <span v-else class="no-reply">未回复</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="280" fixed="right">
          <template #default="{ row }">
            <div class="reply-action">
              <el-input v-model="row._reply" placeholder="输入回复内容" size="small" />
              <el-button size="small" type="primary" link @click="reply(row)">回复</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="!loading && filteredReviews.length === 0" description="暂无评价" />
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/stores/user'
import { api } from '@/api/request'

const reviews = ref([])
const stats = ref(null)
const loading = ref(false)
const scoreFilter = ref(-1)
const userStore = useUserStore()

const filteredReviews = computed(() => {
  if (scoreFilter.value === -1) return reviews.value
  return reviews.value.filter(r => r.score >= 1 && r.score <= 2)
})

async function loadAll() {
  loading.value = true
  try {
    const windowId = userStore.userInfo.windowId
    const [reviewRes, statsRes] = await Promise.all([
      api.windowReviews(windowId),
      api.windowReviewStats(windowId)
    ])
    const records = reviewRes.data?.records || reviewRes.data || []
    reviews.value = records.map(item => ({ ...item, _reply: item.replyContent || '' }))
    stats.value = statsRes.data || null
  } finally {
    loading.value = false
  }
}

async function reply(row) {
  if (!row._reply || !row._reply.trim()) {
    ElMessage.warning('请输入回复内容')
    return
  }
  await api.replyReview(row.id, { content: row._reply })
  ElMessage.success('回复成功')
  await loadAll()
}

onMounted(loadAll)
</script>

<style scoped>
.score-cell {
  display: flex;
  align-items: center;
  gap: 6px;
}
.score-num {
  font-size: 13px;
  color: #606266;
  font-weight: 500;
}
.reply-text {
  color: #409E67;
}
.no-reply {
  color: #c0c4cc;
  font-style: italic;
}
.reply-action {
  display: flex;
  align-items: center;
  gap: 6px;
}
.reply-action .el-input {
  flex: 1;
  min-width: 120px;
}
.dish-review-list {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
</style>
