<template>
  <div class="page-shell" v-loading="loading">
    <div class="page-card">
      <div class="toolbar" style="margin-bottom:16px">
        <el-radio-group v-model="statusFilter" @change="filterOrders">
          <el-radio-button :value="-1">全部</el-radio-button>
          <el-radio-button :value="0">待支付</el-radio-button>
          <el-radio-button :value="1">待制作</el-radio-button>
          <el-radio-button :value="2">制作中</el-radio-button>
          <el-radio-button :value="3">待取餐</el-radio-button>
          <el-radio-button :value="4">已取餐</el-radio-button>
          <el-radio-button :value="5">已取消</el-radio-button>
        </el-radio-group>
      </div>
      <el-table :data="filteredOrders" row-key="id">
        <el-table-column type="expand">
          <template #default="{ row }">
            <div class="expand-items">
              <div class="detail-title">
                <h4>菜品明细</h4>
                <span>共 {{ itemCount(row) }} 件</span>
              </div>
              <el-table :data="row.items" size="small" style="margin-top:8px">
                <el-table-column prop="menuName" label="菜品名称" />
                <el-table-column prop="quantity" label="数量" width="80" />
                <el-table-column prop="unitPrice" label="单价(元)" width="100" />
                <el-table-column prop="subtotal" label="小计(元)" width="100" />
              </el-table>
              <div v-if="!row.items || row.items.length === 0" class="text-muted">暂无菜品信息</div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="orderNo" label="订单号" width="180" />
        <el-table-column prop="pickupNumber" label="取餐号" width="80" />
        <el-table-column label="菜品" min-width="240">
          <template #default="{ row }">
            <div v-if="row.items && row.items.length" class="item-summary">
              <el-tag
                v-for="(item, index) in visibleItems(row)"
                :key="`${row.id}-${item.menuId || item.menuName}-${index}`"
                class="item-tag"
                effect="plain"
                type="success"
              >
                {{ item.menuName }} x{{ item.quantity }}
              </el-tag>
              <span v-if="hiddenItemCount(row) > 0" class="more-items">
                另 {{ hiddenItemCount(row) }} 种
              </span>
            </div>
            <span v-else class="text-muted-inline">暂无菜品信息</span>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="90">
          <template #default="{ row }">
            <StatusTag :status="row.status" />
          </template>
        </el-table-column>
        <el-table-column prop="pickupTimeSlot" label="取餐时段" width="120" />
        <el-table-column label="金额(元)" width="90">
          <template #default="{ row }">
            <span style="color:#409E67;font-weight:600">¥{{ row.totalAmount }}</span>
          </template>
        </el-table-column>
        <el-table-column label="下单时间" width="160">
          <template #default="{ row }">
            {{ row.createTime || '-' }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="260" fixed="right">
          <template #default="{ row }">
            <el-button v-if="row.status===1" link @click="changeStatus(row.id, 2)">开始制作</el-button>
            <el-button v-if="row.status===2" link @click="changeStatus(row.id, 3)">制作完成</el-button>
            <el-button v-if="row.status===3" link @click="changeStatus(row.id, 4)">确认取餐</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="!loading && filteredOrders.length === 0" description="暂无订单" />
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { api } from '@/api/request'
import StatusTag from '@/components/common/StatusTag.vue'
import { confirmAction } from '@/composables/useConfirm'

const orders = ref([])
const loading = ref(false)
const statusFilter = ref(-1)

const filteredOrders = computed(() => {
  if (statusFilter.value === -1) return orders.value
  return orders.value.filter(o => o.status === statusFilter.value)
})

async function loadOrders() {
  loading.value = true
  try {
    const res = await api.orders()
    orders.value = res.data?.records || res.data || []
  } finally {
    loading.value = false
  }
}

function filterOrders() {
  // computed handles filtering
}

function visibleItems(row) {
  return (row.items || []).slice(0, 3)
}

function hiddenItemCount(row) {
  return Math.max((row.items || []).length - 3, 0)
}

function itemCount(row) {
  return (row.items || []).reduce((total, item) => total + Number(item.quantity || 0), 0)
}

async function changeStatus(id, status) {
  const confirmMsg = status === 2 ? '确定开始制作吗？' : status === 3 ? '确定将此订单标记为制作完成吗？' : '确定确认取餐吗？'
  let pickupCode = ''
  if (status === 4) {
    try {
      const result = await ElMessageBox.prompt('请扫描或输入学生出示的取餐码', '确认取餐', {
        confirmButtonText: '确认取餐',
        cancelButtonText: '取消',
        inputPattern: /^[0-9]{6}$/,
        inputErrorMessage: '取餐码为6位数字'
      })
      pickupCode = result.value
    } catch {
      return
    }
  } else {
    const ok = await confirmAction(confirmMsg)
    if (!ok) return
  }
  loading.value = true
  try {
    await api.updateOrderStatus(id, { status, pickupCode })
    ElMessage.success('操作成功')
    await loadOrders()
  } finally {
    loading.value = false
  }
}

onMounted(loadOrders)
</script>

<style scoped>
.expand-items {
  padding: 8px 16px;
  background: #fafafa;
  border-radius: 8px;
}
.detail-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.detail-title h4 {
  margin: 0 0 4px;
  font-size: 14px;
  color: #606266;
}
.detail-title span {
  color: #909399;
  font-size: 13px;
}
.item-summary {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  align-items: center;
}
.item-tag {
  max-width: 150px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.more-items {
  color: #909399;
  font-size: 13px;
}
.text-muted {
  color: #c0c4cc;
  font-size: 13px;
  text-align: center;
  padding: 16px;
}
.text-muted-inline {
  color: #c0c4cc;
  font-size: 13px;
}
</style>
