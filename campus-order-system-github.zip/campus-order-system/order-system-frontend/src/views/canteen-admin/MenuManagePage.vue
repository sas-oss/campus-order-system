<template>
  <div class="page-shell">
    <div class="page-card">
      <div class="menu-manage-header">
        <div>
          <h2 class="page-title">菜品管理</h2>
          <p>按食堂和窗口分类查看，维护菜品、价格和库存。</p>
        </div>
        <el-button type="primary" @click="openCreate">新增菜品</el-button>
      </div>

      <div class="filter-bar">
        <el-select v-model="filters.canteenId" clearable placeholder="全部食堂" style="width: 180px" @change="handleFilterCanteenChange">
          <el-option v-for="item in canteens" :key="item.id" :label="item.name" :value="item.id" />
        </el-select>
        <el-select v-model="filters.windowId" clearable placeholder="全部窗口" style="width: 200px" @change="loadMenus">
          <el-option v-for="item in filterWindows" :key="item.id" :label="windowLabel(item)" :value="item.id" />
        </el-select>
        <el-select v-model="filters.category" clearable placeholder="全部分类" style="width: 140px" @change="loadMenus">
          <el-option label="主食" value="主食" />
          <el-option label="小吃" value="小吃" />
          <el-option label="饮料" value="饮料" />
        </el-select>
        <el-input v-model="filters.keyword" clearable placeholder="搜索菜品名称" style="width: 220px" @keyup.enter="loadMenus" />
        <el-button type="primary" plain @click="loadMenus">查询</el-button>
        <el-button @click="resetFilters">重置</el-button>
      </div>

      <el-table :data="menus" v-loading="loading">
        <el-table-column prop="name" label="菜品" min-width="130" />
        <el-table-column label="图片" width="80">
          <template #default="{ row }">
            <el-image v-if="row.imageUrl" :src="row.imageUrl" style="width:40px;height:40px;border-radius:4px" fit="cover" />
            <span v-else style="color:#ccc">-</span>
          </template>
        </el-table-column>
        <el-table-column prop="canteenName" label="食堂" min-width="120" />
        <el-table-column prop="windowName" label="窗口" min-width="120" />
        <el-table-column prop="category" label="分类" width="90" />
        <el-table-column prop="price" label="价格" width="90" />
        <el-table-column prop="stock" label="库存" width="90" />
        <el-table-column label="操作" width="140" fixed="right">
          <template #default="{ row }">
            <el-button link @click="edit(row)">编辑</el-button>
            <el-button link type="danger" @click="remove(row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-dialog v-model="dialogVisible" :title="form.id ? '编辑菜品' : '新增菜品'" width="560px">
        <el-form ref="formRef" :model="form" :rules="formRules" label-position="top">
          <div class="form-grid">
            <el-form-item label="所属食堂" prop="canteenId">
              <el-select v-model="form.canteenId" placeholder="请选择食堂" style="width:100%" @change="handleFormCanteenChange">
                <el-option v-for="item in canteens" :key="item.id" :label="item.name" :value="item.id" />
              </el-select>
            </el-form-item>
            <el-form-item label="所属窗口" prop="windowId">
              <el-select v-model="form.windowId" placeholder="请选择窗口" style="width:100%">
                <el-option v-for="item in formWindows" :key="item.id" :label="windowLabel(item)" :value="item.id" />
              </el-select>
            </el-form-item>
          </div>
          <el-form-item label="名称" prop="name"><el-input v-model="form.name" /></el-form-item>
          <div class="form-grid">
            <el-form-item label="分类" prop="category">
              <el-select v-model="form.category" style="width:100%">
                <el-option label="主食" value="主食" />
                <el-option label="小吃" value="小吃" />
                <el-option label="饮料" value="饮料" />
              </el-select>
            </el-form-item>
            <el-form-item label="价格" prop="price"><el-input v-model.number="form.price" /></el-form-item>
            <el-form-item label="库存" prop="stock"><el-input v-model.number="form.stock" /></el-form-item>
          </div>
          <el-form-item label="菜品图片">
            <div v-if="imagePreviewUrl || form.imageUrl" style="margin-bottom:8px">
              <el-image :src="imagePreviewUrl || form.imageUrl" style="width:120px;height:120px;border-radius:8px" fit="cover" />
              <el-button link type="danger" size="small" style="margin-left:8px" @click="clearImage">移除图片</el-button>
            </div>
            <el-upload
              :auto-upload="false"
              :limit="1"
              accept="image/*"
              :on-change="handleImageChange"
              :file-list="uploadFileList"
              list-type="picture"
            >
              <el-button type="primary" plain>选择图片</el-button>
              <template #tip><div class="el-upload__tip">支持 JPG/PNG，建议尺寸 400×400</div></template>
            </el-upload>
          </el-form-item>
          <el-form-item label="描述"><el-input v-model="form.description" type="textarea" /></el-form-item>
        </el-form>
        <template #footer>
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="save">保存</el-button>
        </template>
      </el-dialog>
    </div>
  </div>
</template>

<script setup>
import { onBeforeUnmount, onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { api } from '@/api/request'
import { confirmDelete } from '@/composables/useConfirm'

const menus = ref([])
const canteens = ref([])
const filterWindows = ref([])
const formWindows = ref([])
const dialogVisible = ref(false)
const imageFile = ref(null)
const imagePreviewUrl = ref('')
const uploadFileList = ref([])
const formRef = ref(null)
const loading = ref(false)

const filters = reactive({
  canteenId: null,
  windowId: null,
  category: '',
  keyword: ''
})

const emptyForm = () => ({
  id: null,
  canteenId: filters.canteenId || null,
  windowId: filters.windowId || null,
  name: '',
  category: '主食',
  price: 10,
  stock: 10,
  description: '',
  imageUrl: ''
})
const form = reactive(emptyForm())

const formRules = {
  canteenId: [{ required: true, message: '请选择所属食堂', trigger: 'change' }],
  windowId: [{ required: true, message: '请选择所属窗口', trigger: 'change' }],
  name: [{ required: true, message: '请输入菜品名称', trigger: 'blur' }],
  category: [{ required: true, message: '请选择分类', trigger: 'change' }],
  price: [
    { required: true, message: '请输入价格', trigger: 'blur' },
    { type: 'number', min: 0.01, message: '价格必须大于0', trigger: 'blur' }
  ],
  stock: [
    { required: true, message: '请输入库存', trigger: 'blur' },
    { type: 'number', min: 0, message: '库存不能小于0', trigger: 'blur' }
  ]
}

async function openCreate() {
  Object.assign(form, emptyForm())
  await loadFormWindows(form.canteenId)
  if (!form.windowId && formWindows.value.length > 0) {
    form.windowId = formWindows.value[0].id
  }
  resetImageState()
  dialogVisible.value = true
}

function buildMenuParams() {
  const params = { size: 100, allDates: true }
  if (filters.canteenId) params.canteenId = filters.canteenId
  if (filters.windowId) params.windowId = filters.windowId
  if (filters.category) params.category = filters.category
  if (filters.keyword?.trim()) params.keyword = filters.keyword.trim()
  return params
}

async function loadMenus() {
  loading.value = true
  try {
    const res = await api.menus(buildMenuParams())
    menus.value = res.data?.records || []
  } finally {
    loading.value = false
  }
}

async function loadCanteens() {
  const res = await api.canteens()
  canteens.value = res.data || []
}

async function loadFilterWindows(canteenId = filters.canteenId) {
  const params = {}
  if (canteenId) {
    params.canteenId = canteenId
  }
  const res = await api.windows(params)
  filterWindows.value = res.data || []
}

async function loadFormWindows(canteenId = form.canteenId) {
  if (!canteenId) {
    formWindows.value = []
    return
  }
  const res = await api.windows({ canteenId })
  formWindows.value = res.data || []
}

async function handleFilterCanteenChange() {
  filters.windowId = null
  await loadFilterWindows(filters.canteenId)
  await loadMenus()
}

async function handleFormCanteenChange() {
  form.windowId = null
  await loadFormWindows(form.canteenId)
  if (formWindows.value.length === 1) {
    form.windowId = formWindows.value[0].id
  }
}

async function resetFilters() {
  filters.canteenId = null
  filters.windowId = null
  filters.category = ''
  filters.keyword = ''
  await loadFilterWindows(filters.canteenId)
  await loadMenus()
}

function windowLabel(item) {
  return item.floor ? `${item.name}（${item.floor}楼）` : item.name
}

function resetImageState() {
  if (imagePreviewUrl.value) {
    URL.revokeObjectURL(imagePreviewUrl.value)
  }
  imageFile.value = null
  imagePreviewUrl.value = ''
  uploadFileList.value = []
}

function handleImageChange(file) {
  if (imagePreviewUrl.value) {
    URL.revokeObjectURL(imagePreviewUrl.value)
  }
  imageFile.value = file.raw
  imagePreviewUrl.value = file.raw ? URL.createObjectURL(file.raw) : ''
  uploadFileList.value = [file]
}

function clearImage() {
  resetImageState()
  form.imageUrl = ''
}

async function edit(row) {
  Object.assign(form, emptyForm(), row)
  form.canteenId = row.canteenId || form.canteenId
  await loadFormWindows(form.canteenId)
  resetImageState()
  dialogVisible.value = true
}

async function save() {
  const valid = await formRef.value.validate().catch(() => false)
  if (!valid) return

  loading.value = true
  try {
    let imageUrl = form.imageUrl
    if (imageFile.value) {
      const imgPayload = new FormData()
      imgPayload.append('imageFile', imageFile.value)
      const uploadRes = await api.uploadMenuImage(imgPayload)
      const uploadedImageUrl = uploadRes.data?.imageUrl
      if (!uploadedImageUrl) {
        ElMessage.error('图片上传失败，请重新选择图片')
        return
      }
      imageUrl = uploadedImageUrl
    }

    const menuData = {
      windowId: form.windowId,
      name: form.name,
      category: form.category,
      price: form.price,
      stock: form.stock,
      description: form.description || '',
      imageUrl: imageUrl || ''
    }

    if (form.id) {
      await api.updateMenu(form.id, menuData)
    } else {
      await api.createMenu(menuData)
    }
    ElMessage.success(form.id ? '编辑成功' : '新增成功')
    Object.assign(form, emptyForm())
    resetImageState()
    dialogVisible.value = false
    await loadMenus()
  } catch (e) {
    // error handled by interceptor
  } finally {
    loading.value = false
  }
}

async function remove(id) {
  const ok = await confirmDelete('确定删除该菜品吗？')
  if (!ok) return
  loading.value = true
  try {
    await api.deleteMenu(id)
    ElMessage.success('删除成功')
    await loadMenus()
  } finally {
    loading.value = false
  }
}

onMounted(async () => {
  filters.canteenId = null
  filters.windowId = null
  await loadCanteens()
  await loadFilterWindows(filters.canteenId)
  await loadMenus()
})

onBeforeUnmount(() => {
  if (imagePreviewUrl.value) {
    URL.revokeObjectURL(imagePreviewUrl.value)
  }
})
</script>

<style scoped>
.menu-manage-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 16px;
  margin-bottom: 16px;
}
.menu-manage-header .page-title {
  margin-bottom: 4px;
}
.menu-manage-header p {
  margin: 0;
  color: #6d6258;
  font-size: 13px;
}
.filter-bar {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
  margin-bottom: 16px;
}
.form-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
}
@media (max-width: 768px) {
  .menu-manage-header,
  .form-grid {
    grid-template-columns: 1fr;
    flex-direction: column;
  }
  .filter-bar .el-select,
  .filter-bar .el-input {
    width: 100% !important;
  }
}
</style>
