<template>
  <div class="page-shell" v-loading="loading">
    <div class="page-card" style="margin-bottom:16px">
      <p style="color:#999;font-size:14px">统计范围：今日数据</p>
    </div>
    <div class="chart-grid">
      <StatChart :option="hotDishesOption" height="380px" :loading="loading" />
      <StatChart :option="timeSlotsOption" height="380px" :loading="loading" />
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref, computed } from 'vue'
import { api } from '@/api/request'
import StatChart from '@/components/common/StatChart.vue'

const hotDishes = ref([])
const timeSlots = ref([])
const loading = ref(false)

const hotDishesOption = computed(() => {
  const dishes = hotDishes.value || []
  const names = dishes.map(d => d.menuName || '')
  const quantities = dishes.map(d => d.totalQuantity || 0)
  return {
    title: { text: '热门菜品排行', left: 'center', textStyle: { fontSize: 15, color: '#27211b' } },
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    grid: { left: 100, right: 30, top: 50, bottom: 30 },
    xAxis: { type: 'value', splitLine: { lineStyle: { color: '#f0ebe0' } } },
    yAxis: {
      type: 'category',
      data: names,
      inverse: true,
      axisLine: { lineStyle: { color: '#e3d8cb' } }
    },
    series: [{
      data: quantities,
      type: 'bar',
      itemStyle: {
        color: '#409E67',
        borderRadius: [0, 6, 6, 0]
      }
    }]
  }
})

const timeSlotsOption = computed(() => {
  const slots = timeSlots.value || []
  const slotNames = slots.map(s => s.timeSlot || '')
  const counts = slots.map(s => s.orderCount || 0)
  return {
    title: { text: '取餐时段分布', left: 'center', textStyle: { fontSize: 15, color: '#27211b' } },
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    grid: { left: 30, right: 30, top: 50, bottom: 30 },
    xAxis: {
      type: 'category',
      data: slotNames,
      axisLine: { lineStyle: { color: '#e3d8cb' } }
    },
    yAxis: { type: 'value', minInterval: 1, splitLine: { lineStyle: { color: '#f0ebe0' } } },
    series: [{
      data: counts,
      type: 'bar',
      itemStyle: {
        color: '#e6a23c',
        borderRadius: [6, 6, 0, 0]
      }
    }]
  }
})

onMounted(async () => {
  loading.value = true
  try {
    hotDishes.value = (await api.hotDishes()).data || []
    timeSlots.value = (await api.timeSlots()).data || []
  } finally {
    loading.value = false
  }
})
</script>

<style scoped>
.chart-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}
@media (max-width: 768px) {
  .chart-grid {
    grid-template-columns: 1fr;
  }
}
</style>
