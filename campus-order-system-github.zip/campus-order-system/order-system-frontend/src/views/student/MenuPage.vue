<template>
  <div class="page-shell">
    <div class="page-card">
      <h2 class="page-title">实时菜单</h2>
      <div class="search-bar">
        <el-select v-model="query.canteenId" clearable placeholder="选择食堂" style="width: 160px">
          <el-option v-for="item in canteens" :key="item.id" :label="item.name" :value="item.id" />
        </el-select>
        <el-select v-model="query.windowId" clearable placeholder="选择窗口" style="width: 180px" :disabled="!query.canteenId">
          <el-option v-for="item in windows" :key="item.id" :label="item.name" :value="item.id" />
        </el-select>
        <el-input v-model="query.keyword" placeholder="搜索菜品" style="max-width: 240px" clearable />
        <el-button type="primary" @click="loadMenus">查询</el-button>
      </div>
      <div class="category-bar">
        <el-radio-group v-model="query.category">
          <el-radio-button label="">全部</el-radio-button>
          <el-radio-button label="主食">主食</el-radio-button>
          <el-radio-button label="小吃">小吃</el-radio-button>
          <el-radio-button label="饮料">饮料</el-radio-button>
        </el-radio-group>
      </div>
      <div v-loading="loading">
        <el-empty v-if="!loading && menus.length === 0" description="暂无菜品数据" />
        <div v-else class="menu-grid">
          <MenuCard
            v-for="menu in menus"
            :key="menu.id"
            :menu="menu"
            @add-to-cart="handleAddToCart"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { useRoute } from 'vue-router'
import { api } from '@/api/request'
import MenuCard from '@/components/common/MenuCard.vue'

const route = useRoute()
const query = reactive({
  canteenId: null,
  windowId: null,
  keyword: '',
  category: ''
})
const canteens = ref([])
const windows = ref([])
const menus = ref([])
const loading = ref(false)
let syncingFilters = false

async function loadMenus() {
  loading.value = true
  try {
    const res = await api.menus(query)
    menus.value = res.data?.records || []
  } finally {
    loading.value = false
  }
}

async function handleAddToCart(menu, quantity) {
  await api.addCart({ menuId: menu.id, quantity })
  ElMessage.success(`已加入购物车 x${quantity}`)
  await loadMenus()
}

async function loadWindows(canteenId) {
  if (!canteenId) {
    windows.value = []
    return
  }
  const res = await api.windows({ canteenId })
  windows.value = res.data || []
}

function toNullableNumber(value) {
  if (value === undefined || value === null || value === '') return null
  const parsed = Number(value)
  return Number.isNaN(parsed) ? null : parsed
}

watch(() => query.canteenId, async (canteenId, previousCanteenId) => {
  if (syncingFilters) return
  if (canteenId === previousCanteenId) return
  query.windowId = null
  await loadWindows(canteenId)
  await loadMenus()
})

watch(() => query.windowId, async () => {
  if (syncingFilters) return
  await loadMenus()
})

watch(() => query.category, async () => {
  if (syncingFilters) return
  await loadMenus()
})

onMounted(async () => {
  const res = await api.canteens()
  canteens.value = res.data || []
  syncingFilters = true
  query.canteenId = toNullableNumber(route.query.canteenId)
  query.windowId = toNullableNumber(route.query.windowId)
  query.keyword = route.query.keyword || ''
  if (query.canteenId) {
    await loadWindows(query.canteenId)
  }
  syncingFilters = false
  await loadMenus()
})
</script>

<style scoped>
.search-bar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}

.category-bar {
  margin-bottom: 20px;
}

.menu-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  gap: 16px;
}

@media (max-width: 768px) {
  .menu-grid {
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 12px;
  }

  .search-bar {
    flex-direction: column;
    align-items: stretch;
  }

  .search-bar .el-select,
  .search-bar .el-input {
    max-width: none !important;
    width: 100% !important;
  }
}

@media (max-width: 480px) {
  .menu-grid {
    grid-template-columns: 1fr;
  }
}
</style>
