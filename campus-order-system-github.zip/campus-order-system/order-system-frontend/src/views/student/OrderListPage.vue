<template>
  <div class="page-shell">
    <div class="page-card">
      <h2 class="page-title">我的订单</h2>
      <div style="margin-bottom:12px">
        <el-radio-group v-model="filterStatus" @change="loadOrders">
          <el-radio-button label="">全部</el-radio-button>
          <el-radio-button :value="0">待支付</el-radio-button>
          <el-radio-button :value="1">待制作</el-radio-button>
          <el-radio-button :value="2">制作中</el-radio-button>
          <el-radio-button :value="3">待取餐</el-radio-button>
          <el-radio-button :value="4">已完成</el-radio-button>
          <el-radio-button :value="5">已取消</el-radio-button>
        </el-radio-group>
      </div>
      <div v-loading="loading">
        <el-empty v-if="orders.length === 0" description="暂无订单" />
        <el-table v-else :data="orders">
          <el-table-column prop="orderNo" label="订单号" />
          <el-table-column prop="pickupNumber" label="取餐号" />
          <el-table-column prop="canteenName" label="食堂" />
          <el-table-column prop="windowName" label="窗口" />
          <el-table-column prop="totalAmount" label="金额" />
          <el-table-column label="状态">
            <template #default="{ row }">
              <StatusTag :status="row.status" />
            </template>
          </el-table-column>
          <el-table-column prop="pickupTimeSlot" label="时段" />
          <el-table-column label="操作" width="240">
            <template #default="{ row }">
              <el-button link type="primary" @click="$router.push(`/student/orders/${row.id}`)">详情</el-button>
              <el-button v-if="row.status === 0" link @click="pay(row)">支付</el-button>
              <el-button v-if="[0,1].includes(row.status)" link type="danger" @click="cancel(row.id)">取消</el-button>
              <el-button v-if="row.status === 4" link @click="$router.push(`/student/review/${row.id}`)">评价</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onBeforeUnmount, onMounted, ref } from 'vue'
import { api } from '@/api/request'
import { confirmDelete } from '@/composables/useConfirm'
import StatusTag from '@/components/common/StatusTag.vue'

const orders = ref([])
const loading = ref(false)
const filterStatus = ref('')
let timer = null

async function loadOrders() {
  loading.value = true
  try {
    const params = {}
    if (filterStatus.value !== '') {
      params.status = filterStatus.value
    }
    const res = await api.orders(params)
    orders.value = res.data?.records || res.data || []
  } finally {
    loading.value = false
  }
}

async function pay(row) {
  await api.payOrder(row.id, { paymentMethod: row.paymentMethod || 'ALIPAY' })
  await loadOrders()
}

async function cancel(id) {
  const ok = await confirmDelete('确定取消该订单吗？')
  if (!ok) return
  await api.cancelOrder(id)
  await loadOrders()
}

onMounted(() => {
  loadOrders()
  timer = setInterval(loadOrders, 10000)
})

onBeforeUnmount(() => {
  if (timer) clearInterval(timer)
})
</script>
