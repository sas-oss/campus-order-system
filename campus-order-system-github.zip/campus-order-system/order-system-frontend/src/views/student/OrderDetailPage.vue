<template>
  <div class="page-shell">
    <div class="page-card">
      <h2 class="page-title">订单详情</h2>
      <div v-loading="loading">
        <el-result v-if="error" status="error" :title="error">
          <template #extra>
            <el-button type="primary" @click="fetchDetail()">重试</el-button>
          </template>
        </el-result>
        <el-empty v-else-if="!detail" description="订单不存在" />
        <template v-else>
          <div class="panel-grid" style="margin-bottom:16px">
            <div class="stat-box"><h4>订单号</h4><strong style="font-size:18px">{{ detail.orderNo }}</strong></div>
            <div class="stat-box"><h4>取餐号</h4><strong>{{ detail.pickupNumber }}</strong></div>
            <div class="stat-box"><h4>状态</h4>
              <StatusTag :status="detail.status" size="large" />
            </div>
          </div>
          <div class="panel-grid" style="margin-bottom:16px">
            <div class="stat-box"><h4>取餐时段</h4><strong>{{ detail.pickupTimeSlot || '-' }}</strong></div>
            <div class="stat-box"><h4>食堂</h4><strong>{{ detail.canteenName || '-' }}</strong></div>
            <div class="stat-box"><h4>窗口</h4><strong>{{ detail.windowName || '-' }}</strong></div>
          </div>
          <!-- 订单状态时间线 -->
          <div class="timeline-wrap">
            <OrderTimeline
              :status="detail.status"
              :create-time="detail.createTime"
              :payment-time="detail.paymentTime"
              :finish-time="detail.finishTime"
            />
          </div>

          <!-- 取餐二维码（状态=3时显示） -->
          <div v-if="detail.status === 3" class="pickup-qr-section">
            <div class="qr-card">
              <div class="qr-pulse-ring">
                <div class="qr-inner">
                  <span class="qr-number">{{ detail.pickupNumber }}</span>
                  <small>取餐号</small>
                </div>
              </div>
              <img v-if="pickupQrUrl" class="pickup-qr-image" :src="pickupQrUrl" alt="取餐二维码" />
              <p class="qr-tip">请向窗口工作人员出示取餐号</p>
              <p class="qr-tip">取餐码：<strong>{{ detail.pickupCode }}</strong></p>
              <p class="qr-note">工作人员核销后，订单状态将自动更新为已取餐</p>
            </div>
          </div>

          <el-table :data="detail.items || []">
            <el-table-column prop="menuName" label="菜品" />
            <el-table-column prop="quantity" label="数量" />
            <el-table-column prop="unitPrice" label="单价" />
            <el-table-column prop="subtotal" label="小计" />
          </el-table>
          <div style="text-align:right;margin-top:16px;font-size:16px">
            合计：<strong style="color:#409E67">¥{{ detail.totalAmount }}</strong>
          </div>
          <div style="margin-top:16px;display:flex;gap:8px">
            <el-button v-if="detail.status === 0" type="success" @click="pay">立即支付</el-button>
            <el-button v-if="[0,1].includes(detail.status)" type="danger" @click="cancel">取消订单</el-button>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { api } from '@/api/request'
import { confirmDelete } from '@/composables/useConfirm'
import StatusTag from '@/components/common/StatusTag.vue'
import OrderTimeline from '@/components/common/OrderTimeline.vue'

const route = useRoute()
const detail = ref(null)
const loading = ref(false)
const error = ref(null)
let pollingTimer = null

const pickupQrUrl = computed(() => {
  if (!detail.value?.pickupCode) return ''
  const payload = JSON.stringify({
    orderId: detail.value.id,
    pickupNumber: detail.value.pickupNumber,
    pickupCode: detail.value.pickupCode
  })
  return `https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent(payload)}`
})

async function fetchDetail(silent) {
  if (!silent) {
    loading.value = true
    error.value = null
  }
  try {
    const res = await api.orderDetail(route.params.id)
    const newData = res.data
    if (detail.value && newData.status !== detail.value.status) {
      const statusMap = { 2: '窗口已开始制作', 3: '制作完成，请前往窗口取餐', 4: '已取餐', 5: '订单已取消' }
      const msg = statusMap[newData.status]
      if (msg) ElMessage({ message: msg, type: newData.status === 5 ? 'warning' : 'success', duration: 5000 })
    }
    detail.value = newData
    if ([4, 5].includes(newData.status)) stopPolling()
  } catch (e) {
    if (!silent) error.value = e?.response?.data?.message || e?.message || '加载失败'
  } finally {
    if (!silent) loading.value = false
  }
}

async function pay() {
  loading.value = true
  try {
    await api.payOrder(detail.value.id, { paymentMethod: detail.value.paymentMethod || 'ALIPAY' })
    ElMessage.success('支付成功')
    await fetchDetail()
  } catch (e) {
    loading.value = false
  }
}

async function cancel() {
  const ok = await confirmDelete('确定取消该订单吗？')
  if (!ok) return
  loading.value = true
  try {
    await api.cancelOrder(detail.value.id)
    await fetchDetail()
  } catch (e) {
    loading.value = false
  }
}

function startPolling() {
  stopPolling()
  pollingTimer = setInterval(() => fetchDetail(true), 8000)
}

function stopPolling() {
  if (pollingTimer) { clearInterval(pollingTimer); pollingTimer = null }
}

onMounted(async () => {
  await fetchDetail()
  startPolling()
})

onBeforeUnmount(stopPolling)
</script>

<style scoped>
.timeline-wrap {
  margin: 20px 0;
  padding: 16px;
  background: #fafaf5;
  border-radius: 10px;
}
.pickup-qr-section {
  display: flex;
  justify-content: center;
  margin: 20px 0;
}
.qr-card {
  text-align: center;
}
.pickup-qr-image {
  width: 160px;
  height: 160px;
  margin-top: 14px;
  border: 1px solid #e3d8cb;
  border-radius: 8px;
  background: #fff;
  padding: 6px;
}
.qr-pulse-ring {
  width: 140px;
  height: 140px;
  border-radius: 50%;
  border: 3px solid #67c23a;
  display: grid;
  place-items: center;
  animation: qr-pulse 2s ease-in-out infinite;
}
@keyframes qr-pulse {
  0%, 100% { box-shadow: 0 0 0 0 rgba(103, 194, 58, 0.4); }
  50% { box-shadow: 0 0 0 16px rgba(103, 194, 58, 0); }
}
.qr-inner {
  display: flex;
  flex-direction: column;
  align-items: center;
}
.qr-number {
  font-size: 32px;
  font-weight: 800;
  color: #409E67;
  letter-spacing: 2px;
}
.qr-inner small {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}
.qr-tip {
  margin-top: 12px;
  font-size: 13px;
  color: #67c23a;
  font-weight: 500;
}
.qr-note {
  margin-top: 8px;
  font-size: 13px;
  color: #909399;
}
</style>
