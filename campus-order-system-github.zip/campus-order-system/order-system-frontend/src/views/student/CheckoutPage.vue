<template>
  <div class="page-shell">
    <div class="page-card">
      <h2 class="page-title">确认订单</h2>
      <el-empty v-if="!cart.items || cart.items.length === 0" description="购物车为空，请先添加菜品">
        <el-button type="primary" @click="$router.push('/student/menu')">去看看</el-button>
      </el-empty>
      <template v-else>
        <el-alert
          :title="`将按 ${windowGroups.length} 个窗口生成 ${windowGroups.length} 笔订单`"
          type="info"
          show-icon
          :closable="false"
          style="margin-bottom:16px"
        />
        <div class="panel-grid" style="margin-bottom:16px">
          <div class="stat-box" v-for="group in windowGroups" :key="group.windowId">
            <h4>{{ group.canteenName }}</h4>
            <div style="font-weight:700;margin-bottom:8px">{{ group.windowName }}</div>
            <div v-for="item in group.items" :key="item.id" style="margin-top:6px">
              {{ item.menuName }} x{{ item.quantity }}
              <span style="color:#409E67">￥{{ item.subtotal }}</span>
            </div>
            <strong style="display:block;margin-top:8px">小计：￥{{ group.totalAmount }}</strong>
          </div>
        </div>
        <div style="text-align:right;margin-bottom:16px;font-size:16px">
          合计：<strong style="color:#409E67">￥{{ cart.totalAmount }}</strong>
        </div>
        <el-form ref="formRef" :model="form" :rules="rules" label-position="top">
          <el-form-item label="取餐时段" prop="pickupTimeSlot">
            <el-select v-model="form.pickupTimeSlot" style="width:260px">
              <el-option label="11:30-12:00" value="11:30-12:00" />
              <el-option label="12:00-12:30" value="12:00-12:30" />
              <el-option label="12:30-13:00" value="12:30-13:00" />
            </el-select>
          </el-form-item>
          <el-form-item label="支付方式" prop="paymentMethod">
            <el-radio-group v-model="form.paymentMethod">
              <el-radio label="ALIPAY">支付宝</el-radio>
              <el-radio label="WECHAT">微信</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="备注">
            <el-input v-model="form.remark" type="textarea" :rows="3" placeholder="特殊要求（可选）" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" :loading="submitting" @click="submit">提交订单</el-button>
          </el-form-item>
        </el-form>
      </template>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { useRouter } from 'vue-router'
import { api } from '@/api/request'

const router = useRouter()
const formRef = ref(null)
const submitting = ref(false)
const cart = ref({ items: [], totalAmount: 0 })

const form = reactive({
  pickupTimeSlot: '11:30-12:00',
  paymentMethod: 'ALIPAY',
  remark: ''
})

const rules = {
  pickupTimeSlot: [{ required: true, message: '请选择取餐时段', trigger: 'change' }],
  paymentMethod: [{ required: true, message: '请选择支付方式', trigger: 'change' }]
}

const windowGroups = computed(() => {
  const groups = new Map()
  for (const item of cart.value.items || []) {
    const key = item.windowId || 'unknown'
    if (!groups.has(key)) {
      groups.set(key, {
        windowId: item.windowId,
        canteenName: item.canteenName || '未知食堂',
        windowName: item.windowName || '未知窗口',
        items: [],
        totalAmount: 0
      })
    }
    const group = groups.get(key)
    group.items.push(item)
    group.totalAmount += Number(item.subtotal || 0)
  }
  return Array.from(groups.values()).map(group => ({
    ...group,
    totalAmount: group.totalAmount.toFixed(2)
  }))
})

async function loadCart() {
  try {
    const res = await api.cart()
    cart.value = res.data || { items: [], totalAmount: 0 }
  } catch (e) {
    // ignore
  }
}

async function submit() {
  const valid = await formRef.value.validate().catch(() => false)
  if (!valid) return
  submitting.value = true
  try {
    const res = await api.createOrder(form)
    const orders = Array.isArray(res.data) ? res.data : [res.data].filter(Boolean)
    ElMessage.success(`订单创建成功，共生成 ${orders.length} 笔订单`)
    router.push('/student/orders')
  } catch (e) {
    // error handled by interceptor
  } finally {
    submitting.value = false
  }
}

onMounted(loadCart)
</script>
