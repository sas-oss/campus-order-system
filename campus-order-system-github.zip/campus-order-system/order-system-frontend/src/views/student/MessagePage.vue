<template>
  <div class="page-shell">
    <div class="page-card">
      <h2 class="page-title">消息中心</h2>
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
        <el-radio-group v-model="filterType" size="small">
          <el-radio-button label="">全部</el-radio-button>
          <el-radio-button :value="1">订单提醒</el-radio-button>
          <el-radio-button :value="2">取餐提醒</el-radio-button>
          <el-radio-button :value="3">系统通知</el-radio-button>
        </el-radio-group>
        <el-button type="primary" size="small" :disabled="unreadCount === 0" @click="markAllRead">全部已读</el-button>
      </div>
      <div v-loading="loading">
        <el-empty v-if="!loading && filteredMessages.length === 0" description="暂无消息" />
        <el-table v-else :data="filteredMessages" style="width:100%">
          <el-table-column prop="title" label="标题" min-width="140" />
          <el-table-column label="类型" width="100">
            <template #default="{ row }">
              <el-tag :type="row.type === 1 ? '' : row.type === 2 ? 'success' : 'info'" size="small">
                {{ row.typeText }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column label="内容" min-width="420">
            <template #default="{ row }">
              <div class="message-content">{{ row.content }}</div>
            </template>
          </el-table-column>
          <el-table-column label="时间" width="170">
            <template #default="{ row }">
              {{ formatTime(row.createTime) }}
            </template>
          </el-table-column>
          <el-table-column label="状态" width="80">
            <template #default="{ row }">
              <el-tag :type="row.read ? 'info' : 'danger'" size="small">{{ row.read ? '已读' : '未读' }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="90">
            <template #default="{ row }">
              <el-button v-if="!row.read" link size="small" @click="read(row.id)">标记已读</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { api } from '@/api/request'

const messages = ref([])
const loading = ref(false)
const filterType = ref('')

const unreadCount = computed(() => messages.value.filter(m => !m.read).length)

const filteredMessages = computed(() => {
  if (!filterType.value) return messages.value
  return messages.value.filter(m => m.type === filterType.value)
})

async function loadMessages() {
  loading.value = true
  try {
    const res = await api.messages({ page: 1, size: 50 })
    // 处理后端分页响应 { records, total, page, size }
    messages.value = res.data?.records || res.data || []
  } finally {
    loading.value = false
  }
}

async function read(id) {
  await api.readMessage(id)
  await loadMessages()
}

async function markAllRead() {
  try {
    await api.markAllRead()
    ElMessage.success('已全部标记为已读')
    await loadMessages()
  } catch (e) {
    ElMessage.error('操作失败')
  }
}

function formatTime(value) {
  if (!value) return '-'
  return String(value).replace('T', ' ').slice(0, 19)
}

onMounted(loadMessages)
</script>

<style scoped>
.message-content {
  white-space: normal;
  word-break: break-word;
  line-height: 1.6;
  color: #303133;
}
</style>
