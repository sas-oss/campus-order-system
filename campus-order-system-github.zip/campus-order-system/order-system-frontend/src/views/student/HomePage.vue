<template>
  <div class="page-shell">
    <!-- 问候横幅 -->
    <div class="greeting-banner">
      <div class="greeting-copy">
        <h2 class="page-title">{{ greeting }}</h2>
        <p>欢迎使用校园食堂在线订餐平台</p>
      </div>
      <div class="quick-stats">
        <div class="quick-stat" @click="$router.push('/student/orders')">
          <span class="quick-stat-num">{{ activeOrderCount }}</span>
          <span class="quick-stat-label">进行中订单</span>
        </div>
        <div class="quick-stat" @click="$router.push('/student/messages')">
          <span class="quick-stat-num">{{ unreadCount }}</span>
          <span class="quick-stat-label">未读消息</span>
        </div>
      </div>
    </div>

    <!-- AI 点餐助手 -->
    <div class="ai-assistant" style="margin-top:16px">
      <div class="ai-main">
        <div class="ai-heading">
          <div>
            <span class="ai-badge">AI</span>
            <h3>AI 点餐助手</h3>
          </div>
          <el-button type="primary" :loading="aiLoading" @click="askAiAssistant">生成搭配</el-button>
        </div>
        <el-input
          v-model="aiForm.preference"
          class="ai-input"
          placeholder="例如：想吃辣一点，25元以内，赶时间"
        />
        <div class="ai-controls">
          <button
            v-for="item in flavorOptions"
            :key="item"
            type="button"
            class="quick-tag"
            :class="{ active: aiForm.flavor === item }"
            @click="toggleTag('flavor', item)"
          >
            {{ item }}
          </button>
          <span class="control-divider"></span>
          <button
            v-for="item in sceneOptions"
            :key="item"
            type="button"
            class="quick-tag"
            :class="{ active: aiForm.scene === item }"
            @click="toggleTag('scene', item)"
          >
            {{ item }}
          </button>
          <el-input-number v-model="aiForm.budget" :min="8" :max="60" :step="1" size="small" class="budget-input" />
        </div>
      </div>
      <div v-if="aiResult" class="ai-result">
        <div class="ai-reply">{{ aiResult.reply }}</div>
        <div class="ai-meta">
          <span>{{ aiResult.canteenName }}</span>
          <span>{{ aiResult.windowName }}</span>
          <strong>合计 ¥{{ aiResult.totalAmount }}</strong>
        </div>
        <div class="ai-menu-row">
          <button
            v-for="dish in aiResult.menus"
            :key="dish.id"
            class="ai-menu-item"
            type="button"
            @click="goToMenu(dish)"
          >
            <span>{{ dish.name }}</span>
            <strong>¥{{ dish.price }}</strong>
          </button>
        </div>
      </div>
      <div v-else class="ai-empty">
        <strong>输入需求后生成搭配</strong>
        <span>结果会结合真实菜单、库存和预算。</span>
      </div>
    </div>

    <!-- 食堂列表 -->
    <div class="page-card canteen-section" style="margin-top:16px">
      <h3 style="margin:0 0 14px">🏫 选择食堂</h3>
      <div v-loading="loading">
        <el-empty v-if="canteens.length === 0" description="暂无营业食堂" />
        <div v-else class="canteen-grid">
          <div v-for="item in canteens" :key="item.id" class="canteen-card" @click="$router.push({ path: '/student/menu', query: { canteenId: item.id } })">
            <div class="canteen-avatar">{{ item.name.charAt(0) }}</div>
            <div class="canteen-info">
              <h4>{{ item.name }}</h4>
              <p>{{ item.address || '校园内' }}</p>
              <p v-if="item.description" class="canteen-desc">{{ item.description }}</p>
              <span class="canteen-window-count">{{ item.windows?.length || 0 }} 个窗口</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 推荐菜品 -->
    <div class="page-card featured-section" style="margin-top:16px" v-if="featuredDishes.length > 0">
      <h3 style="margin:0 0 16px">🌟 今日推荐</h3>
      <div class="featured-scroll">
        <div v-for="dish in featuredDishes" :key="dish.id" class="featured-dish" @click="$router.push({ path: '/student/menu', query: { canteenId: dish.canteenId, windowId: dish.windowId } })">
          <el-image v-if="dish.imageUrl" :src="dish.imageUrl" style="width:100%;height:100px;border-radius:8px 8px 0 0" fit="cover" />
          <div v-else class="featured-placeholder">🍽️</div>
          <div class="featured-info">
            <strong>{{ dish.name }}</strong>
            <span style="color:#409E67;font-weight:700">¥{{ dish.price }}</span>
            <small v-if="dish.reason" class="featured-reason">{{ dish.reason }}</small>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { api } from '@/api/request'
import { useUserStore } from '@/stores/user'

const userStore = useUserStore()
const router = useRouter()
const canteens = ref([])
const loading = ref(false)
const activeOrderCount = ref(0)
const unreadCount = ref(0)
const featuredDishes = ref([])
const aiLoading = ref(false)
const aiResult = ref(null)
const flavorOptions = ['清淡', '香辣', '管饱', '实惠']
const sceneOptions = ['赶时间', '正常午餐', '想尝新品']
const aiForm = reactive({
  preference: '',
  flavor: '',
  scene: '',
  budget: 25
})

function getGreeting() {
  const name = userStore.userInfo.realName || '同学'
  const h = new Date().getHours()
  if (h >= 5 && h < 12) return `早上好，${name}`
  if (h >= 12 && h < 18) return `下午好，${name}`
  return `晚上好，${name}`
}
const greeting = computed(getGreeting)

function toggleTag(field, value) {
  aiForm[field] = aiForm[field] === value ? '' : value
}

async function askAiAssistant() {
  aiLoading.value = true
  try {
    const res = await api.aiMealAssistant({
      preference: aiForm.preference,
      flavor: aiForm.flavor,
      scene: aiForm.scene,
      budget: aiForm.budget
    })
    aiResult.value = res.data
  } finally {
    aiLoading.value = false
  }
}

function goToMenu(dish) {
  router.push({ path: '/student/menu', query: { canteenId: dish.canteenId, windowId: dish.windowId } })
}

async function loadCanteens() {
  loading.value = true
  try {
    const canteenRes = await api.canteens()
    canteens.value = canteenRes.data || []
  } finally {
    loading.value = false
  }
}

async function loadStats() {
  try {
    const orderRes = await api.orders({ status: '' })
    const orders = orderRes.data?.records || orderRes.data || []
    activeOrderCount.value = orders.filter(o => [0,1,2,3].includes(o.status)).length
  } catch (e) {
    activeOrderCount.value = 0
  }
  try {
    const msgRes = await api.unreadCount()
    unreadCount.value = msgRes.data ?? 0
  } catch (e) {
    unreadCount.value = 0
  }
}

async function loadFeaturedDishes() {
  try {
    const recommendationRes = await api.aiRecommendations({ limit: 6 })
    featuredDishes.value = recommendationRes.data || []
  } catch (e) {
    featuredDishes.value = []
  }
}

onMounted(() => {
  loadCanteens()
  loadStats()
  window.setTimeout(loadFeaturedDishes, 0)
})
</script>

<style scoped>
.greeting-banner {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: linear-gradient(135deg, #409E67, #67c23a);
  border-radius: 10px;
  padding: 18px 28px;
  color: white;
}
.greeting-copy .page-title {
  margin: 0;
  color: white;
  font-size: 24px;
}
.greeting-copy p {
  color: rgba(255,255,255,0.88);
  margin: 4px 0 0;
}
.quick-stats { display: flex; gap: 14px; }
.quick-stat {
  cursor: pointer;
  text-align: center;
  min-width: 86px;
  padding: 8px 12px;
  background: rgba(255,255,255,0.2);
  border-radius: 8px;
  transition: background 0.2s;
}
.quick-stat:hover { background: rgba(255,255,255,0.35); }
.quick-stat-num { display: block; font-size: 24px; font-weight: 700; line-height: 1.1; }
.quick-stat-label { font-size: 13px; opacity: 0.9; }
.ai-assistant {
  display: grid;
  grid-template-columns: minmax(0, 1.2fr) minmax(260px, 0.8fr);
  gap: 14px;
  padding: 16px 20px;
  border: 1px solid #cfe7d7;
  border-radius: 10px;
  background: #f5fbf7;
}
.ai-heading {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  margin-bottom: 10px;
}
.ai-heading > div {
  display: flex;
  align-items: center;
  gap: 10px;
}
.ai-heading h3 { margin: 0; }
.ai-badge {
  width: 32px;
  height: 32px;
  display: grid;
  place-items: center;
  border-radius: 7px;
  background: #1f7a4a;
  color: white;
  font-weight: 800;
}
.ai-input :deep(.el-input__wrapper) {
  min-height: 40px;
}
.ai-controls {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
  margin-top: 10px;
}
.quick-tag {
  height: 28px;
  padding: 0 10px;
  border: 1px solid #d7e3dc;
  border-radius: 6px;
  background: #fff;
  color: #44534a;
  cursor: pointer;
  font-size: 13px;
  transition: all 0.16s;
}
.quick-tag:hover {
  border-color: #409E67;
  color: #2f8a5d;
}
.quick-tag.active {
  background: #409E67;
  border-color: #409E67;
  color: #fff;
}
.control-divider {
  width: 1px;
  height: 18px;
  background: #cfe7d7;
}
.budget-input {
  width: 116px;
}
.ai-result {
  border-left: 1px solid #cfe7d7;
  padding-left: 14px;
  align-self: stretch;
}
.ai-reply {
  line-height: 1.55;
  color: #2f3d35;
  font-weight: 600;
}
.ai-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin: 8px 0;
  color: #6d6258;
  font-size: 13px;
}
.ai-meta strong { color: #409E67; }
.ai-menu-row {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}
.ai-menu-item {
  display: flex;
  gap: 8px;
  align-items: center;
  border: 1px solid #cfe7d7;
  background: white;
  color: #2f3d35;
  border-radius: 7px;
  padding: 7px 10px;
  cursor: pointer;
}
.ai-menu-item:hover {
  border-color: #409E67;
  color: #409E67;
}
.ai-empty {
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 6px;
  min-height: 96px;
  border-left: 1px solid #cfe7d7;
  padding-left: 14px;
  color: #6d6258;
}
.ai-empty strong {
  color: #2f3d35;
}
.ai-empty span {
  font-size: 13px;
}
.canteen-section,
.featured-section {
  padding: 18px 22px;
  border-radius: 14px;
}
.canteen-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 12px;
}
.canteen-card {
  display: flex;
  gap: 14px;
  padding: 14px 16px;
  border: 1px solid #e3d8cb;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.2s;
  background: #fffaf3;
}
.canteen-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  border-color: #409E67;
}
.canteen-avatar {
  width: 52px; height: 52px;
  border-radius: 10px;
  background: linear-gradient(135deg, #409E67, #67c23a);
  color: white;
  display: grid; place-items: center;
  font-size: 24px; font-weight: 700;
  flex-shrink: 0;
}
.canteen-info h4 { margin: 0 0 4px; }
.canteen-info p { margin: 0; font-size: 13px; color: #6d6258; }
.canteen-desc { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 200px; }
.canteen-window-count { font-size: 12px; color: #409E67; }
.featured-scroll {
  display: flex;
  gap: 12px;
  overflow-x: auto;
  padding-bottom: 8px;
}
.featured-dish {
  min-width: 150px;
  border: 1px solid #e3d8cb;
  border-radius: 9px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.2s;
  flex-shrink: 0;
}
.featured-dish:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}
.featured-placeholder {
  height: 92px;
  display: grid; place-items: center;
  background: linear-gradient(135deg, #f5e6d3, #e8d5b7);
  font-size: 40px;
}
.featured-info {
  padding: 10px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.featured-reason {
  color: #6d6258;
  line-height: 1.35;
}
@media (max-width: 768px) {
  .greeting-banner { flex-direction: column; gap: 16px; text-align: center; }
  .ai-assistant { grid-template-columns: 1fr; }
  .ai-result,
  .ai-empty { border-left: 0; border-top: 1px solid #cfe7d7; padding-left: 0; padding-top: 14px; }
  .ai-heading { align-items: flex-start; }
  .canteen-grid { grid-template-columns: 1fr; }
}
</style>
