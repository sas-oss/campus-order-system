<template>
  <div class="page-shell">
    <div class="page-card">
      <h2 class="page-title">订单评价</h2>
      <div v-loading="orderLoading">
        <el-empty v-if="!order" description="订单不存在" />
        <template v-else>
          <div class="panel-grid" style="margin-bottom:16px">
            <div class="stat-box"><h4>订单号</h4><strong>{{ order.orderNo }}</strong></div>
            <div class="stat-box"><h4>窗口</h4><strong>{{ order.windowName || '-' }}</strong></div>
            <div class="stat-box"><h4>金额</h4><strong>¥{{ order.totalAmount }}</strong></div>
          </div>

          <!-- 菜品评分 -->
          <h4 style="margin:16px 0 8px">🍽️ 菜品评分</h4>
          <div class="dish-rating-list">
            <div v-for="item in (order.items || [])" :key="item.menuId" class="dish-rating-item">
              <div class="dish-info">
                <span class="dish-name">{{ item.menuName }}</span>
                <span class="dish-qty">x{{ item.quantity }}</span>
              </div>
              <el-rate v-model="dishRatings[item.menuId]" :max="5" size="small" />
            </div>
          </div>

          <!-- 窗口评分 -->
          <h4 style="margin:16px 0 8px">🏪 窗口服务评分</h4>
          <el-rate v-model="form.windowScore" :max="5" style="margin-bottom:16px" />

          <el-form ref="formRef" :model="form" :rules="rules" label-position="top">
            <el-form-item label="文字评价" prop="content">
              <el-input v-model="form.content" type="textarea" :rows="4" placeholder="分享你的用餐体验，至少5个字" />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" :loading="submitting" @click="submit">提交评价</el-button>
            </el-form-item>
          </el-form>
        </template>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { useRoute, useRouter } from 'vue-router'
import { api } from '@/api/request'

const route = useRoute()
const router = useRouter()
const formRef = ref(null)
const submitting = ref(false)
const orderLoading = ref(false)
const order = ref(null)

const dishRatings = reactive({})
const form = reactive({
  orderId: Number(route.params.id),
  score: 5,
  windowScore: 5,
  content: ''
})

const computedScore = computed(() => {
  const dishScores = Object.values(dishRatings).filter(s => s > 0)
  if (dishScores.length === 0) return form.windowScore
  const avgDish = dishScores.reduce((a, b) => a + b, 0) / dishScores.length
  return Math.round((avgDish + form.windowScore) / 2)
})

const rules = {
  content: [{ required: true, message: '请输入评价内容', trigger: 'blur' }, { min: 5, message: '评价内容至少5个字', trigger: 'blur' }]
}

function initDishRatings() {
  if (order.value?.items) {
    order.value.items.forEach(item => {
      dishRatings[item.menuId] = 5
    })
  }
}

async function loadOrder() {
  orderLoading.value = true
  try {
    const res = await api.orderDetail(route.params.id)
    order.value = res.data
    initDishRatings()
  } catch (e) {
    // ignore
  } finally {
    orderLoading.value = false
  }
}

async function submit() {
  const valid = await formRef.value.validate().catch(() => false)
  if (!valid) return

  // Check at least one dish rated
  const ratedDishes = Object.entries(dishRatings).filter(([, s]) => s > 0)
  if (ratedDishes.length === 0 && form.windowScore === 0) {
    ElMessage.warning('请至少为一道菜品或窗口评分')
    return
  }

  submitting.value = true
  try {
    await api.createReview({
      orderId: form.orderId,
      score: computedScore.value,
      windowScore: form.windowScore,
      content: form.content,
      items: order.value.items.map(item => ({
        menuId: item.menuId,
        score: dishRatings[item.menuId] || 5,
        content: ''
      }))
    })
    ElMessage.success('评价成功')
    router.push('/student/orders')
  } catch (e) {
    // error handled by interceptor
  } finally {
    submitting.value = false
  }
}

onMounted(loadOrder)
</script>

<style scoped>
.dish-rating-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-bottom: 8px;
}
.dish-rating-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 14px;
  background: #fafafa;
  border-radius: 8px;
  border: 1px solid #f0f0f0;
}
.dish-info {
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.dish-name {
  font-weight: 600;
  font-size: 14px;
  color: #303133;
}
.dish-qty {
  font-size: 12px;
  color: #909399;
}
</style>
