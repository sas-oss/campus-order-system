<template>
  <div class="page-shell">
    <div class="page-card">
      <h2 class="page-title">购物车</h2>
      <div v-loading="loading">
        <el-empty v-if="!cart.items || cart.items.length === 0" description="购物车是空的，去逛逛吧">
          <el-button type="primary" @click="$router.push('/student/menu')">去看看</el-button>
        </el-empty>
        <template v-else>
          <div class="canteen-groups">
            <section v-for="group in canteenGroups" :key="group.canteenId" class="canteen-group">
              <div class="canteen-header">
                <h3>{{ group.canteenName }}</h3>
                <span>小计：￥{{ group.totalAmount }}</span>
              </div>
              <el-table :data="group.items">
                <el-table-column prop="menuName" label="菜品" />
                <el-table-column prop="windowName" label="窗口" />
                <el-table-column prop="price" label="单价" />
                <el-table-column prop="quantity" label="数量" />
                <el-table-column prop="subtotal" label="小计" />
                <el-table-column label="操作">
                  <template #default="{ row }">
                    <el-button link type="danger" @click="remove(row.id)">删除</el-button>
                  </template>
                </el-table-column>
              </el-table>
            </section>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;margin-top:16px">
            <strong>总金额：￥{{ cart.totalAmount || 0 }}</strong>
            <div>
              <el-button @click="clear">清空</el-button>
              <el-button type="primary" @click="$router.push('/student/checkout')">去下单</el-button>
            </div>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { api } from '@/api/request'
import { confirmDelete } from '@/composables/useConfirm'

const cart = ref({ items: [], totalAmount: 0 })
const loading = ref(false)

const canteenGroups = computed(() => {
  const groups = new Map()
  for (const item of cart.value.items || []) {
    const key = item.canteenId || 'unknown'
    if (!groups.has(key)) {
      groups.set(key, {
        canteenId: key,
        canteenName: item.canteenName || '未知食堂',
        items: [],
        totalAmount: 0
      })
    }
    const group = groups.get(key)
    group.items.push(item)
    group.totalAmount += Number(item.subtotal || 0)
  }
  return Array.from(groups.values()).map(group => ({
    ...group,
    totalAmount: group.totalAmount.toFixed(2)
  }))
})

async function loadCart() {
  loading.value = true
  try {
    const res = await api.cart()
    cart.value = res.data || { items: [], totalAmount: 0 }
  } finally {
    loading.value = false
  }
}

async function remove(id) {
  const ok = await confirmDelete('确定从购物车移除此菜品吗？')
  if (!ok) return
  await api.removeCart(id)
  await loadCart()
}

async function clear() {
  const ok = await confirmDelete('确定清空购物车吗？')
  if (!ok) return
  await api.clearCart()
  await loadCart()
}

onMounted(loadCart)
</script>

<style scoped>
.canteen-groups {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.canteen-group {
  border: 1px solid #ebeef5;
  border-radius: 8px;
  overflow: hidden;
  background: #fff;
}

.canteen-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 14px;
  background: #fafafa;
  border-bottom: 1px solid #ebeef5;
}

.canteen-header h3 {
  margin: 0;
  font-size: 16px;
  font-weight: 700;
}

.canteen-header span {
  color: #409e67;
  font-weight: 700;
  white-space: nowrap;
}

@media (max-width: 640px) {
  .canteen-header {
    align-items: flex-start;
    flex-direction: column;
  }
}
</style>
