<template>
  <div class="login-page">
    <!-- 左侧装饰区 -->
    <div class="login-left">
      <div class="left-content">
        <div class="logo-area">
          <span class="logo-icon">🍽️</span>
          <h1>校园食堂</h1>
          <h2>在线订餐平台</h2>
        </div>
        <p class="slogan">告别排队，错峰取餐<br/>美味不等待</p>
        <div class="feature-list">
          <div class="feature-item">
            <span class="feature-icon">📋</span>
            <span>实时菜单查看</span>
          </div>
          <div class="feature-item">
            <span class="feature-icon">🛒</span>
            <span>在线下单订餐</span>
          </div>
          <div class="feature-item">
            <span class="feature-icon">📱</span>
            <span>取餐实时提醒</span>
          </div>
          <div class="feature-item">
            <span class="feature-icon">⭐</span>
            <span>菜品评价反馈</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 右侧登录区 -->
    <div class="login-right">
      <div class="login-card">
        <el-tabs v-model="activeTab" class="login-tabs">
          <el-tab-pane label="账号登录" name="login" />
          <el-tab-pane label="新用户注册" name="register" />
        </el-tabs>

        <!-- 登录表单 -->
        <el-form v-if="activeTab === 'login'" ref="loginFormRef" :model="loginForm" :rules="loginRules" @keyup.enter="handleLogin">
          <el-form-item prop="username">
            <el-input
              v-model="loginForm.username"
              placeholder="请输入学号或工号"
              size="large"
              :prefix-icon="User"
              clearable
            />
          </el-form-item>
          <el-form-item prop="password">
            <el-input
              v-model="loginForm.password"
              type="password"
              placeholder="请输入密码"
              size="large"
              :prefix-icon="Lock"
              show-password
            />
          </el-form-item>
          <el-form-item prop="role">
            <div class="role-selector">
              <div
                v-for="role in roles"
                :key="role.value"
                class="role-card"
                :class="{ active: loginForm.role === role.value }"
                @click="loginForm.role = role.value"
              >
                <span class="role-emoji">{{ role.icon }}</span>
                <span class="role-label">{{ role.label }}</span>
              </div>
            </div>
          </el-form-item>
          <el-button type="primary" size="large" style="width:100%;height:48px;font-size:16px" :loading="loginLoading" @click="handleLogin">
            登 录
          </el-button>
        </el-form>

        <!-- 注册表单 -->
        <el-form v-else ref="registerFormRef" :model="registerForm" :rules="registerRules" @keyup.enter="handleRegister">
          <el-form-item prop="username">
            <el-input v-model="registerForm.username" placeholder="学生请输入纯数字学号（6-12位）" size="large" :prefix-icon="User" clearable />
          </el-form-item>
          <el-form-item prop="realName">
            <el-input v-model="registerForm.realName" placeholder="请输入真实姓名" size="large" :prefix-icon="User" clearable />
          </el-form-item>
          <el-form-item prop="phone">
            <el-input v-model="registerForm.phone" placeholder="请输入手机号（选填）" size="large" clearable />
          </el-form-item>
          <el-form-item prop="password">
            <el-input v-model="registerForm.password" type="password" placeholder="请输入密码（至少6位）" size="large" :prefix-icon="Lock" show-password />
          </el-form-item>
          <el-form-item prop="role">
            <div class="role-selector">
              <div
                v-for="role in registerRoles"
                :key="role.value"
                class="role-card"
                :class="{ active: registerForm.role === role.value }"
                @click="registerForm.role = role.value"
              >
                <span class="role-emoji">{{ role.icon }}</span>
                <span class="role-label">{{ role.label }}</span>
              </div>
            </div>
          </el-form-item>
          <el-button type="success" size="large" style="width:100%;height:48px;font-size:16px" :loading="registerLoading" @click="handleRegister">
            注 册
          </el-button>
        </el-form>

        <!-- 测试账号提示 -->
        <div class="test-accounts">
          <p class="test-title">🔑 测试账号（密码均为 123456）</p>
          <div class="test-grid">
            <span class="test-tag" @click="quickFill('20240001', 'STUDENT')">学生 20240001</span>
            <span class="test-tag" @click="quickFill('admin001', 'CANTEEN_ADMIN')">管理员 admin001</span>
            <span class="test-tag" @click="quickFill('system001', 'SYSTEM_ADMIN')">超管 system001</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { User, Lock } from '@element-plus/icons-vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { api } from '@/api/request'

const router = useRouter()
const userStore = useUserStore()
const activeTab = ref('login')
const loginLoading = ref(false)
const registerLoading = ref(false)

const loginFormRef = ref(null)
const registerFormRef = ref(null)

const roles = [
  { value: 'STUDENT', label: '学生', icon: '🎓' },
  { value: 'CANTEEN_ADMIN', label: '食堂管理员', icon: '👨‍🍳' },
  { value: 'SYSTEM_ADMIN', label: '系统管理员', icon: '⚙️' }
]

const registerRoles = [
  { value: 'STUDENT', label: '学生', icon: '🎓' }
]

const loginRules = {
  username: [{ required: true, message: '请输入账号', trigger: 'blur' }],
  password: [{ required: true, message: '请输入密码', trigger: 'blur' }],
  role: [{ required: true, message: '请选择角色', trigger: 'change' }]
}

const registerRules = {
  username: [
    { required: true, message: '请输入账号', trigger: 'blur' },
    { pattern: /^[0-9]{6,12}$/, message: '学生账号必须为6-12位数字学号', trigger: 'blur' }
  ],
  realName: [{ required: true, message: '请输入真实姓名', trigger: 'blur' }],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, message: '密码至少6位', trigger: 'blur' }
  ],
  phone: [
    { pattern: /^(1[3-9]\d{9})?$/, message: '请输入正确的手机号', trigger: 'blur' }
  ],
  role: [{ required: true, message: '请选择角色', trigger: 'change' }]
}

const loginForm = reactive({
  username: '',
  password: '',
  role: 'STUDENT'
})

const registerForm = reactive({
  username: '',
  password: '',
  realName: '',
  phone: '',
  role: 'STUDENT'
})

function quickFill(username, role) {
  loginForm.username = username
  loginForm.password = '123456'
  loginForm.role = role
  activeTab.value = 'login'
}

async function handleLogin() {
  if (!loginFormRef.value) return
  try {
    await loginFormRef.value.validate()
  } catch {
    return
  }
  loginLoading.value = true
  try {
    await userStore.login(loginForm)
    ElMessage.success('登录成功')
    const roleMap = { STUDENT: '/student/home', CANTEEN_ADMIN: '/canteen-admin/dashboard', SYSTEM_ADMIN: '/system-admin/dashboard' }
    router.push(roleMap[loginForm.role] || '/login')
  } catch (error) {
    ElMessage.error(error?.response?.data?.message || error?.message || '登录失败')
  } finally {
    loginLoading.value = false
  }
}

async function handleRegister() {
  if (!registerFormRef.value) return
  try {
    await registerFormRef.value.validate()
  } catch {
    return
  }
  registerLoading.value = true
  try {
    await api.register(registerForm)
    ElMessage.success('注册成功，请登录')
    activeTab.value = 'login'
    loginForm.username = registerForm.username
    loginForm.role = registerForm.role
    loginForm.password = ''
  } catch (error) {
    ElMessage.error(error?.response?.data?.message || error?.message || '注册失败')
  } finally {
    registerLoading.value = false
  }
}
</script>

<style scoped>
.login-page {
  display: flex;
  min-height: 100vh;
}

/* 左侧 */
.login-left {
  flex: 1;
  background: linear-gradient(135deg, #1a3c2a 0%, #2d5a3d 30%, #409E67 70%, #67c23a 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px;
  position: relative;
  overflow: hidden;
}
.login-left::before {
  content: '';
  position: absolute;
  width: 400px; height: 400px;
  background: rgba(255,255,255,0.05);
  border-radius: 50%;
  top: -100px; right: -100px;
}
.login-left::after {
  content: '';
  position: absolute;
  width: 300px; height: 300px;
  background: rgba(255,255,255,0.05);
  border-radius: 50%;
  bottom: -80px; left: -80px;
}
.left-content {
  position: relative;
  z-index: 1;
  color: white;
  max-width: 400px;
}
.logo-area { text-align: center; margin-bottom: 32px; }
.logo-icon { font-size: 64px; display: block; margin-bottom: 16px; }
.logo-area h1 { font-size: 32px; margin: 0 0 4px; font-weight: 700; }
.logo-area h2 { font-size: 20px; margin: 0; font-weight: 400; opacity: 0.9; }
.slogan {
  text-align: center;
  font-size: 16px;
  line-height: 1.8;
  opacity: 0.85;
  margin: 0 0 40px;
}
.feature-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.feature-item {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 15px;
  opacity: 0.9;
}
.feature-icon { font-size: 22px; }

/* 右侧 */
.login-right {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px;
  background: #faf8f3;
}
.login-card {
  width: 100%;
  max-width: 420px;
}
.login-tabs {
  margin-bottom: 24px;
}
.login-tabs :deep(.el-tabs__header) {
  margin-bottom: 24px;
}
.login-tabs :deep(.el-tabs__item) {
  font-size: 16px;
  font-weight: 600;
}

/* 角色选择器 */
.role-selector {
  display: flex;
  gap: 12px;
  width: 100%;
}
.role-card {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  padding: 14px 8px;
  border: 2px solid #e3d8cb;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s;
  background: white;
}
.role-card:hover {
  border-color: #67c23a;
  background: #f0f9eb;
}
.role-card.active {
  border-color: #409E67;
  background: #f0f9eb;
  box-shadow: 0 0 0 3px rgba(64,158,103,0.15);
}
.role-emoji { font-size: 28px; }
.role-label { font-size: 13px; font-weight: 500; color: #606266; }
.role-card.active .role-label { color: #409E67; }

/* 测试账号 */
.test-accounts {
  margin-top: 32px;
  padding-top: 20px;
  border-top: 1px solid #e3d8cb;
}
.test-title {
  font-size: 13px;
  color: #909399;
  margin: 0 0 12px;
}
.test-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
.test-tag {
  font-size: 12px;
  padding: 6px 14px;
  border-radius: 20px;
  background: #f5f0e8;
  color: #6d6258;
  cursor: pointer;
  transition: all 0.2s;
  border: 1px solid transparent;
}
.test-tag:hover {
  background: #409E67;
  color: white;
  border-color: #409E67;
}

/* 响应式 */
@media (max-width: 768px) {
  .login-left { display: none; }
  .login-right { padding: 24px; }
  .role-selector { flex-direction: column; }
  .role-card { flex-direction: row; justify-content: center; }
}
</style>
