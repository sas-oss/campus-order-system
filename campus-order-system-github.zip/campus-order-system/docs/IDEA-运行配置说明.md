﻿# IDEA 启动当前项目详细教程

编写日期：2026-06-21

## 一、项目目录说明

当前项目根目录：

```text
<项目根目录>
```

主要目录：

```text
<项目根目录>\order-system-backend
<项目根目录>\order-system-frontend
<项目根目录>\docs
```

后端是 Spring Boot 项目，前端是 Vue 3 + Vite 项目。建议在 IDEA 中打开整个根目录 `<项目根目录>`，这样前后端和文档都能一起看到。

## 二、运行前环境要求

### 1. 后端环境

| 工具 | 要求 |
| --- | --- |
| JDK | 17 |
| Maven | 3.8+ 或使用 IDEA 自带 Maven |
| MySQL | 8.0 推荐 |

### 2. 前端环境

| 工具 | 要求 |
| --- | --- |
| Node.js | 18+ 推荐 |
| npm | 9+ 推荐 |

## 三、数据库初始化

### 1. 查看当前数据库配置

后端配置文件：

```text
<项目根目录>\order-system-backend\src\main\resources\application.yml
```

当前默认配置：

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/order_system?useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai
    username: root
    password: your_mysql_password
```

如果你本机 MySQL 的 `root` 密码不是 `your_mysql_password`，需要把 `password` 改成你的真实密码。

### 2. 创建并初始化数据库

初始化脚本：

```text
<项目根目录>\order-system-backend\src\main\resources\db\init.sql
```

在 MySQL 命令行中执行：

```sql
SOURCE <项目根目录>/order-system-backend/src/main/resources/db/init.sql;
```

这个脚本会：

- 创建 `order_system` 数据库。
- 删除并重建系统所需表。
- 插入角色、食堂、窗口、用户、菜单、订单、评价、消息等完整演示数据。

如果你之前已经运行过旧版本数据库，也建议重新执行一次 `init.sql`。当前版本新增了：

- `order_info.pickup_code`：取餐确认校验码。
- `review_item`：菜品评分明细表。

旧库如果不更新这两项，确认取餐和结构化菜品评价会报错。

## 四、在 IDEA 中启动后端

### 1. 打开项目

在 IDEA 中选择：

```text
File -> Open
```

打开目录：

```text
<项目根目录>
```

### 2. 设置 JDK

进入：

```text
File -> Project Structure -> Project
```

设置：

- `SDK`：选择 JDK 17。
- `Language level`：选择 17。

如果没有 JDK 17，需要先安装 JDK 17，然后回到 IDEA 中重新选择。

### 3. 导入 Maven 项目

找到后端 `pom.xml`：

```text
<项目根目录>\order-system-backend\pom.xml
```

如果 IDEA 右上角出现 `Load Maven Changes`，点击它。

也可以打开右侧 Maven 面板，点击刷新按钮。

### 4. 检查数据库配置

打开：

```text
<项目根目录>\order-system-backend\src\main\resources\application.yml
```

重点确认：

- MySQL 地址是否是 `localhost:3306`。
- 数据库名是否是 `order_system`。
- 用户名是否正确。
- 密码是否正确。

### 5. 启动 Spring Boot

启动类：

```text
<项目根目录>\order-system-backend\src\main\java\com\ordersystem\OrderSystemApplication.java
```

启动方式：

1. 打开 `OrderSystemApplication.java`。
2. 点击类左侧绿色运行按钮。
3. 选择 `Run 'OrderSystemApplication'`。

后端启动成功后，控制台应显示 Spring Boot 已启动，端口为：

```text
8080
```

### 6. 验证后端

浏览器访问：

```text
http://localhost:8080/doc.html
```

如果能打开 Knife4j 接口文档，说明后端启动成功。

也可以访问公开菜单接口：

```text
http://localhost:8080/api/canteens
```

## 五、在 IDEA 中启动前端

### 1. 确认 Node.js

在 IDEA 中进入：

```text
File -> Settings -> Languages & Frameworks -> Node.js
```

选择本机安装的 Node.js。

也可以在 IDEA Terminal 中执行：

```bash
node -v
npm -v
```

如果能看到版本号，说明 Node.js 和 npm 可用。

### 2. 安装前端依赖

在 IDEA Terminal 中进入前端目录：

```bash
cd <项目根目录>\order-system-frontend
```

安装依赖：

```bash
npm install
```

如果项目中已有 `node_modules`，也建议首次运行前执行一次 `npm install`，确保依赖完整。

### 3. 启动前端

继续在前端目录执行：

```bash
npm run dev
```

启动成功后，终端会显示本地访问地址，默认是：

```text
http://localhost:5173
```

用浏览器打开即可进入登录页。

## 六、前后端联调说明

前端请求配置在：

```text
<项目根目录>\order-system-frontend\src\api\request.js
```

前端 Axios 的 `baseURL` 是：

```javascript
baseURL: '/api'
```

Vite 代理配置在：

```text
<项目根目录>\order-system-frontend\vite.config.js
```

代理规则：

```javascript
proxy: {
  '/api': {
    target: 'http://localhost:8080',
    changeOrigin: true
  },
  '/uploads': {
    target: 'http://localhost:8080',
    changeOrigin: true
  }
}
```

因此本地开发时：

- 前端地址：`http://localhost:5173`
- 后端地址：`http://localhost:8080`
- 前端请求 `/api/...` 会自动转发到后端。
- 前端访问 `/uploads/...` 会自动转发到后端图片资源。

## 七、推荐启动顺序

每次从零启动时，按这个顺序最稳：

1. 启动 MySQL。
2. 确认 `application.yml` 中数据库账号密码正确。
3. 首次运行时执行 `init.sql`。
4. 在 IDEA 中启动后端 `OrderSystemApplication`。
5. 打开 `http://localhost:8080/doc.html` 验证后端。
6. 在 IDEA Terminal 中进入 `order-system-frontend`。
7. 执行 `npm run dev`。
8. 打开 `http://localhost:5173`。
9. 使用测试账号登录。

## 八、测试账号

初始化脚本中的默认测试账号如下，密码均为：

```text
your_mysql_password
```

| 角色 | 账号 | 登录角色 |
| --- | --- | --- |
| 学生 | `20240001` | 学生 |
| 食堂管理员 | `admin001` | 食堂管理员 |
| 系统管理员 | `system001` | 系统管理员 |

## 九、常见问题与解决方法

### 1. 后端启动失败：数据库连接失败

常见原因：

- MySQL 没有启动。
- `application.yml` 中密码不正确。
- 没有创建 `order_system` 数据库。
- MySQL 端口不是 `3306`。

处理方法：

1. 确认 MySQL 服务已启动。
2. 用数据库工具或命令行确认账号密码能登录。
3. 修改 `application.yml` 中的 `username` 和 `password`。
4. 重新执行 `init.sql`。
5. 重启后端。

### 2. 后端启动失败：端口 8080 被占用

如果 `8080` 已被其他程序占用，可以修改：

```text
<项目根目录>\order-system-backend\src\main\resources\application.yml
```

将：

```yaml
server:
  port: 8080
```

改为：

```yaml
server:
  port: 8081
```

同时需要修改前端代理目标：

```text
<项目根目录>\order-system-frontend\vite.config.js
```

把 `http://localhost:8080` 改成 `http://localhost:8081`。

### 3. 前端启动失败：npm 或 node 不存在

说明 Node.js 没有安装，或 IDEA 没有识别到 Node.js。

处理方法：

1. 安装 Node.js 18+。
2. 重启 IDEA。
3. 在 IDEA 设置中选择 Node.js 路径。
4. 重新执行 `node -v` 和 `npm -v`。

### 4. 前端页面能打开，但接口报错 401

常见原因：

- 没有登录。
- 登录 token 过期。
- 后端没有启动。
- 浏览器中保存了旧 token。

处理方法：

1. 退出登录后重新登录。
2. 清除浏览器 Local Storage 中的 `token`、`role`、`userInfo`。
3. 确认后端 `8080` 正常运行。

### 5. 菜品图片显示失败

常见原因：

- 后端没有启动。
- 图片文件没有成功上传。
- `uploads` 目录没有生成。
- 前端代理 `/uploads` 没生效。

检查目录：

```text
<项目根目录>\uploads\menu-images
```

或后端运行目录下的：

```text
uploads\menu-images
```

### 6. 登录提示账号或密码错误

确认：

- 是否已执行 `init.sql`。
- 是否选择了正确角色。
- 密码是否是 `your_mysql_password`。

例如 `20240001` 必须选择学生角色登录，不能选择食堂管理员或系统管理员。

## 十、可以在 IDEA 中配置的运行项

### 1. 后端 Spring Boot 运行配置

运行配置建议：

| 项目 | 值 |
| --- | --- |
| Name | `order-system-backend` |
| Main class | `com.ordersystem.OrderSystemApplication` |
| JRE | JDK 17 |
| Working directory | `<项目根目录>\order-system-backend` |

### 2. 前端 npm 运行配置

运行配置建议：

| 项目 | 值 |
| --- | --- |
| Name | `order-system-frontend` |
| package.json | `<项目根目录>\order-system-frontend\package.json` |
| Command | `run` |
| Scripts | `dev` |
| Node interpreter | 本机 Node.js |
| Working directory | `<项目根目录>\order-system-frontend` |

配置好后，可以直接在 IDEA 右上角选择对应运行项启动。

## 十一、启动成功后的验证流程

建议按下面流程验证系统功能：

1. 使用 `system001 / your_mysql_password` 登录系统管理员端。
2. 查看食堂管理和窗口管理是否有数据。
3. 查看用户管理中是否有学生和食堂管理员账号。
4. 退出登录。
5. 使用 `admin001 / your_mysql_password` 登录食堂管理员端。
6. 查看菜品管理是否能看到窗口菜品。
7. 新增或编辑一个菜品库存。
8. 退出登录。
9. 使用 `20240001 / your_mysql_password` 登录学生端。
10. 进入菜单页，选择菜品加入购物车。
11. 进入购物车和下单页，选择取餐时间段和支付方式。
12. 提交订单并完成模拟支付。
13. 再切换到食堂管理员端，进入订单管理。
14. 依次点击开始制作、制作完成、确认取餐。
15. 回到学生端查看订单状态和消息中心。
16. 已取餐后提交评价。

完成以上流程，说明当前项目的主要业务链路已经跑通。

